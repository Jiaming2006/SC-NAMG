=== 03_Supplementary_material ===

Upload the contents of this folder as Supplementary material on the Springer
submission portal.  This material is intended to be published alongside the
manuscript and provides the reference implementation that reproduces all
numerical experiments.

Structure:
  sc_namg/ai_amg/
    src/           - algorithmic core (OSC, AIK, DMLE, GNN coarsener)
    bench/         - benchmark drivers and matrix loaders
    checkpoints/   - 3 trained GNN checkpoints (gnn.pt, gnn_dmle*.pt)
    configs/  examples/  scripts/  tests/  docs/
    README.md
  experiments_extra/
    diagnose_dmle/ - DMLE diagnostic scripts

Note: the 807 MB training-tensor file train_50.pt is omitted; the underlying
matrices are regenerable from src/matrix_gen.py.  SuiteSparse engineering
matrices are publicly available at https://sparse.tamu.edu and are downloaded
by bench/download_suitesparse.py.

"""DMLE (Differentiable Multi-Level Energy) 单元测试.

测试 dmle_loss.py 中的:
    - gumbel_softmax_cf: Gumbel-Softmax C/F 决策
    - strength_matrix_torch: torch 版强连接
    - build_P_differentiable: 可微插值算子
    - spectral_radius_power: 幂迭代谱半径
    - two_grid_error_op: 二级误差传播算子
    - dmle_loss_single: 单样本 DMLE 损失
    - tau_schedule: 温度退火
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pytest
import scipy.sparse as sp
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from src.dmle_loss import (
    gumbel_softmax_cf,
    strength_matrix_torch,
    build_P_differentiable,
    spectral_radius_power,
    two_grid_error_op,
    dmle_loss_single,
    tau_schedule,
    complexity_regularizer,
    smoothness_regularizer,
    differentiable_kappa,
    dmle_loss_batch_multilevel,
)
from src.gnn_model import CFClassifier
from src.graph_features import to_pyg_data
from src import matrix_gen


class TestDifferentiableKappa:
    """Direction 2 核心: 可微 Lanczos κ(M⁻¹A) 估计."""

    def _spd_op(self, n=40):
        # SPD operator with known-ish conditioning
        d = torch.linspace(1.0, 10.0, n)
        return (lambda v: d * v), d

    def test_positive_and_geq_one(self):
        op, d = self._spd_op(50)
        k = differentiable_kappa(op, 50, m=15)
        assert torch.isfinite(k)
        assert k.item() > 0.0
        # κ of a diagonal op ≈ max/min ≥ 1
        assert k.item() >= 1.0 - 1e-3

    def test_tracks_true_condition_number(self):
        # diagonal 1..C : true κ = C
        for C in (5.0, 20.0):
            d = torch.linspace(1.0, C, 60)
            k = differentiable_kappa(lambda v: d * v, 60, m=30)
            # Lanczos lower-bounds the spread; should be within 2x band
            assert 0.4 * C <= k.item() <= 1.05 * C

    def test_gradient_flows(self):
        torch.manual_seed(0)
        s = torch.nn.Parameter(torch.ones(40))
        op = lambda v: (1.0 + s.abs()) * v
        k = differentiable_kappa(op, 40, m=12)
        k.backward()
        assert s.grad is not None and s.grad.abs().sum() > 0

    def test_kappa_term_in_multilevel_loss(self):
        torch.manual_seed(0)
        m = CFClassifier(in_dim=7, hidden=16, layers=2, conv="gatv2")
        A = matrix_gen.poisson_2d(16)
        batch = [(A, to_pyg_data(A))]
        _, i0 = dmle_loss_batch_multilevel(m, batch, tau=1.0,
                                           n_power=6, lam_kappa=0.0)
        _, i1 = dmle_loss_batch_multilevel(m, batch, tau=1.0,
                                           n_power=6, lam_kappa=0.1,
                                           m_lanczos=8)
        assert i0[0]["kappa_hat"] is None
        assert i1[0]["kappa_hat"] is not None
        assert i1[0]["kappa_hat"] > 0.0


class TestGATv2EdgeAttr:
    """Direction 1 核心: GATv2Conv + edge_attr 路径."""

    def test_gatv2_uses_edge_attr_flag(self):
        m = CFClassifier(in_dim=7, hidden=16, layers=2, conv="gatv2")
        assert m.uses_edge_attr is True
        s = CFClassifier(in_dim=7, hidden=16, layers=2, conv="sage")
        assert s.uses_edge_attr is False

    def test_forward_with_edge_attr_shape(self):
        A = matrix_gen.anisotropic_2d(16, epsilon=1e-3, theta=0.785)
        d = to_pyg_data(A)
        assert d.edge_attr.shape[1] == 2
        m = CFClassifier(in_dim=7, hidden=16, layers=2, conv="gatv2")
        out = m(d.x, d.edge_index, d.edge_attr)
        assert out.shape == (A.shape[0],)
        assert torch.all(torch.isfinite(out))

    def test_gatv2_gradient_flows(self):
        torch.manual_seed(0)
        A = matrix_gen.poisson_2d(14)
        d = to_pyg_data(A)
        m = CFClassifier(in_dim=7, hidden=16, layers=2, conv="gatv2")
        m.train()
        loss = m(d.x, d.edge_index, d.edge_attr).pow(2).mean()
        loss.backward()
        g = sum(p.grad.norm().item() for p in m.parameters()
                if p.grad is not None)
        assert g > 1e-8

    def test_predict_cf_gatv2_consistent(self):
        A = matrix_gen.poisson_2d(16)
        d = to_pyg_data(A)
        m = CFClassifier(in_dim=7, hidden=16, layers=2, conv="gatv2")
        cf, probs = m.predict_cf(d, threshold=0.5)
        assert cf.shape == (A.shape[0],)
        assert ((cf == 0) | (cf == 1)).all()
        assert torch.all((probs >= 0) & (probs <= 1))

    def test_sage_backward_compatible_ignores_edge_attr(self):
        A = matrix_gen.poisson_2d(14)
        d = to_pyg_data(A)
        s = CFClassifier(in_dim=7, hidden=16, layers=2, conv="sage")
        # passing edge_attr must not break the non-edge convs
        out = s(d.x, d.edge_index, d.edge_attr)
        assert out.shape == (A.shape[0],)


class TestGumbelSoftmaxCF:
    def test_output_shape(self):
        logits = torch.randn(50)
        cf = gumbel_softmax_cf(logits, tau=1.0)
        assert cf.shape == (50,)

    def test_hard_binary(self):
        logits = torch.randn(100)
        cf = gumbel_softmax_cf(logits, tau=0.5, hard=True)
        assert set(cf.unique().tolist()).issubset({0.0, 1.0})

    def test_soft_continuous(self):
        logits = torch.randn(100)
        cf = gumbel_softmax_cf(logits, tau=1.0, hard=False)
        assert (cf >= 0).all() and (cf <= 1).all()
        assert not all(v in (0.0, 1.0) for v in cf.tolist())

    def test_gradient_flows(self):
        logits = torch.randn(30, requires_grad=True)
        cf = gumbel_softmax_cf(logits, tau=0.5, hard=True)
        loss = cf.sum()
        loss.backward()
        assert logits.grad is not None
        assert logits.grad.abs().sum() > 0

    def test_high_logits_mostly_c(self):
        logits = torch.ones(100) * 10.0
        cf = gumbel_softmax_cf(logits, tau=0.1, hard=True)
        assert cf.mean() > 0.9


class TestStrengthMatrixTorch:
    def test_poisson_1d(self):
        n = 20
        A = sp.diags([-1, 2, -1], [-1, 0, 1], shape=(n, n), format="csr")
        edges = strength_matrix_torch(A, theta=0.25)
        assert edges.shape[0] == 2
        assert edges.shape[1] > 0
        # Each interior node should have 2 strong connections
        assert edges.shape[1] == 2 * (n - 2) + 2  # interior + boundary

    def test_diagonal_no_strong(self):
        n = 10
        A = sp.eye(n, format="csr")
        edges = strength_matrix_torch(A, theta=0.25)
        assert edges.shape[1] == 0


class TestBuildPDifferentiable:
    def test_identity_for_all_c(self):
        n = 10
        A = torch.diag(torch.ones(n) * 2) - torch.diag(torch.ones(n - 1), 1) - torch.diag(torch.ones(n - 1), -1)
        cf_soft = torch.ones(n)  # all C
        edges = torch.zeros(2, 0, dtype=torch.long)
        P = build_P_differentiable(A, cf_soft, edges)
        assert P.shape == (n, n)

    def test_output_shape(self):
        n = 16
        A = torch.diag(torch.ones(n) * 2) - torch.diag(torch.ones(n - 1), 1) - torch.diag(torch.ones(n - 1), -1)
        # Alternate C/F
        cf_soft = torch.zeros(n)
        cf_soft[::2] = 1.0
        A_csr = sp.diags([-1, 2, -1], [-1, 0, 1], shape=(n, n), format="csr")
        edges = strength_matrix_torch(A_csr, theta=0.25)
        P = build_P_differentiable(A, cf_soft, edges)
        n_c = int(cf_soft.sum().item())
        assert P.shape == (n, n_c)

    def test_c_points_have_identity_rows(self):
        n = 10
        A = torch.diag(torch.ones(n) * 2) - torch.diag(torch.ones(n - 1), 1) - torch.diag(torch.ones(n - 1), -1)
        cf_soft = torch.zeros(n)
        cf_soft[0] = 1.0
        cf_soft[3] = 1.0
        cf_soft[6] = 1.0
        cf_soft[9] = 1.0
        edges = torch.tensor([[0, 1, 2, 3, 4, 5, 6, 7, 8],
                              [1, 2, 3, 4, 5, 6, 7, 8, 9]], dtype=torch.long)
        P = build_P_differentiable(A, cf_soft, edges)
        # C-point rows should have exactly one 1.0
        c_indices = [0, 3, 6, 9]
        for idx, ci in enumerate(c_indices):
            assert abs(P[ci, idx].item() - 1.0) < 1e-5

    def test_gradient_through_P(self):
        n = 8
        A = torch.diag(torch.ones(n) * 2) - torch.diag(torch.ones(n - 1), 1) - torch.diag(torch.ones(n - 1), -1)
        logits = torch.randn(n, requires_grad=True)
        cf_soft = gumbel_softmax_cf(logits, tau=0.5, hard=True)
        edges = torch.tensor([[0, 1, 2, 3, 4, 5, 6],
                              [1, 2, 3, 4, 5, 6, 7]], dtype=torch.long)
        P = build_P_differentiable(A, cf_soft, edges)
        loss = P.sum()
        loss.backward()
        assert logits.grad is not None


class TestSpectralRadius:
    def test_identity(self):
        n = 20
        def op(v): return v
        rho = spectral_radius_power(op, n, n_iters=10)
        assert abs(rho.item() - 1.0) < 0.1

    def test_scaled_identity(self):
        n = 20
        def op(v): return 0.5 * v
        rho = spectral_radius_power(op, n, n_iters=10)
        assert abs(rho.item() - 0.5) < 0.1

    def test_known_matrix(self):
        torch.manual_seed(0)
        n = 10
        M = torch.randn(n, n)
        M = M @ M.T / n  # symmetric positive semi-definite
        eigs = torch.linalg.eigvalsh(M)
        true_rho = eigs.abs().max().item()
        def op(v): return M @ v
        rho = spectral_radius_power(op, n, n_iters=30)
        assert abs(rho.item() - true_rho) / true_rho < 0.2


class TestTwoGridErrorOp:
    def test_returns_callable(self):
        n, n_c = 8, 4
        A = torch.diag(torch.ones(n) * 2) - torch.diag(torch.ones(n - 1), 1) - torch.diag(torch.ones(n - 1), -1)
        P = torch.randn(n, n_c)
        E = two_grid_error_op(A, P)
        v = torch.randn(n)
        result = E(v)
        assert result.shape == (n,)

    def test_ideal_P_gives_small_rho(self):
        """If P perfectly interpolates, rho(E_TG) should be small."""
        n = 10
        A = torch.diag(torch.ones(n) * 2) - torch.diag(torch.ones(n - 1), 1) - torch.diag(torch.ones(n - 1), -1)
        # Ideal: P = [I; W] for alternating C/F
        n_c = 5
        P = torch.zeros(n, n_c)
        for i in range(n_c):
            P[2 * i, i] = 1.0
            if 2 * i + 1 < n:
                P[2 * i + 1, i] = 0.5
                if i + 1 < n_c:
                    P[2 * i + 1, i + 1] = 0.5
        E = two_grid_error_op(A, P, n_smooth=2)
        rho = spectral_radius_power(E, n, n_iters=20)
        assert rho.item() < 0.9


class TestDMLELossSingle:
    def test_runs_without_error(self):
        import pyamg
        torch.manual_seed(0)
        n = 8
        A = pyamg.gallery.poisson((n, n), format="csr")
        from src.graph_features import to_pyg_data
        from src.gnn_model import CFClassifier
        data = to_pyg_data(A, labels=None)
        model = CFClassifier(hidden=16, layers=2)
        model.train()
        logits = model(data.x, data.edge_index)
        loss, info = dmle_loss_single(A, logits, tau=1.0)
        assert loss.item() > 0
        assert "rho" in info
        assert "n_c" in info

    def test_backward_pass(self):
        import pyamg
        torch.manual_seed(1)
        n = 6
        A = pyamg.gallery.poisson((n, n), format="csr")
        from src.graph_features import to_pyg_data
        from src.gnn_model import CFClassifier
        data = to_pyg_data(A, labels=None)
        model = CFClassifier(hidden=16, layers=2)
        model.train()
        logits = model(data.x, data.edge_index)
        loss, info = dmle_loss_single(A, logits, tau=1.0)
        loss.backward()
        grad_norm = sum(p.grad.norm().item() for p in model.parameters() if p.grad is not None)
        assert grad_norm > 0


class TestTauSchedule:
    def test_starts_high(self):
        tau = tau_schedule(0, 100, tau_start=2.0, tau_end=0.1)
        assert abs(tau - 2.0) < 1e-6

    def test_ends_low(self):
        tau = tau_schedule(99, 100, tau_start=2.0, tau_end=0.1)
        assert abs(tau - 0.1) < 0.01

    def test_monotone_decreasing(self):
        taus = [tau_schedule(ep, 100) for ep in range(100)]
        for i in range(1, len(taus)):
            assert taus[i] <= taus[i - 1] + 1e-10


class TestRegularizers:
    def test_complexity(self):
        P = torch.randn(20, 10)
        reg = complexity_regularizer(P, 20)
        assert abs(reg.item() - 0.5) < 1e-6

    def test_smoothness_positive(self):
        torch.manual_seed(0)
        n = 16
        A = torch.diag(torch.ones(n) * 2) - torch.diag(torch.ones(n - 1), 1) - torch.diag(torch.ones(n - 1), -1)
        P = torch.randn(n, 8)
        reg = smoothness_regularizer(A, P)
        assert reg.item() > 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

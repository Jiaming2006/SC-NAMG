"""Tests for the NeurIF/GNP baseline proxy (honest cited fallback)."""
import numpy as np
import scipy.sparse as sp

from ai_amg.bench.baselines.neurif_gnp_proxy import (
    SKIP, solve_neurif, solve_gnp, register_baseline,
    build_comparison, to_markdown, CITED_BASELINES)


def _sys():
    A = sp.eye(8, format="csr") * 2.0
    return A, np.ones(8)


def test_skip_when_not_installed():
    A, b = _sys()
    assert solve_neurif(A, b, 1e-8) == SKIP
    assert solve_gnp(A, b, 1e-8) == SKIP


def test_registered_baseline_runs():
    A, b = _sys()

    def fake(A, b, tol):
        x = b / A.diagonal()
        return x, 1, 0.0, 0.01, float(np.linalg.norm(b - A @ x))

    register_baseline("neurif", fake)
    out = solve_neurif(A, b, 1e-8)
    assert out != SKIP
    x, iters, ts, tsv, res = out
    assert iters == 1 and res < 1e-10
    # cleanup the registry so other tests see the SKIP path
    from ai_amg.bench.baselines import neurif_gnp_proxy as p
    p._REGISTRY.clear()
    assert solve_neurif(A, b, 1e-8) == SKIP


def test_no_fabricated_numbers():
    # cited baselines must NOT ship invented values
    for bl in ("neurif", "gnp"):
        for cls, v in CITED_BASELINES[bl]["by_class"].items():
            assert v["iters"] is None, f"{bl}/{cls} has a fabricated value"
        assert "citation" in CITED_BASELINES[bl]
        assert CITED_BASELINES[bl]["citation"]


def test_build_comparison_merges_real_numbers():
    exp4 = {"results": [
        {"matrix": "poisson_2d_32", "n": 1024,
         "methods": {"amg_pcg": {"iters": 6}, "sc_namg": {"iters": 6}}},
        {"matrix": "bcsstk16", "error": "not downloaded"},  # skipped row
    ]}
    cmp = build_comparison(exp4)
    assert cmp["summary"]["n_matrices"] == 1   # error row dropped
    r = cmp["rows"][0]
    assert r["amg_pcg"] == 6 and r["sc_namg"] == 6
    assert r["neurif"] is None                  # cited-TODO, not faked
    assert r["neurif_status"] == "cited-TODO"
    assert "Häusner" in cmp["summary"]["neurif_citation"]


def test_to_markdown_renders_table():
    exp4 = {"results": [
        {"matrix": "poisson_2d_32", "n": 1024,
         "methods": {"amg_pcg": {"iters": 6}, "sc_namg": {"iters": 6}}},
    ]}
    md = to_markdown(build_comparison(exp4))
    assert "| Matrix |" in md and "SC-NAMG" in md
    assert "cited†" in md and "cited from" in md


def test_solvers_registry_includes_baselines():
    from ai_amg.bench.run import SOLVERS
    assert "neurif" in SOLVERS and "gnp" in SOLVERS

"""
test_osc.py -- Unit tests for the OSC module (spectral_operational_bound.py)
======================================================================

Covers:
  - Lanczos tridiagonalisation accuracy
  - Gauss-Christoffel quadrature correctness
  - SLQ spectral bounds on known-spectrum matrices
  - Adaptive SLQ convergence
  - AISolver.certify() integration
  - Coverage on Poisson 2D with AMG preconditioner

Run:
    python -m pytest ai_amg/tests/test_osc.py -v
    python ai_amg/tests/test_osc.py            # standalone
"""
from __future__ import annotations

import numpy as np
import scipy.sparse as sp
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from ai_amg.src.spectral_certificate import (
    lanczos_tridiag,
    gauss_quadrature,
    slq_spectrum_bounds,
    slq_spectrum_bounds_adaptive,
    certify_amg_solver,
)


# ---------------------------------------------------------------
# Helper: build SPD matrix with known spectrum
# ---------------------------------------------------------------
def make_spd_known_spectrum(eigvals: np.ndarray, seed: int = 42) -> np.ndarray:
    rng = np.random.default_rng(seed)
    n = len(eigvals)
    Q, _ = np.linalg.qr(rng.standard_normal((n, n)))
    return Q @ np.diag(eigvals) @ Q.T


# ===============================================================
# Test: Lanczos
# ===============================================================
class TestLanczos:
    def test_tridiag_orthogonality(self):
        """V columns should be orthonormal."""
        n = 50
        A = make_spd_known_spectrum(np.linspace(1, 50, n))
        v0 = np.random.default_rng(0).standard_normal(n)
        _, _, V = lanczos_tridiag(lambda v: A @ v, v0, m=30)
        gram = V @ V.T
        assert np.allclose(gram, np.eye(gram.shape[0]), atol=1e-10), \
            f"Lanczos basis not orthonormal: max deviation {np.abs(gram - np.eye(gram.shape[0])).max():.2e}"

    def test_full_spectrum_recovery(self):
        """m=n Lanczos should recover all eigenvalues."""
        n = 15
        eigvals = np.array([0.5, 1.0, 2.0, 3.5, 5.0, 7.0, 10.0, 12.0,
                            15.0, 18.0, 22.0, 28.0, 35.0, 45.0, 60.0])
        A = make_spd_known_spectrum(eigvals)
        v0 = np.random.default_rng(1).standard_normal(n)
        alphas, betas, V = lanczos_tridiag(lambda v: A @ v, v0, m=n)
        nodes, _ = gauss_quadrature(alphas, betas)
        assert np.allclose(np.sort(nodes), np.sort(eigvals), rtol=1e-6), \
            "Full Lanczos did not recover spectrum"

    def test_invariant_subspace_early_exit(self):
        """If v0 lies in a k-dim invariant subspace, Lanczos exits early."""
        n = 20
        A = np.diag(np.arange(1.0, n + 1))
        v0 = np.zeros(n)
        v0[0] = 1.0  # lies in 1-dim eigenspace
        alphas, betas, V = lanczos_tridiag(lambda v: A @ v, v0, m=10)
        assert len(alphas) == 1, f"Expected 1-step exit, got {len(alphas)} steps"
        assert abs(alphas[0] - 1.0) < 1e-10


# ===============================================================
# Test: Gauss quadrature
# ===============================================================
class TestGaussQuadrature:
    def test_nodes_match_eigenvalues(self):
        alphas = np.array([2.0, 3.0, 4.0, 5.0])
        betas = np.array([-0.5, -0.8, -0.3])
        T = np.diag(alphas) + np.diag(betas, 1) + np.diag(betas, -1)
        ev_true = np.linalg.eigvalsh(T)
        nodes, weights = gauss_quadrature(alphas, betas)
        assert np.allclose(nodes, ev_true, atol=1e-12)

    def test_weights_sum_to_one(self):
        alphas = np.array([1.0, 2.0, 3.0])
        betas = np.array([-0.5, -0.5])
        _, weights = gauss_quadrature(alphas, betas)
        assert abs(weights.sum() - 1.0) < 1e-12

    def test_empty_input(self):
        nodes, weights = gauss_quadrature(np.array([]), np.array([]))
        assert len(nodes) == 0 and len(weights) == 0


# ===============================================================
# Test: SLQ spectral bounds
# ===============================================================
class TestSLQBounds:
    def test_diagonal_identity_coverage(self):
        """For A=diag(1..100), M=I, true spectrum is [1,100]."""
        n = 200
        eigvals = np.linspace(1.0, 100.0, n)
        D = np.diag(eigvals)
        c, C, delta = slq_spectrum_bounds(
            lambda v: D @ v, lambda v: v.copy(), n, m=30, n_probes=30
        )
        # SLQ gives interior estimates; with 30 probes they should be close
        assert c <= eigvals.min() + 5.0, f"c={c} too far above lmin=1"
        assert C >= eigvals.max() - 5.0, f"C={C} too far below lmax=100"

    def test_well_conditioned_tight_bounds(self):
        """kappa=2 matrix should give tight bounds."""
        n = 100
        eigvals = np.linspace(1.0, 2.0, n)
        A = make_spd_known_spectrum(eigvals)
        c, C, _ = slq_spectrum_bounds(
            lambda v: A @ v, lambda v: v.copy(), n, m=20, n_probes=20
        )
        assert 0.5 < c < 1.5, f"c={c} out of range"
        assert 1.5 < C < 2.5, f"C={C} out of range"

    def test_deterministic_with_seed(self):
        """Same seed should produce same result."""
        n = 50
        A = np.diag(np.linspace(1, 10, n))
        r1 = slq_spectrum_bounds(lambda v: A @ v, lambda v: v.copy(), n, rng=42)
        r2 = slq_spectrum_bounds(lambda v: A @ v, lambda v: v.copy(), n, rng=42)
        assert r1[0] == r2[0] and r1[1] == r2[1]


# ===============================================================
# Test: Adaptive SLQ
# ===============================================================
class TestAdaptiveSLQ:
    def test_uses_fewer_probes_on_easy_problem(self):
        """kappa=2 should converge quickly."""
        n = 100
        eigvals = np.linspace(1.0, 2.0, n)
        A = make_spd_known_spectrum(eigvals)
        _, _, _, info = slq_spectrum_bounds_adaptive(
            lambda v: A @ v, lambda v: v.copy(), n,
            m=15, n_probes_init=4, n_probes_max=40,
        )
        assert info["n_probes_used"] <= 20, \
            f"Used {info['n_probes_used']} probes on easy problem"

    def test_returns_timing(self):
        n = 50
        A = np.diag(np.linspace(1, 5, n))
        _, _, _, info = slq_spectrum_bounds_adaptive(
            lambda v: A @ v, lambda v: v.copy(), n,
            m=10, n_probes_init=4, n_probes_max=10,
        )
        assert "time_osc" in info
        assert info["time_osc"] > 0


# ===============================================================
# Test: AISolver.certify() integration
# ===============================================================
class TestAISolverCertify:
    def test_certify_poisson_2d(self):
        """certify() on Poisson 2D should give ratio close to 1."""
        import pyamg
        from ai_amg.src.amg_solver import AISolver

        A = pyamg.gallery.poisson((16, 16), format="csr")
        solver = AISolver(model=None, tol=1e-8, max_iter=50)
        solver.setup(A)
        cert = solver.certify(m=15, n_probes=8, adaptive=False)

        assert "c" in cert and "C" in cert and "ratio" in cert
        assert cert["c"] > 0
        assert cert["C"] >= cert["c"]
        assert cert["ratio"] < 100, f"ratio={cert['ratio']} too large for Poisson"
        print(f"  Poisson 16x16: ratio={cert['ratio']:.2f}, time={cert['time_osc']:.3f}s")

    def test_certify_with_adaptive(self):
        import pyamg
        from ai_amg.src.amg_solver import AISolver

        A = pyamg.gallery.poisson((16, 16), format="csr")
        solver = AISolver(model=None, tol=1e-8, max_iter=50)
        solver.setup(A)
        cert = solver.certify(m=15, n_probes=6, adaptive=True)

        assert cert["c"] > 0
        assert cert["ratio"] < 100


# ===============================================================
# Test: Coverage on Poisson 2D with ARPACK ground truth
# ===============================================================
class TestCoveragePoisson:
    def test_coverage_poisson_2d_bare(self):
        """SLQ on bare Poisson 2D (M=I) should cover true spectrum."""
        import pyamg
        from scipy.sparse.linalg import eigsh

        A = pyamg.gallery.poisson((16, 16), format="csr")
        n = A.shape[0]

        c, C, _ = slq_spectrum_bounds(
            lambda v: A @ v, lambda v: v.copy(), n, m=20, n_probes=20
        )
        lmin = eigsh(A, k=1, sigma=0, which="LM", return_eigenvectors=False)[0]
        lmax = eigsh(A, k=1, which="LM", return_eigenvectors=False)[0]

        # SLQ gives interior estimates; they should be reasonably close
        assert c <= lmin * 1.5, f"c={c} >> lmin={lmin}"
        assert C >= lmax * 0.7, f"C={C} << lmax={lmax}"
        over_conserv = (C / c) / (lmax / lmin)
        print(f"  Poisson 16x16 bare: c={c:.4f}, C={C:.3f}, "
              f"true=[{lmin:.4f},{lmax:.3f}], over_conserv={over_conserv:.2f}")


# ===============================================================
# Standalone runner
# ===============================================================
def _run_all():
    import traceback
    classes = [TestLanczos, TestGaussQuadrature, TestSLQBounds,
               TestAdaptiveSLQ, TestAISolverCertify, TestCoveragePoisson]
    total = 0
    passed = 0
    failed = 0
    for cls in classes:
        print(f"\n{'='*50}")
        print(f"  {cls.__name__}")
        print(f"{'='*50}")
        obj = cls()
        for name in sorted(dir(obj)):
            if not name.startswith("test_"):
                continue
            total += 1
            print(f"\n  [{name}] ", end="")
            try:
                getattr(obj, name)()
                print("PASS")
                passed += 1
            except Exception as e:
                print(f"FAIL: {e}")
                traceback.print_exc()
                failed += 1
    print(f"\n{'='*50}")
    print(f"  Results: {passed}/{total} passed, {failed} failed")
    print(f"{'='*50}")
    return failed == 0


if __name__ == "__main__":
    success = _run_all()
    sys.exit(0 if success else 1)

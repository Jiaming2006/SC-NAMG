"""Tests for the NN-assisted Krylov subsystem (pytorch_linalg)."""
import numpy as np
import pytest
import torch

from ai_amg.src import matrix_gen
from ai_amg.src.pytorch_linalg import (
    PRECONDITIONERS, jacobi_precond, ilu_precond, amg_precond,
    pcg, gmres, InitialGuessNet, initial_guess_residual_loss,
    MethodSelector, matrix_signature)


@pytest.fixture
def spd():
    A = matrix_gen.poisson_2d(16)
    xs = np.random.RandomState(0).randn(A.shape[0])
    return A, A @ xs, xs


# ---- preconditioners ----
def test_jacobi_precond_shape(spd):
    A, b, _ = spd
    z = jacobi_precond(A)(b)
    assert z.shape == b.shape and np.all(np.isfinite(z))


def test_all_preconditioners_make_pcg_converge(spd):
    A, b, xs = spd
    for name, fn in PRECONDITIONERS.items():
        x, info = pcg(A, b, fn(A), tol=1e-8, max_iter=400)
        assert info["converged"], f"{name} did not converge"
        assert np.linalg.norm(x - xs) / np.linalg.norm(xs) < 1e-5


def test_ilu_fewer_iters_than_unpreconditioned(spd):
    A, b, _ = spd
    _, i_none = pcg(A, b, None, tol=1e-8, max_iter=500)
    _, i_ilu = pcg(A, b, ilu_precond(A), tol=1e-8, max_iter=500)
    assert i_ilu["iters"] <= i_none["iters"]


def test_amg_precond_runs(spd):
    A, b, _ = spd
    _, info = pcg(A, b, amg_precond(A), tol=1e-8, max_iter=200)
    assert info["converged"]


# ---- solvers ----
def test_pcg_x0_warm_start_reduces_iters(spd):
    A, b, xs = spd
    M = amg_precond(A)
    _, i0 = pcg(A, b, M, x0=None, tol=1e-8, max_iter=300)
    _, iw = pcg(A, b, M, x0=xs * 0.9, tol=1e-8, max_iter=300)
    assert iw["iters"] <= i0["iters"]


def test_gmres_nonsymmetric():
    n = 200
    import scipy.sparse as sp
    A = sp.diags([-2 * np.ones(n - 1), 4 * np.ones(n),
                  -1 * np.ones(n - 1)], [-1, 0, 1]).tocsr()
    xs = np.random.RandomState(1).randn(n)
    b = A @ xs
    x, info = gmres(A, b, jacobi_precond(A), tol=1e-8)
    assert info["residual"] < 1e-6


# ---- InitialGuessNet ----
def test_initial_guess_net_grad_flows(spd):
    A, b, _ = spd
    ig = InitialGuessNet(hidden=16, layers=2)
    loss = initial_guess_residual_loss(ig, A, b)
    loss.backward()
    g = sum(p.grad.norm().item() for p in ig.parameters()
            if p.grad is not None)
    assert g > 1e-8


def test_initial_guess_net_predict_shape(spd):
    A, b, _ = spd
    ig = InitialGuessNet(hidden=16, layers=2)
    x0 = ig.predict_x0(A, b)
    assert x0.shape == b.shape and np.all(np.isfinite(x0))


def test_initial_guess_training_reduces_residual(spd):
    A, b, _ = spd
    ig = InitialGuessNet(hidden=32, layers=2)
    opt = torch.optim.Adam(ig.parameters(), lr=1e-3)
    l0 = initial_guess_residual_loss(ig, A, b).item()
    for _ in range(40):
        opt.zero_grad()
        loss = initial_guess_residual_loss(ig, A, b)
        loss.backward()
        opt.step()
    l1 = initial_guess_residual_loss(ig, A, b).item()
    assert l1 < l0


# ---- MethodSelector ----
def test_matrix_signature_dim(spd):
    A, _, _ = spd
    s = matrix_signature(A)
    assert s.shape == (5,) and np.all(np.isfinite(s))


def test_method_selector_returns_valid_label(spd):
    A, _, _ = spd
    sel = MethodSelector()
    assert sel.select(A) in MethodSelector.LABELS


def test_method_selector_can_learn():
    sel = MethodSelector()
    # synthetic separable signal: feature 0 decides the class
    X = torch.randn(60, 5)
    y = (X[:, 0] > 0).long()  # 2 of 3 classes
    opt = torch.optim.Adam(sel.parameters(), lr=1e-2)
    lf = torch.nn.CrossEntropyLoss()
    for _ in range(150):
        opt.zero_grad()
        loss = lf(sel(X), y)
        loss.backward()
        opt.step()
    acc = (sel(X).argmax(1) == y).float().mean().item()
    assert acc > 0.8

"""AIK (Adaptive Inexact Krylov) 单元测试.

测试 aik_krylov.py 中的:
    - derive_aik_params: 从谱界推导 FCG 超参数
    - aik_fcg: 截断 Flexible CG 求解器
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pytest
import scipy.sparse as sp

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from src.aik_krylov import derive_aik_params, aik_fcg, aik_fgmres


class TestAIKFGMRES:
    """非 SPD FGMRES 路径覆盖."""

    def _nonsym(self, n=200):
        e = np.ones(n)
        A = sp.diags([-2 * e[:-1], 4 * e, -1 * e[:-1]],
                     [-1, 0, 1]).tocsr()
        rng = np.random.RandomState(1)
        x_true = rng.randn(n)
        return A, A @ x_true, x_true

    def test_converges_on_nonsymmetric(self):
        A, b, x_true = self._nonsym()
        assert abs(A - A.T).max() > 0
        x, info = aik_fgmres(A, b, lambda r, e: r / A.diagonal(),
                             c=1e-3, C=4.0, tol=1e-8, restart=30)
        assert info["residual"] < 1e-7
        assert (np.linalg.norm(x - x_true)
                / np.linalg.norm(x_true)) < 1e-6

    def test_return_structure(self):
        A, b, _ = self._nonsym(120)
        x, info = aik_fgmres(A, b, lambda r, e: r / A.diagonal(),
                             c=1e-3, C=4.0, tol=1e-8)
        for k in ("iters", "residual", "history", "k_max_predicted",
                  "restart", "inner_vcycles", "operational_bound"):
            assert k in info, f"missing key {k}"
        assert x.shape == b.shape
        assert info["inner_vcycles"] >= info["iters"] >= 0
        assert set(info["certificate"]) >= {"c", "C", "ratio"}

    def test_restart_parameter_respected(self):
        A, b, _ = self._nonsym(150)
        Minv = lambda r, e: r / A.diagonal()
        _, i1 = aik_fgmres(A, b, Minv, c=1e-3, C=4.0,
                           tol=1e-10, restart=10)
        _, i2 = aik_fgmres(A, b, Minv, c=1e-3, C=4.0,
                           tol=1e-10, restart=50)
        assert i1["restart"] == 10 and i2["restart"] == 50
        assert i1["residual"] < 1e-3 and i2["residual"] < 1e-3

    def test_k_max_override(self):
        A, b, _ = self._nonsym(80)
        _, info = aik_fgmres(A, b, lambda r, e: r / A.diagonal(),
                             c=1e-3, C=4.0, tol=1e-12,
                             k_max_override=2, restart=5)
        assert info["k_max_predicted"] == 2
        assert info["iters"] <= 2


# ============================================================
# derive_aik_params
# ============================================================

class TestDeriveAIKParams:
    def test_basic_output_keys(self):
        params = derive_aik_params(c=0.1, C=10.0, tol=1e-8)
        assert "k_max" in params
        assert "trunc" in params
        assert "eta_0" in params

    def test_well_conditioned(self):
        params = derive_aik_params(c=0.5, C=2.0, tol=1e-8)
        assert params["k_max"] > 0
        assert params["k_max"] < 200
        assert params["trunc"] >= 5

    def test_ill_conditioned_more_iters(self):
        p_good = derive_aik_params(c=0.5, C=2.0, tol=1e-8)
        p_bad = derive_aik_params(c=0.01, C=100.0, tol=1e-8)
        assert p_bad["k_max"] > p_good["k_max"]

    def test_tighter_tol_more_iters(self):
        p_loose = derive_aik_params(c=0.1, C=10.0, tol=1e-6)
        p_tight = derive_aik_params(c=0.1, C=10.0, tol=1e-10)
        assert p_tight["k_max"] > p_loose["k_max"]

    def test_eta_0_bounded(self):
        params = derive_aik_params(c=0.1, C=10.0, tol=1e-8)
        assert 0 < params["eta_0"] <= 0.5


# ============================================================
# aik_fcg solver
# ============================================================

def make_poisson_1d(n):
    diag = 2.0 * np.ones(n)
    off = -1.0 * np.ones(n - 1)
    A = sp.diags([off, diag, off], [-1, 0, 1], format="csr")
    return A


class TestAIKFCG:
    def test_exact_preconditioner(self):
        """With exact preconditioner, should converge in 1 iteration."""
        n = 50
        A = make_poisson_1d(n)
        b = np.random.RandomState(42).randn(n)

        def M_inv(r, eta):
            return sp.linalg.spsolve(A.tocsc(), r)

        x, info = aik_fcg(A, b, M_inv, c=1.0, C=1.0, tol=1e-10)
        assert info["iters"] <= 2
        assert np.linalg.norm(b - A @ x) / np.linalg.norm(b) < 1e-8

    def test_jacobi_preconditioner(self):
        """Jacobi preconditioner should converge within predicted iterations."""
        n = 100
        A = make_poisson_1d(n)
        b = np.ones(n)
        D_inv = 1.0 / A.diagonal()

        def M_inv(r, eta):
            return 0.6 * D_inv * r

        # Jacobi on Poisson 1D: eigenvalues of M^{-1}A in (0, 2)
        x, info = aik_fcg(A, b, M_inv, c=1e-3, C=2.0, tol=1e-8)
        rel_res = np.linalg.norm(b - A @ x) / np.linalg.norm(b)
        assert rel_res < 1e-7
        assert info["iters"] > 0
        assert "k_max_predicted" in info

    def test_convergence_2d_poisson(self):
        """Test on 2D Poisson with Jacobi — should converge."""
        n = 16
        N = n * n
        import pyamg
        A = pyamg.gallery.poisson((n, n), format="csr")
        b = np.random.RandomState(7).randn(N)
        D_inv = 1.0 / A.diagonal()

        def M_inv(r, eta):
            return D_inv * r

        x, info = aik_fcg(A, b, M_inv, c=0.05, C=2.0, tol=1e-6)
        rel_res = np.linalg.norm(b - A @ x) / np.linalg.norm(b)
        assert rel_res < 1e-5
        assert info["residual"] < 1e-5

    def test_output_structure(self):
        """Check returned info dict has expected keys."""
        n = 30
        A = make_poisson_1d(n)
        b = np.ones(n)
        D_inv = 1.0 / A.diagonal()

        def M_inv(r, eta):
            return D_inv * r

        x, info = aik_fcg(A, b, M_inv, c=0.3, C=1.5, tol=1e-6)
        assert "iters" in info
        assert "residual" in info
        assert "k_max_predicted" in info
        assert "trunc" in info
        assert "history" in info
        assert len(info["history"]) > 0

    def test_zero_rhs(self):
        """Zero RHS should return zero solution immediately."""
        n = 20
        A = make_poisson_1d(n)
        b = np.zeros(n)

        def M_inv(r, eta):
            return r * 0.5

        x, info = aik_fcg(A, b, M_inv, c=0.5, C=1.5, tol=1e-8)
        assert np.allclose(x, 0)
        assert info["iters"] == 0

    def test_with_amg_vcycle(self):
        """Integration test: AIK + real AMG V-cycle."""
        from src.amg_solver import AISolver
        import pyamg

        n = 16
        A = pyamg.gallery.poisson((n, n), format="csr")
        b = np.random.RandomState(99).randn(n * n)

        solver = AISolver(model=None, tol=1e-8, max_iter=200)
        solver.setup(A)

        def M_inv(r, eta):
            return solver.v_cycle_apply(r)

        x, info = aik_fcg(A, b, M_inv, c=0.1, C=5.0, tol=1e-8)
        rel_res = np.linalg.norm(b - A @ x) / np.linalg.norm(b)
        assert rel_res < 1e-7

    def test_solve_certified_integration(self):
        """Full SC-NAMG pipeline: AISolver.solve_certified."""
        from src.amg_solver import AISolver
        import pyamg

        n = 16
        A = pyamg.gallery.poisson((n, n), format="csr")
        b = np.random.RandomState(11).randn(n * n)

        solver = AISolver(model=None, tol=1e-8, max_iter=200)
        solver.setup(A)
        x, cert = solver.solve_certified(b, tol=1e-8, conf=0.95)

        rel_res = np.linalg.norm(b - A @ x) / np.linalg.norm(b)
        assert rel_res < 1e-7
        assert "c" in cert
        assert "C" in cert
        assert cert["k_used"] > 0
        assert cert["final_residual"] < 1e-7


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

"""Phase 4 数值验证单元测试.

验证 SC-NAMG 端到端保证:
    - 收敛保证 (k ≤ k_max)
    - 精度保证 (residual ≤ tol)
    - 谱界有效性 (OSC bounds cover true spectrum)
    - 多矩阵一致性
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pytest
import scipy.sparse as sp
import scipy.sparse.linalg as spla

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from src.amg_solver import AISolver, gauss_seidel
import src.amg_solver as _amg


class TestNumbaGaussSeidel:
    """numba JIT GS 核: 正确性 + 就地语义 + 纯 Python 一致性."""

    def _poisson1d(self, n=120):
        e = np.ones(n)
        A = sp.diags([-e[:-1], 2 * e, -e[:-1]], [-1, 0, 1]).tocsr()
        rng = np.random.RandomState(0)
        x_true = rng.randn(n)
        return A, A @ x_true

    def test_numba_kernel_present(self):
        # numba should be available in the pinned env
        assert _amg._HAVE_NUMBA is True

    def test_reduces_residual_and_inplace(self):
        A, b = self._poisson1d()
        x = np.zeros(A.shape[0])
        r0 = np.linalg.norm(b - A @ x)
        out = gauss_seidel(A, x, b, iters=5, forward=True)
        assert out is x                       # in-place preserved
        assert np.linalg.norm(b - A @ x) < r0  # residual reduced

    def test_numba_matches_pure_python(self):
        A, b = self._poisson1d(100)
        x_nb = np.zeros(A.shape[0])
        gauss_seidel(A, x_nb, b, iters=8, forward=True)

        # force the pure-Python fallback path
        orig = _amg._HAVE_NUMBA
        _amg._HAVE_NUMBA = False
        try:
            x_py = np.zeros(A.shape[0])
            gauss_seidel(A, x_py, b, iters=8, forward=True)
        finally:
            _amg._HAVE_NUMBA = orig

        assert np.allclose(x_nb, x_py, atol=1e-10)

    def test_forward_backward_differ(self):
        A, b = self._poisson1d(60)
        xf = np.zeros(A.shape[0]); gauss_seidel(A, xf, b, 1, True)
        xb = np.zeros(A.shape[0]); gauss_seidel(A, xb, b, 1, False)
        assert not np.allclose(xf, xb)


from src.spectral_certificate import certify_amg_solver


def make_poisson_2d(n):
    import pyamg
    return pyamg.gallery.poisson((n, n), format="csr")


class TestConvergenceGuarantee:
    """V1: SC-NAMG converges within k_max_predicted iterations."""

    @pytest.mark.parametrize("n", [8, 16, 32])
    def test_poisson_2d_within_bound(self, n):
        A = make_poisson_2d(n)
        b = np.random.RandomState(42).randn(A.shape[0])
        solver = AISolver(model=None, tol=1e-8, max_iter=200)
        solver.setup(A)
        x, cert = solver.solve_certified(b, tol=1e-8, conf=0.95)
        assert cert["k_used"] <= cert["k_max_predicted"]

    def test_anisotropic_within_bound(self):
        import pyamg
        stencil = pyamg.gallery.diffusion_stencil_2d(epsilon=0.01, theta=np.pi / 6)
        A = pyamg.gallery.stencil_grid(stencil, (16, 16), format="csr")
        b = np.random.RandomState(7).randn(A.shape[0])
        solver = AISolver(model=None, tol=1e-8, max_iter=500)
        solver.setup(A)
        x, cert = solver.solve_certified(b, tol=1e-8, conf=0.95)
        assert cert["k_used"] <= cert["k_max_predicted"]


class TestPrecisionGuarantee:
    """V2: Final residual meets tolerance."""

    @pytest.mark.parametrize("tol", [1e-6, 1e-8, 1e-10])
    def test_meets_tolerance(self, tol):
        A = make_poisson_2d(16)
        b = np.random.RandomState(11).randn(A.shape[0])
        solver = AISolver(model=None, tol=tol, max_iter=500)
        solver.setup(A)
        x, cert = solver.solve_certified(b, tol=tol, conf=0.95)
        rel_res = np.linalg.norm(b - A @ x) / np.linalg.norm(b)
        assert rel_res < tol * 10

    def test_zero_rhs(self):
        A = make_poisson_2d(8)
        b = np.zeros(A.shape[0])
        solver = AISolver(model=None, tol=1e-8, max_iter=200)
        solver.setup(A)
        x, cert = solver.solve_certified(b, tol=1e-8)
        assert np.allclose(x, 0, atol=1e-12)


class TestSpectralBoundsValidity:
    """V3: OSC spectral bounds cover the true eigenvalue range."""

    def test_coverage_poisson_small(self):
        n = 8
        A = make_poisson_2d(n)
        N = A.shape[0]
        solver = AISolver(model=None, tol=1e-8, max_iter=200)
        solver.setup(A)

        cert = solver.certify(m=20, n_probes=10, conf=0.95, adaptive=True)
        c_osc, C_osc = cert["c"], cert["C"]

        # Ground truth: build M^{-1}A explicitly
        MA_cols = []
        for i in range(N):
            e_i = np.zeros(N)
            e_i[i] = 1.0
            MA_cols.append(solver.v_cycle_apply(A @ e_i))
        MA = np.column_stack(MA_cols)
        MA = 0.5 * (MA + MA.T)
        eigs = np.linalg.eigvalsh(MA)
        eigs = eigs[eigs > 1e-12]

        lam_min = eigs.min()
        lam_max = eigs.max()

        # OSC should provide conservative bounds
        assert c_osc <= lam_min * 1.2, f"c_osc={c_osc:.6f} > lam_min={lam_min:.6f}"
        assert C_osc >= lam_max * 0.8, f"C_osc={C_osc:.6f} < lam_max={lam_max:.6f}"

    def test_bounds_positive(self):
        A = make_poisson_2d(12)
        solver = AISolver(model=None, tol=1e-8, max_iter=200)
        solver.setup(A)
        cert = solver.certify(m=20, n_probes=10, conf=0.95)
        assert cert["c"] > 0
        assert cert["C"] > cert["c"]

    def test_condition_number_reasonable(self):
        A = make_poisson_2d(16)
        solver = AISolver(model=None, tol=1e-8, max_iter=200)
        solver.setup(A)
        cert = solver.certify(m=20, n_probes=10, conf=0.95)
        kappa = cert["C"] / cert["c"]
        # For well-preconditioned Poisson, kappa should be modest
        assert kappa < 50, f"kappa={kappa:.1f} seems too large for preconditioned Poisson"


class TestMultiMatrixConsistency:
    """V4: SC-NAMG is consistent across different problems."""

    def test_iteration_count_monotone_with_size(self):
        """Larger problems may need more iterations, but not drastically more."""
        iters = []
        for n in [8, 16, 32]:
            A = make_poisson_2d(n)
            b = np.ones(A.shape[0])
            solver = AISolver(model=None, tol=1e-8, max_iter=200)
            solver.setup(A)
            x, cert = solver.solve_certified(b, tol=1e-8)
            iters.append(cert["k_used"])
        # Iterations should not grow dramatically (h-independent for good AMG)
        assert max(iters) <= 3 * min(iters), f"iterations vary too much: {iters}"

    def test_sc_namg_matches_pcg_iterations(self):
        """SC-NAMG should use similar iterations as standard PCG (same preconditioner)."""
        A = make_poisson_2d(16)
        b = np.random.RandomState(0).randn(A.shape[0])
        solver = AISolver(model=None, tol=1e-8, max_iter=200)
        solver.setup(A)

        # SC-NAMG
        x_sc, cert = solver.solve_certified(b, tol=1e-8)
        k_sc = cert["k_used"]

        # Standard PCG
        n = A.shape[0]
        M = spla.LinearOperator((n, n), matvec=solver.v_cycle_apply, dtype=np.float64)
        iters_pcg = [0]
        def cb(xk): iters_pcg[0] += 1
        x_pcg, _ = spla.cg(A, b.astype(np.float64), M=M, rtol=1e-8, maxiter=200, callback=cb)

        # Should be within factor of 2
        assert abs(k_sc - iters_pcg[0]) <= max(k_sc, iters_pcg[0]), \
            f"SC-NAMG k={k_sc} vs PCG k={iters_pcg[0]}"


class TestEdgeCases:
    """Edge cases that might break the pipeline."""

    def test_very_small_matrix(self):
        """4x4 Poisson — only 1 level, direct solve."""
        A = make_poisson_2d(2)  # 4 unknowns
        b = np.array([1.0, 2.0, 3.0, 4.0])
        solver = AISolver(model=None, tol=1e-8, max_iter=200, min_coarse=3)
        solver.setup(A)
        x, cert = solver.solve_certified(b, tol=1e-8)
        assert np.linalg.norm(b - A @ x) / np.linalg.norm(b) < 1e-7

    def test_repeated_solves_same_result(self):
        """Same problem solved twice should give same answer."""
        A = make_poisson_2d(8)
        b = np.ones(A.shape[0])
        solver = AISolver(model=None, tol=1e-8, max_iter=200)
        solver.setup(A)
        x1, c1 = solver.solve_certified(b, tol=1e-8)
        x2, c2 = solver.solve_certified(b, tol=1e-8)
        assert np.allclose(x1, x2, rtol=1e-6)

    def test_random_rhs(self):
        """Random RHS should also converge."""
        A = make_poisson_2d(16)
        for seed in range(5):
            b = np.random.RandomState(seed).randn(A.shape[0])
            solver = AISolver(model=None, tol=1e-8, max_iter=200)
            solver.setup(A)
            x, cert = solver.solve_certified(b, tol=1e-8)
            rel_res = np.linalg.norm(b - A @ x) / np.linalg.norm(b)
            assert rel_res < 1e-7, f"seed={seed}: res={rel_res:.2e}"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

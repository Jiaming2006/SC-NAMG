# SuiteSparse matrix cache

This directory holds Matrix-Market (`.mtx`) files for the real engineering
matrices used by `experiments/exp5_paper/exp4_benchmark`.

It is intentionally empty in the repo — the matrices are **fetched on
demand** (network required), not vendored:

```bash
python -m ai_amg.bench.download_suitesparse            # default 3
python -m ai_amg.bench.download_suitesparse --list     # all 20 known
python -m ai_amg.bench.download_suitesparse bcsstk16 nasa2910 s3rmt3m3 \
        nos7 1138_bus ex15 sherman5 msc23052 bcsstk17 bcsstk27
```

`ai_amg/bench/loaders.py` reads `{name}.mtx` from here automatically.
Until a matrix is downloaded, `exp4_benchmark` records it as a skipped
entry (by design — not a code defect).

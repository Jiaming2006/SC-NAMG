# SC-NAMG Testbed

## Hardware
- **CPU**: Apple Silicon (arm64)
- **OS**: macOS 26.4.1 (Darwin, arm64)
- **Memory**: System default

## Software
| Package | Version |
|---------|---------|
| Python | 3.13.5 (Anaconda) |
| NumPy | 2.1.3 |
| SciPy | 1.15.3 |
| PyAMG | 5.3.0 |
| PyTorch | 2.10.0 |
| PyG (torch_geometric) | 2.7.0 |

## Benchmark Matrix Set

### Built-in (pyamg.gallery)
- Poisson 2D: n = {16, 32, 64, 128, 256, 512}
- Poisson 3D: n = {8, 16, 32, 64}
- Anisotropic 2D (eps=0.01, theta=pi/8): n = {16, 32, 64, 128, 256}

### SuiteSparse (Phase 0 target: 20 matrices)
See execution plan Appendix A for the full list.

## Reproducibility
```bash
pip install numpy==2.1.3 scipy==1.15.3 pyamg==5.3.0
pip install torch==2.10.0 torch_geometric==2.7.0

# Generate baselines
python ai_amg/bench/generate_baselines.py

# Run Phase 1 experiment
python experiments/exp1_certificate/run.py

# Run Phase 2 experiment
python experiments/exp2_aik/run.py
```

"""端到端示例: 小规模上跑通整条链路.

即使没有训练好的 GNN, 也能跑 (自动回退到经典 RS 分裂).
"""
from __future__ import annotations
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import numpy as np

from src import matrix_gen
from src.amg_solver import AISolver
from src.utils import pretty_history


def demo(kind: str = "poisson_2d", n: int = 64):
    print(f"\n===== {kind}, n={n} =====")
    A = matrix_gen.generate(kind, n)
    b = matrix_gen.random_rhs(A, seed=0)

    solver = AISolver(
        model=None,              # None -> 经典 RS 分裂 (baseline)
        max_levels=8,
        min_coarse=50,
        tol=1e-8,
        max_iter=60,
        smoother_iters=2,
        verbose=False,
    ).setup(A)

    x, hist = solver.solve(b)
    print(pretty_history(hist))
    print(f"||Ax - b|| = {np.linalg.norm(A @ x - b):.3e}")


if __name__ == "__main__":
    demo("poisson_2d", n=48)
    demo("anisotropic_2d", n=32)
    demo("random_spd", n=400)

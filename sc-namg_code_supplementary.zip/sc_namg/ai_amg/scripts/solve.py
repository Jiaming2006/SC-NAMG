"""使用 (已训练好的) GNN 求解任意 Ax=b.

两种矩阵来源:
  1) 内置生成: --gen poisson_2d|poisson_3d|anisotropic_2d|random_spd --n <size>
  2) 加载文件: --mat path/to/A.mtx  (或 .npz)

示例:
    # 生成 poisson_2d 128x128 并求解
    python scripts/solve.py --gen poisson_2d --n 128 --ckpt checkpoints/gnn.pt

    # 加载自定义矩阵求解
    python scripts/solve.py --mat my_mat.mtx --ckpt checkpoints/gnn.pt --tol 1e-10

    # 不训练直接用经典 RS (baseline) 比较
    python scripts/solve.py --gen poisson_2d --n 128 --no-model
"""
from __future__ import annotations
import argparse
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from src import matrix_gen
from src.amg_solver import AISolver
from src.utils import load_yaml, pretty_history


def build_matrix(args) -> "sp.csr_matrix":
    if args.mat is not None:
        return matrix_gen.load_matrix(args.mat)
    if args.gen is None:
        raise SystemExit("请指定 --gen <type> --n <size> 或 --mat <file>")
    kw = {}
    if args.gen == "anisotropic_2d":
        kw = dict(epsilon=args.epsilon, theta=args.theta)
    if args.gen == "random_spd":
        kw = dict(density=args.density, seed=args.seed)
    return matrix_gen.generate(args.gen, args.n, **kw)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=str(ROOT / "configs" / "default.yaml"))
    ap.add_argument("--ckpt", default=None, help="GNN 权重. 未给时回退经典 RS")
    ap.add_argument("--no-model", action="store_true",
                    help="强制不加载模型, 只用经典 AMG")

    # 矩阵来源
    ap.add_argument("--mat", default=None, help=".mtx 或 .npz 文件")
    ap.add_argument("--gen", default=None,
                    choices=["poisson_2d", "poisson_3d", "anisotropic_2d", "random_spd"])
    ap.add_argument("--n", type=int, default=64)
    ap.add_argument("--epsilon", type=float, default=0.01)
    ap.add_argument("--theta", type=float, default=0.0)
    ap.add_argument("--density", type=float, default=0.01)
    ap.add_argument("--seed", type=int, default=0)

    # 求解器极限
    ap.add_argument("--tol", type=float, default=None)
    ap.add_argument("--max-iter", type=int, default=None)
    ap.add_argument("--max-levels", type=int, default=None)
    ap.add_argument("--min-coarse", type=int, default=None)

    # SC-NAMG OSC-monitored solve
    ap.add_argument("--certified", action="store_true",
                    help="Use SC-NAMG path (OSC + AIK)")
    ap.add_argument("--conf", type=float, default=0.95,
                    help="OSC confidence level")

    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args()

    cfg = load_yaml(args.config)["solver"]
    # 命令行覆盖
    solver_kwargs = dict(
        max_levels=args.max_levels or cfg["max_levels"],
        min_coarse=args.min_coarse or cfg["min_coarse"],
        tol=args.tol or cfg["tol"],
        max_iter=args.max_iter or cfg["max_iter"],
        smoother_iters=cfg["smoother_iters"],
        cf_threshold=cfg["cf_threshold"],
        verbose=args.verbose,
    )

    A = build_matrix(args)
    print(f"[solve] A shape={A.shape}, nnz={A.nnz}")

    b = matrix_gen.random_rhs(A, seed=args.seed)

    model = None
    if not args.no_model and args.ckpt:
        from src.gnn_trainer import load_model   # lazy import (依赖 torch)
        model = load_model(args.ckpt)
        print(f"[solve] 已加载 GNN 权重 {args.ckpt}")

    solver = AISolver(model=model, **solver_kwargs).setup(A)

    if args.certified:
        x, cert = solver.solve_certified(b, tol=solver_kwargs["tol"],
                                          conf=args.conf, verbose=args.verbose)
        print("\n========= SC-NAMG Certified Solve =========")
        print(f"  c={cert['c']:.6f}, C={cert['C']:.4f}, ratio={cert['ratio']:.2f}")
        print(f"  k_used={cert['k_used']}, k_max_predicted={cert['k_max_predicted']}")
        print(f"  final_residual={cert['final_residual']:.3e}")
        print(f"  time_osc={cert['time_osc']:.3f}s, time_solve={cert['time_solve']:.3f}s")
    else:
        x, hist = solver.solve(b)
        print("\n========= 求解汇总 =========")
        print(pretty_history(hist))


if __name__ == "__main__":
    main()

"""生成训练集.

用法:
    python scripts/generate_dataset.py --config configs/default.yaml --out data/train.pt
或只覆盖少量参数:
    python scripts/generate_dataset.py --out data/train.pt --n-samples 300
"""
from __future__ import annotations
import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from src.gnn_dataset import SamplingConfig, build_dataset, save_dataset
from src.utils import load_yaml


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=str(ROOT / "configs" / "default.yaml"))
    ap.add_argument("--out", default=str(ROOT / "data" / "train.pt"))
    ap.add_argument("--n-samples", type=int, default=None,
                    help="覆盖配置中的样本数")
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    cfg_all = load_yaml(args.config)
    ds_cfg = cfg_all["dataset"]

    cfg = SamplingConfig(
        types=ds_cfg["types"],
        n_samples=args.n_samples or ds_cfg["n_samples"],
        strength_theta=ds_cfg.get("strength_theta", 0.25),
    )
    samples = build_dataset(cfg, seed=args.seed, verbose=True)
    save_dataset(samples, args.out)
    print(f"[done] {len(samples)} 个样本 -> {args.out}")


if __name__ == "__main__":
    main()

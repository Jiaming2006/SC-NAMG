"""训练 GNN.

用法:
    python scripts/train_model.py --data data/train.pt --out checkpoints/gnn.pt --epochs 50
"""
from __future__ import annotations
import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from src.gnn_dataset import load_dataset
from src.gnn_trainer import train
from src.utils import load_yaml


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=str(ROOT / "configs" / "default.yaml"))
    ap.add_argument("--data", required=True)
    ap.add_argument("--out", default=str(ROOT / "checkpoints" / "gnn.pt"))
    ap.add_argument("--epochs", type=int, default=None)
    ap.add_argument("--device", default=None)
    args = ap.parse_args()

    cfg = load_yaml(args.config)
    tr = cfg["train"]
    md = cfg["model"]

    samples = load_dataset(args.data)
    if not samples:
        raise RuntimeError("空数据集, 请先跑 generate_dataset.py")
    print(f"[train] 加载 {len(samples)} 个样本")

    train(
        samples,
        epochs=args.epochs or tr["epochs"],
        lr=tr["lr"],
        weight_decay=tr["weight_decay"],
        batch_size=tr["batch_size"],
        val_split=tr["val_split"],
        pos_weight=tr["pos_weight"],
        hidden=md["hidden_dim"],
        layers=md["num_layers"],
        conv=md["conv_type"],
        dropout=md["dropout"],
        device=args.device,
        seed=tr["seed"],
        out_ckpt=args.out,
        verbose=True,
    )


if __name__ == "__main__":
    main()

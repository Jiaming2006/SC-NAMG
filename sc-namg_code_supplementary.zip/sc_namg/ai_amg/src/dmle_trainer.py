"""DMLE 训练器: 用可微多层能量损失训练 GNN.

替代 gnn_trainer.py 中的 BCE 损失, 直接优化 V-cycle 收敛率.

用法:
    python -m src.dmle_trainer --epochs 100 --n-matrices 20 --out checkpoints/gnn_dmle.pt
"""
from __future__ import annotations

import argparse
import random
import sys
import time
from pathlib import Path
from typing import List, Tuple

import numpy as np
import scipy.sparse as sp
import torch
import torch.nn as nn

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from src.gnn_model import CFClassifier
from src.graph_features import to_pyg_data
from src.dmle_loss import (dmle_loss_single, dmle_loss_batch,
                           dmle_loss_batch_multilevel, tau_schedule)
from src import matrix_gen


def generate_training_matrices(n_matrices: int = 30,
                               sizes: list = None,
                               seed: int = 42) -> List[Tuple[sp.csr_matrix, object]]:
    """Generate diverse training matrices with PyG data objects.

    Includes hard anisotropic + jump_diffusion for GNN differentiation from RS.
    """
    rng = np.random.RandomState(seed)
    if sizes is None:
        sizes = [16, 24, 32, 48, 64]

    samples = []
    for i in range(n_matrices):
        n = sizes[i % len(sizes)]
        kind = rng.randint(0, 5)
        if kind == 0:
            A = matrix_gen.generate("poisson_2d", n)
        elif kind == 1:
            eps = 10 ** rng.uniform(-4, -1)
            theta = rng.uniform(0, np.pi / 2)
            A = matrix_gen.generate("anisotropic_2d", n, epsilon=eps, theta=theta)
        elif kind == 2:
            n3 = max(n // 3, 4)
            A = matrix_gen.generate("poisson_3d", n3)
        elif kind == 3:
            contrast = 10 ** rng.uniform(2, 6)
            n_inc = rng.randint(3, 8)
            A = matrix_gen.jump_diffusion_2d(n, contrast=contrast,
                                             n_inclusions=n_inc, seed=seed + i)
        else:
            n_rnd = min(n * n, 400)
            A = matrix_gen.generate("random_spd", n_rnd, density=0.02, seed=seed + i)

        data = to_pyg_data(A, labels=None)
        samples.append((A, data))

    return samples


def train_dmle(
    n_matrices: int = 30,
    epochs: int = 100,
    lr: float = 5e-4,
    weight_decay: float = 1e-4,
    batch_size: int = 4,
    tau_start: float = 2.0,
    tau_end: float = 0.1,
    lam_rho: float = 1.0,
    lam_complex: float = 0.1,
    lam_smooth: float = 0.05,
    lam_kappa: float = 0.1,
    m_lanczos: int = 12,
    n_power: int = 15,
    multilevel: bool = False,
    ml_max_levels: int = 3,
    ml_min_coarse: int = 40,
    hidden: int = 64,
    layers: int = 3,
    conv: str = "gatv2",
    dropout: float = 0.1,
    sizes: list = None,
    device: str | None = None,
    seed: int = 42,
    out_ckpt: str | None = None,
    verbose: bool = True,
) -> Tuple[CFClassifier, list]:
    """Train GNN with DMLE loss.

    Returns (model, history).
    """
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    device = device or ("cuda" if torch.cuda.is_available() else "cpu")

    if verbose:
        print(f"[DMLE] Generating {n_matrices} training matrices...")
    samples = generate_training_matrices(n_matrices, sizes=sizes, seed=seed)
    if verbose:
        print(f"[DMLE] Generated {len(samples)} samples, sizes: {[A.shape[0] for A, _ in samples[:5]]}...")

    # Split train/val
    n_val = max(1, int(0.15 * len(samples)))
    indices = list(range(len(samples)))
    random.shuffle(indices)
    val_idx = set(indices[:n_val])
    train_samples = [samples[i] for i in range(len(samples)) if i not in val_idx]
    val_samples = [samples[i] for i in val_idx]

    model = CFClassifier(hidden=hidden, layers=layers, conv=conv, dropout=dropout).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs, eta_min=lr * 0.01)

    history = []
    best_val_loss = float("inf")
    best_state = None

    for ep in range(1, epochs + 1):
        tau = tau_schedule(ep - 1, epochs, tau_start, tau_end)
        model.train()

        # Shuffle and batch
        random.shuffle(train_samples)
        epoch_loss = 0.0
        epoch_rho = 0.0
        n_batches = 0

        for i in range(0, len(train_samples), batch_size):
            batch = train_samples[i:i + batch_size]
            if multilevel:
                loss, infos = dmle_loss_batch_multilevel(
                    model, batch, tau=tau,
                    lam_rho=lam_rho, lam_complex=lam_complex,
                    lam_smooth=lam_smooth, lam_kappa=lam_kappa,
                    n_power=n_power, m_lanczos=m_lanczos,
                    max_levels=ml_max_levels, min_coarse=ml_min_coarse,
                    device=device,
                )
            else:
                loss, infos = dmle_loss_batch(
                    model, batch, tau=tau,
                    lam_rho=lam_rho, lam_complex=lam_complex,
                    lam_smooth=lam_smooth, n_power=n_power, device=device,
                )
            opt.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step()

            epoch_loss += loss.item()
            epoch_rho += np.mean([inf["rho"] for inf in infos])
            n_batches += 1

        scheduler.step()
        train_loss = epoch_loss / max(n_batches, 1)
        train_rho = epoch_rho / max(n_batches, 1)

        # Validation
        model.eval()
        with torch.no_grad():
            val_loss_sum = 0.0
            val_rho_sum = 0.0
            for A_csr, data in val_samples:
                if multilevel:
                    loss, vinfos = dmle_loss_batch_multilevel(
                        model, [(A_csr, data)], tau=tau,
                        lam_rho=lam_rho, lam_complex=lam_complex,
                        lam_smooth=lam_smooth, lam_kappa=lam_kappa,
                        n_power=n_power, m_lanczos=m_lanczos,
                        max_levels=ml_max_levels, min_coarse=ml_min_coarse,
                        device=device,
                    )
                    info = vinfos[0]
                else:
                    x = data.x.to(device)
                    edge_index = data.edge_index.to(device)
                    logits = model(x, edge_index)
                    loss, info = dmle_loss_single(A_csr, logits, tau=tau, training=False)
                val_loss_sum += loss.item()
                val_rho_sum += info["rho"]
        val_loss = val_loss_sum / max(len(val_samples), 1)
        val_rho = val_rho_sum / max(len(val_samples), 1)

        entry = {
            "epoch": ep, "tau": tau,
            "train_loss": train_loss, "train_rho": train_rho,
            "val_loss": val_loss, "val_rho": val_rho,
            "lr": scheduler.get_last_lr()[0],
        }
        history.append(entry)

        if verbose and (ep <= 5 or ep % 10 == 0 or ep == epochs):
            print(f"[ep {ep:03d}] tau={tau:.3f} train_loss={train_loss:.4f} "
                  f"rho={train_rho:.4f} val_loss={val_loss:.4f} val_rho={val_rho:.4f}",
                  flush=True)

        if val_loss < best_val_loss:
            best_val_loss = val_loss
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            # Interrupt-safe: persist best checkpoint immediately
            if out_ckpt:
                out = Path(out_ckpt)
                out.parent.mkdir(parents=True, exist_ok=True)
                torch.save({
                    "state_dict": best_state,
                    "cfg": {"hidden": hidden, "layers": layers,
                            "conv": conv, "dropout": dropout},
                    "loss_type": "dmle",
                    "best_val_loss": best_val_loss,
                    "history": history,
                }, out)

    if best_state is not None:
        model.load_state_dict(best_state)

    if out_ckpt:
        out = Path(out_ckpt)
        out.parent.mkdir(parents=True, exist_ok=True)
        torch.save({
            "state_dict": model.state_dict(),
            "cfg": {"hidden": hidden, "layers": layers, "conv": conv, "dropout": dropout},
            "loss_type": "dmle",
            "best_val_loss": best_val_loss,
            "history": history,
        }, out)
        if verbose:
            print(f"[DMLE] Saved checkpoint to {out}, best val_loss = {best_val_loss:.4f}")

    return model, history


def train_dmle_two_stage(
    n_matrices: int = 45,
    warmup_epochs: int = 30,
    multilevel_epochs: int = 30,
    lr: float = 5e-4,
    weight_decay: float = 1e-4,
    batch_size: int = 4,
    tau_start: float = 2.0,
    tau_end: float = 0.1,
    lam_rho: float = 1.0,
    lam_complex: float = 0.1,
    lam_smooth: float = 0.05,
    lam_kappa: float = 0.1,
    m_lanczos: int = 12,
    n_power: int = 15,
    ml_max_levels: int = 3,
    ml_min_coarse: int = 40,
    hidden: int = 64,
    layers: int = 3,
    conv: str = "gatv2",
    dropout: float = 0.1,
    sizes: list = None,
    device: str | None = None,
    seed: int = 42,
    out_ckpt: str | None = None,
    verbose: bool = True,
) -> Tuple[CFClassifier, list]:
    """Two-stage DMLE training as described in Table 6.1 of the paper.

    Stage 1: warmup_epochs under two-grid surrogate (multilevel=False)
    Stage 2: multilevel_epochs under full multi-level loss (multilevel=True)

    Returns (model, combined_history).
    """
    if verbose:
        print(f"[DMLE two-stage] Stage 1: {warmup_epochs} epochs two-grid warm-up")
    model, hist1 = train_dmle(
        n_matrices=n_matrices, epochs=warmup_epochs,
        lr=lr, weight_decay=weight_decay, batch_size=batch_size,
        tau_start=tau_start, tau_end=tau_end,
        lam_rho=lam_rho, lam_complex=lam_complex, lam_smooth=lam_smooth,
        lam_kappa=0.0,  # no kappa term in two-grid warm-up
        n_power=n_power, m_lanczos=m_lanczos,
        multilevel=False,
        ml_max_levels=ml_max_levels, ml_min_coarse=ml_min_coarse,
        hidden=hidden, layers=layers, conv=conv, dropout=dropout,
        sizes=sizes, device=device, seed=seed,
        out_ckpt=None, verbose=verbose,
    )

    if verbose:
        print(f"\n[DMLE two-stage] Stage 2: {multilevel_epochs} epochs multi-level fine-tuning")

    # Stage 2 reuses the model from stage 1 (already initialized)
    # We train with multilevel=True and lam_kappa enabled
    device = device or ("cuda" if torch.cuda.is_available() else "cpu")
    random.seed(seed + 1)
    np.random.seed(seed + 1)
    torch.manual_seed(seed + 1)

    samples = generate_training_matrices(n_matrices, sizes=sizes, seed=seed)
    n_val = max(1, int(0.15 * len(samples)))
    indices = list(range(len(samples)))
    random.shuffle(indices)
    val_idx = set(indices[:n_val])
    train_samples = [samples[i] for i in range(len(samples)) if i not in val_idx]
    val_samples = [samples[i] for i in val_idx]

    opt = torch.optim.AdamW(model.parameters(), lr=lr * 0.5, weight_decay=weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=multilevel_epochs, eta_min=lr * 0.005)

    hist2 = []
    best_val_loss = float("inf")
    best_state = None

    for ep in range(1, multilevel_epochs + 1):
        tau = tau_schedule(ep - 1, multilevel_epochs, tau_start, tau_end)
        model.train()
        random.shuffle(train_samples)
        epoch_loss = 0.0
        epoch_rho = 0.0
        n_batches = 0

        for i in range(0, len(train_samples), batch_size):
            batch = train_samples[i:i + batch_size]
            loss, infos = dmle_loss_batch_multilevel(
                model, batch, tau=tau,
                lam_rho=lam_rho, lam_complex=lam_complex,
                lam_smooth=lam_smooth, lam_kappa=lam_kappa,
                n_power=n_power, m_lanczos=m_lanczos,
                max_levels=ml_max_levels, min_coarse=ml_min_coarse,
                device=device,
            )
            opt.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step()
            epoch_loss += loss.item()
            epoch_rho += np.mean([inf["rho"] for inf in infos])
            n_batches += 1

        scheduler.step()
        train_loss = epoch_loss / max(n_batches, 1)
        train_rho = epoch_rho / max(n_batches, 1)

        model.eval()
        with torch.no_grad():
            val_loss_sum = 0.0
            val_rho_sum = 0.0
            for A_csr, data in val_samples:
                loss, vinfos = dmle_loss_batch_multilevel(
                    model, [(A_csr, data)], tau=tau,
                    lam_rho=lam_rho, lam_complex=lam_complex,
                    lam_smooth=lam_smooth, lam_kappa=lam_kappa,
                    n_power=n_power, m_lanczos=m_lanczos,
                    max_levels=ml_max_levels, min_coarse=ml_min_coarse,
                    device=device,
                )
                val_loss_sum += loss.item()
                val_rho_sum += vinfos[0]["rho"]
        val_loss = val_loss_sum / max(len(val_samples), 1)
        val_rho = val_rho_sum / max(len(val_samples), 1)

        entry = {
            "epoch": warmup_epochs + ep, "stage": 2, "tau": tau,
            "train_loss": train_loss, "train_rho": train_rho,
            "val_loss": val_loss, "val_rho": val_rho,
            "lr": scheduler.get_last_lr()[0],
        }
        hist2.append(entry)

        if verbose and (ep <= 5 or ep % 10 == 0 or ep == multilevel_epochs):
            print(f"[stage2 ep {ep:03d}] tau={tau:.3f} train_loss={train_loss:.4f} "
                  f"rho={train_rho:.4f} val_loss={val_loss:.4f} val_rho={val_rho:.4f}",
                  flush=True)

        if val_loss < best_val_loss:
            best_val_loss = val_loss
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}

    if best_state is not None:
        model.load_state_dict(best_state)

    combined_history = hist1 + hist2

    if out_ckpt:
        out = Path(out_ckpt)
        out.parent.mkdir(parents=True, exist_ok=True)
        torch.save({
            "state_dict": model.state_dict(),
            "cfg": {"hidden": hidden, "layers": layers, "conv": conv, "dropout": dropout},
            "loss_type": "dmle_two_stage",
            "best_val_loss": best_val_loss,
            "history": combined_history,
        }, out)
        if verbose:
            print(f"[DMLE two-stage] Saved to {out}, best val_loss = {best_val_loss:.4f}")

    return model, combined_history


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--epochs", type=int, default=60,
                    help="Total epochs (split evenly for two-stage, or used directly for single-stage)")
    ap.add_argument("--n-matrices", type=int, default=45)
    ap.add_argument("--batch-size", type=int, default=4)
    ap.add_argument("--lr", type=float, default=5e-4)
    ap.add_argument("--weight-decay", type=float, default=1e-4)
    ap.add_argument("--hidden", type=int, default=64)
    ap.add_argument("--layers", type=int, default=3)
    ap.add_argument("--conv", default="gatv2", choices=["gatv2", "sage", "gcn"])
    ap.add_argument("--tau-start", type=float, default=2.0)
    ap.add_argument("--tau-end", type=float, default=0.1)
    ap.add_argument("--n-power", type=int, default=15)
    ap.add_argument("--lam-kappa", type=float, default=0.1,
                    help="Weight for OSC-DMLE closed-loop kappa regularizer")
    ap.add_argument("--multilevel", action="store_true", default=False,
                    help="Use multi-level loss (single-stage)")
    ap.add_argument("--two-stage", action="store_true", default=True,
                    help="Two-stage training: warm-up + multi-level (paper default)")
    ap.add_argument("--single-stage", action="store_true", default=False,
                    help="Single-stage training (override two-stage)")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", default="checkpoints/gnn_dmle.pt")
    ap.add_argument("--device", default=None)
    ap.add_argument("--verbose", action="store_true", default=True)
    args = ap.parse_args()

    if args.single_stage:
        # Single-stage mode (backward compatible)
        train_dmle(
            n_matrices=args.n_matrices,
            epochs=args.epochs,
            batch_size=args.batch_size,
            lr=args.lr,
            weight_decay=args.weight_decay,
            hidden=args.hidden,
            layers=args.layers,
            conv=args.conv,
            tau_start=args.tau_start,
            tau_end=args.tau_end,
            n_power=args.n_power,
            lam_kappa=args.lam_kappa,
            multilevel=args.multilevel,
            seed=args.seed,
            out_ckpt=args.out,
            device=args.device,
            verbose=args.verbose,
        )
    else:
        # Two-stage mode (paper default: 30 warmup + 30 multilevel)
        warmup_ep = args.epochs // 2
        ml_ep = args.epochs - warmup_ep
        train_dmle_two_stage(
            n_matrices=args.n_matrices,
            warmup_epochs=warmup_ep,
            multilevel_epochs=ml_ep,
            lr=args.lr,
            weight_decay=args.weight_decay,
            batch_size=args.batch_size,
            tau_start=args.tau_start,
            tau_end=args.tau_end,
            lam_kappa=args.lam_kappa,
            n_power=args.n_power,
            hidden=args.hidden,
            layers=args.layers,
            conv=args.conv,
            seed=args.seed,
            out_ckpt=args.out,
            device=args.device,
            verbose=args.verbose,
        )


if __name__ == "__main__":
    main()

"""多层 AI-AMG 求解器.

核心对象:
    Level   : 保存某一层的 A, 分裂, P, R 以及粗层指针
    AISolver: setup() 自顶向下递归粗化 (多次投影), solve() 做 V-cycle

收敛控制 (对应"极限"):
    max_levels      最多投影几层
    min_coarse      粗层规模下限, 触发即改用直接求解
    tol             V-cycle 相对残差容差
    max_iter        V-cycle 最大迭代数
"""
from __future__ import annotations
import time
from dataclasses import dataclass, field
from typing import List, Optional, TYPE_CHECKING

import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla

from .graph_features import to_pyg_data
from .cf_splitting import strength_matrix, rs_splitting

if TYPE_CHECKING:    # 避免 import 时引入 torch
    from .gnn_model import CFClassifier


# ======================================================================
# 插值算子 (Classical Direct Interpolation)
# ======================================================================

def build_prolongation(A: sp.csr_matrix,
                       c_mask: np.ndarray,
                       S: sp.csr_matrix | None = None,
                       mode: str = "standard") -> sp.csr_matrix:
    """根据 C/F 分裂与强连接矩阵构造 P, shape (n, n_c).

    * C 点: P[i, c_idx[i]] = 1
    * F 点:
        - mode="direct"   : 经典直接插值, 强 F-F 连接并入对角.
        - mode="standard" : 标准插值 (Stüben). 强 F 邻居 k 的连接 a_ik
          被按比例重分配到 k 的强 C 邻居上 (即 i 的插值集), 显著提升
          各向异性问题上的插值质量.
    返回 CSR.
    """
    A = A.tocsr()
    n = A.shape[0]
    if S is None:
        S = strength_matrix(A)

    c_mask = c_mask.astype(bool)
    c_idx = -np.ones(n, dtype=np.int64)
    c_idx[c_mask] = np.arange(c_mask.sum())
    n_c = int(c_mask.sum())

    rows, cols, vals = [], [], []

    for i in range(n):
        if c_mask[i]:
            rows.append(i); cols.append(c_idx[i]); vals.append(1.0)
            continue

        a_start, a_end = A.indptr[i], A.indptr[i + 1]
        a_cols = A.indices[a_start:a_end]
        a_vals = A.data[a_start:a_end]

        s_set = set(S.indices[S.indptr[i]:S.indptr[i + 1]].tolist())

        a_ii = 0.0
        weak_sum = 0.0          # 弱连接 (并入对角)
        c_strong = {}           # 强 C 邻居 j -> a_ij  (插值集)
        f_strong = {}           # 强 F 邻居 k -> a_ik
        for k, j in enumerate(a_cols):
            v = a_vals[k]
            if j == i:
                a_ii = v
                continue
            strong = j in s_set
            if c_mask[j] and strong:
                c_strong[j] = v
            elif (not c_mask[j]) and strong:
                f_strong[j] = v
            else:
                weak_sum += v   # 弱连接 (C 或 F) 都并入对角

        if len(c_strong) == 0:
            continue

        if mode == "direct":
            denom = a_ii + weak_sum + sum(f_strong.values())
            if abs(denom) < 1e-30:
                continue
            for j, v in c_strong.items():
                rows.append(i); cols.append(c_idx[j]); vals.append(-v / denom)
            continue

        # ---- standard interpolation ----
        # numerator_j = a_ij + sum_{k in F_i^s} a_ik * a_kj / (sum_{l in C_i^s} a_kl)
        num = {j: v for j, v in c_strong.items()}
        for k, a_ik in f_strong.items():
            k_s, k_e = A.indptr[k], A.indptr[k + 1]
            k_cols = A.indices[k_s:k_e]
            k_vals = A.data[k_s:k_e]
            kpos = {int(cc): vv for cc, vv in zip(k_cols, k_vals)}
            # k 落在 i 插值集 C_i 上的连接
            denom_k = 0.0
            for j in c_strong:
                denom_k += kpos.get(j, 0.0)
            if abs(denom_k) < 1e-30:
                # k 与 i 的插值集无耦合 -> 退化为并入对角
                weak_sum += a_ik
                continue
            for j in c_strong:
                a_kj = kpos.get(j, 0.0)
                if a_kj != 0.0:
                    num[j] = num[j] + a_ik * a_kj / denom_k

        denom = a_ii + weak_sum
        if abs(denom) < 1e-30:
            continue
        for j, nj in num.items():
            if nj != 0.0:
                rows.append(i); cols.append(c_idx[j]); vals.append(-nj / denom)

    P = sp.csr_matrix((vals, (rows, cols)), shape=(n, n_c))
    return P


# ======================================================================
# 光滑子 (Gauss-Seidel)
# ======================================================================

try:
    from numba import njit

    @njit(cache=True, fastmath=True)
    def _gs_kernel(indptr, indices, data, x, b, iters, forward):
        n = x.shape[0]
        for _ in range(iters):
            if forward:
                lo, hi, step = 0, n, 1
            else:
                lo, hi, step = n - 1, -1, -1
            for i in range(lo, hi, step):
                s = indptr[i]
                e = indptr[i + 1]
                diag = 0.0
                dot = 0.0
                for k in range(s, e):
                    j = indices[k]
                    v = data[k]
                    if j == i:
                        diag = v
                    else:
                        dot += v * x[j]
                if diag != 0.0:
                    x[i] = (b[i] - dot) / diag
        return x

    _HAVE_NUMBA = True
except Exception:  # pragma: no cover
    _HAVE_NUMBA = False


def gauss_seidel(A: sp.csr_matrix, x: np.ndarray, b: np.ndarray,
                 iters: int = 1, forward: bool = True) -> np.ndarray:
    """就地 Gauss-Seidel. A 假设为 CSR. 内循环用 numba JIT (回退纯 Python)."""
    A = A.tocsr()
    if _HAVE_NUMBA:
        xw = np.ascontiguousarray(x, dtype=np.float64)
        bw = np.ascontiguousarray(b, dtype=np.float64)
        _gs_kernel(A.indptr, A.indices,
                   np.ascontiguousarray(A.data, dtype=np.float64),
                   xw, bw, int(iters), bool(forward))
        if xw is not x:                 # a copy was made -> write back in place
            x[:] = xw
        return x
    n = A.shape[0]
    indptr = A.indptr; indices = A.indices; data = A.data
    for _ in range(iters):
        order = range(n) if forward else range(n - 1, -1, -1)
        for i in order:
            s = indptr[i]; e = indptr[i + 1]
            diag = 0.0
            dot = 0.0
            for k in range(s, e):
                j = indices[k]; v = data[k]
                if j == i:
                    diag = v
                else:
                    dot += v * x[j]
            if diag != 0.0:
                x[i] = (b[i] - dot) / diag
    return x


# ======================================================================
# 求解器主类
# ======================================================================

@dataclass
class Level:
    A: sp.csr_matrix
    P: Optional[sp.csr_matrix] = None    # 本层 -> 下一粗层
    R: Optional[sp.csr_matrix] = None    # = P^T
    c_mask: Optional[np.ndarray] = None
    S: Optional[sp.csr_matrix] = None
    # 最粗层缓存 LU
    _lu: object = None


@dataclass
class SolveHistory:
    residuals: List[float] = field(default_factory=list)
    setup_time: float = 0.0
    solve_time: float = 0.0
    levels: List[int] = field(default_factory=list)    # 每层规模

    def relative(self) -> np.ndarray:
        r = np.asarray(self.residuals)
        return r / r[0] if len(r) else r


def _is_approximately_symmetric(A: sp.csr_matrix, n_check: int = 10, tol: float = 1e-6) -> bool:
    """Probe approximate symmetry of A with random vectors; does NOT guarantee SPD.

    Checks: (1) all diagonal entries positive, (2) ||Av - A^T v|| / ||Av|| < tol
    for n_check random vectors. Passes do not prove positive-definiteness.
    """
    if A.shape[0] != A.shape[1]:
        return False
    # 对角元检查
    diag = A.diagonal()
    if np.any(diag <= 0):
        return False
    # 随机对称性抽检
    rng = np.random.default_rng(42)
    AT = A.T
    for _ in range(n_check):
        v = rng.standard_normal(A.shape[0])
        Av = A @ v
        ATv = AT @ v
        diff = float(np.linalg.norm(Av - ATv))
        scale = float(np.linalg.norm(Av)) + 1e-30
        if diff / scale > tol:
            return False
    return True


class AISolver:
    """AI-AMG V-cycle 求解器."""

    def __init__(self,
                 model: "Optional[CFClassifier]" = None,
                 *,
                 max_levels: int = 10,
                 min_coarse: int = 25,
                 tol: float = 1e-8,
                 max_iter: int = 200,
                 smoother_iters: int = 1,
                 cf_threshold: float = 0.5,
                 strength_theta: float = 0.25,
                 use_classical_fallback: bool = True,
                 device: str | None = None,
                 verbose: bool = False):
        self.model = model
        self.max_levels = max_levels
        self.min_coarse = min_coarse
        self.tol = tol
        self.max_iter = max_iter
        self.smoother_iters = smoother_iters
        self.cf_threshold = cf_threshold
        self.strength_theta = strength_theta
        self.use_classical_fallback = use_classical_fallback
        if device is None:
            try:
                import torch
                device = "cuda" if torch.cuda.is_available() else "cpu"
            except ImportError:
                device = "cpu"
        self.device = device
        self.verbose = verbose
        self.levels: List[Level] = []

    # ---------- 分裂策略 ----------
    def _predict_splitting(self, A: sp.csr_matrix) -> np.ndarray:
        """如果模型存在就用 NN, 否则 fallback 到经典 RS."""
        if self.model is None:
            return rs_splitting(A, theta=self.strength_theta)
        data = to_pyg_data(A, labels=None, theta=self.strength_theta)
        cf, probs = self.model.predict_cf(data, threshold=self.cf_threshold,
                                          device=self.device)
        c_mask = cf.numpy().astype(np.int8)

        # Adaptive threshold: if all nodes are same class, use median as threshold
        # This extracts the relative ordering from the GNN even when outputs are biased
        if c_mask.sum() == 0 or c_mask.sum() == len(c_mask):
            probs_np = probs.numpy().flatten()
            # Use percentile targeting ~40-60% C nodes (typical for good AMG)
            target_c_frac = 0.5
            adaptive_thr = float(np.percentile(probs_np, (1.0 - target_c_frac) * 100))
            c_mask = (probs_np > adaptive_thr).astype(np.int8)

            # Still degenerate after adaptive threshold -> fallback
            if self.use_classical_fallback and (c_mask.sum() == 0 or c_mask.sum() == len(c_mask)):
                if self.verbose:
                    print("[solver] NN 退化分裂 (自适应后仍退化), 回退经典 RS")
                return rs_splitting(A, theta=self.strength_theta)
            if self.verbose:
                print(f"[solver] 自适应阈值: {adaptive_thr:.3f}, C占比: {c_mask.mean():.1%}")

        return c_mask

    # ---------- 建立层次 ----------
    def setup(self, A: sp.csr_matrix) -> "AISolver":
        """自顶向下构造多层层次 (可能 2 / 3 / ... 层投影, 直到达到极限)."""
        t0 = time.time()
        self.levels = []
        A_cur = sp.csr_matrix(A, copy=True)
        for lvl in range(self.max_levels):
            level = Level(A=A_cur)
            self.levels.append(level)

            if A_cur.shape[0] <= self.min_coarse:
                if self.verbose:
                    print(f"[setup] lvl {lvl} n={A_cur.shape[0]} (最粗, 直接求解)")
                try:
                    level._lu = spla.splu(A_cur.tocsc())
                except Exception:
                    level._lu = None
                break

            # 分裂 + 构造 P
            S = strength_matrix(A_cur, theta=self.strength_theta)
            c_mask = self._predict_splitting(A_cur)
            if c_mask.sum() == 0 or c_mask.sum() == A_cur.shape[0]:
                # 分裂无效, 视为最粗层
                try:
                    level._lu = spla.splu(A_cur.tocsc())
                except Exception:
                    level._lu = None
                if self.verbose:
                    print(f"[setup] lvl {lvl} n={A_cur.shape[0]} 分裂无效, 停止粗化")
                break

            P = build_prolongation(A_cur, c_mask, S=S)
            if P.shape[1] == 0 or P.nnz == 0:
                try:
                    level._lu = spla.splu(A_cur.tocsc())
                except Exception:
                    level._lu = None
                break
            R = P.T.tocsr()
            A_next = (R @ A_cur @ P).tocsr()

            level.P = P; level.R = R; level.c_mask = c_mask; level.S = S

            if self.verbose:
                print(f"[setup] lvl {lvl} n={A_cur.shape[0]} -> n_c={A_next.shape[0]} "
                      f"(C 占 {100*c_mask.mean():.1f}%)")

            A_cur = A_next
        else:
            # for..else: 达到 max_levels 仍未触发 break.
            # 最后一层必须当作最粗层: 清掉 P/R (否则 _vcycle 会越界递归),
            # 并加 LU 直接求解.
            last = self.levels[-1]
            last.P = None
            last.R = None
            last.c_mask = None
            try:
                last._lu = spla.splu(last.A.tocsc())
            except Exception:
                last._lu = None

        self.setup_time = time.time() - t0
        if self.verbose:
            print(f"[setup] 层次构造完成, 共 {len(self.levels)} 层, "
                  f"耗时 {self.setup_time:.3f}s")
        return self

    # ---------- V-cycle ----------
    def _vcycle(self, level_idx: int, x: np.ndarray, b: np.ndarray,
                inner_tol: float = 0.0) -> np.ndarray:
        """Run one V-cycle from level_idx. WARNING: modifies x in-place via Gauss-Seidel.

        Parameters
        ----------
        inner_tol : float
            Bouras-Frayssé inner tolerance. When > 0, the V-cycle performs an
            early exit after post-smoothing if the relative residual drops below
            inner_tol, saving work on easy systems. Default 0.0 = full V-cycle.
        """
        lvl = self.levels[level_idx]
        A = lvl.A
        # 最粗层
        if lvl.P is None:
            if lvl._lu is not None:
                return lvl._lu.solve(b)
            return spla.spsolve(A.tocsc(), b)

        # pre-smooth
        gauss_seidel(A, x, b, iters=self.smoother_iters, forward=True)

        # Bouras-Frayssé early exit check after pre-smooth
        if inner_tol > 0:
            r_pre = b - A @ x
            if np.linalg.norm(r_pre) <= inner_tol * np.linalg.norm(b):
                return x

        # 残差 + 限制
        r = b - A @ x
        rc = lvl.R @ r
        ec = np.zeros(lvl.R.shape[0])
        ec = self._vcycle(level_idx + 1, ec, rc)
        # 延拓 + 修正
        x += lvl.P @ ec
        # post-smooth
        gauss_seidel(A, x, b, iters=self.smoother_iters, forward=False)
        return x

    # ---------- V-cycle as M^{-1} operator ----------
    def v_cycle_apply(self, r: np.ndarray) -> np.ndarray:
        """Apply one V-cycle as a preconditioner: z = M^{-1} r."""
        assert self.levels, "call setup(A) first"
        r = np.asarray(r, dtype=np.float64)
        x = np.zeros(r.shape[0], dtype=np.float64)
        return self._vcycle(0, x, r.copy())

    # ---------- spectral monitor (OSC) ----------
    def certify(self, m: int = 20, n_probes: int = 10, conf: float = 0.95,
                adaptive: bool = True) -> dict:
        """Run OSC to certify spectral equivalence of this V-cycle on current A.

        Returns dict with keys: c, C, ratio, delta_eff, n_probes, m, time_osc.
        """
        assert self.levels, "call setup(A) first"
        from .spectral_certificate import certify_amg_solver
        return certify_amg_solver(
            self.levels[0].A, self, m=m, n_probes=n_probes,
            conf=conf, adaptive=adaptive,
        )

    # ---------- OSC-conditioned solve (OSC + AIK) ----------
    def solve_certified(self, b: np.ndarray, tol: float | None = None,
                        conf: float = 0.95, x0: np.ndarray | None = None,
                        verbose: bool | None = None,
                        kappa_cap: float = 1e6,
                        ) -> tuple[np.ndarray, dict]:
        """SC-NAMG end-to-end solver: OSC monitoring + AIK outer loop.

        Returns (x, cert) where cert contains c, C, k_used, k_max_predicted,
        final_residual, timing info, and osc_status.

        If OSC reports osc_status='kappa_excessive' (kappa > kappa_cap),
        the solver falls back to the classical solve path with max_iter
        and issues a CertificateFailure report.
        """
        assert self.levels, "call setup(A) first"
        tol = tol or self.tol
        verbose = verbose if verbose is not None else self.verbose

        cert = self.certify(m=20, n_probes=10, conf=conf, adaptive=True)
        c, C = cert["c"], cert["C"]
        osc_status = cert.get("osc_status", "ok")

        # (F3) Excessive kappa -> fallback to classical solve with user-defined cap
        if osc_status == "kappa_excessive":
            if verbose:
                print(f"[solve_certified] OSC reports excessive κ={C/c:.1f} > {kappa_cap}. "
                      f"Falling back to classical solve with max_iter={self.max_iter}.")
            x, hist = self.solve(b, x0=x0)
            from .aik_krylov import CertificateFailure
            failure = CertificateFailure(
                c=c, C=C, kappa=C / c if c > 0 else float("inf"),
                delta_eff=cert.get("delta_eff", 1.0),
                k_max=self.max_iter, k_used=len(hist.residuals) - 1,
                final_residual=hist.residuals[-1] if hist.residuals else float("inf"),
                target_tol=tol,
                preconditioner_flag="kappa_excessive_fallback",
            )
            cert.update({
                "k_used": len(hist.residuals) - 1,
                "k_max_predicted": self.max_iter,
                "final_residual": hist.residuals[-1] if hist.residuals else float("inf"),
                "time_solve": hist.solve_time,
                "operational_bound_failure": failure,
                "solver": "classical_fallback",
            })
            return x, cert

        from .aik_krylov import aik_fcg, aik_fgmres
        A = self.levels[0].A

        spd = _is_approximately_symmetric(A)
        solver_name = "aik_fcg" if spd else "aik_fgmres"
        if verbose:
            print(f"[solve_certified] SPD={spd}, solver={solver_name}, "
                  f"OSC=[{c:.4e}, {C:.4e}], κ={C/c:.1f}")

        vcycle_count = [0]

        def M_inv(r, eta):
            vcycle_count[0] += 1
            x = np.zeros_like(r)
            return self._vcycle(0, x, r, inner_tol=eta)

        import time as _time
        t0 = _time.perf_counter()
        if spd:
            x, info = aik_fcg(A, b, M_inv, c=c, C=C, tol=tol, x0=x0, verbose=verbose)
        else:
            x, info = aik_fgmres(A, b, M_inv, c=c, C=C, tol=tol, x0=x0, verbose=verbose)
        t_solve = _time.perf_counter() - t0
        info["total_vcycles"] = vcycle_count[0]

        cert.update({
            "k_used": info["iters"],
            "k_max_predicted": info["k_max_predicted"],
            "trunc": info.get("trunc", False),
            "final_residual": info["residual"],
            "time_solve": t_solve,
            "history": info["history"],
            "total_vcycles": info.get("total_vcycles", info["iters"]),
            "solver": solver_name,
            "spd": spd,
        })
        if "certificate_failure" in info:
            cert["certificate_failure"] = info["certificate_failure"]
        return x, cert

    # ---------- 外循环 ----------
    def solve(self, b: np.ndarray, x0: np.ndarray | None = None) -> tuple[np.ndarray, SolveHistory]:
        assert self.levels, "请先调用 setup(A)"
        A = self.levels[0].A
        n = A.shape[0]
        x = np.zeros(n) if x0 is None else np.array(x0, dtype=float)

        hist = SolveHistory(setup_time=self.setup_time,
                            levels=[lvl.A.shape[0] for lvl in self.levels])

        r0 = np.linalg.norm(b - A @ x)
        hist.residuals.append(float(r0))
        if r0 == 0.0:
            return x, hist

        t0 = time.time()
        for it in range(1, self.max_iter + 1):
            x = self._vcycle(0, x, b)
            r = b - A @ x
            rn = float(np.linalg.norm(r))
            hist.residuals.append(rn)
            if self.verbose:
                print(f"[solve] iter {it:3d}: ||r||={rn:.3e} rel={rn/r0:.3e}")
            if rn <= self.tol * r0 or rn <= self.tol:
                break

        hist.solve_time = time.time() - t0
        return x, hist


# ======================================================================
# 便捷函数
# ======================================================================

def solve_with_ai_amg(A: sp.csr_matrix,
                      b: np.ndarray,
                      model: "Optional[CFClassifier]" = None,
                      **solver_kwargs):
    """一行求解. 返回 (x, history)."""
    s = AISolver(model=model, **solver_kwargs).setup(A)
    return s.solve(b)

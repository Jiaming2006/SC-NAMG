"""
spectral_operational_bound.py -- SC-NAMG Online Spectral Monitor (OSC)
====================================================================

Phase 1 (W3-W5) core module.  Implements Stochastic Lanczos Quadrature (SLQ)
to monitor the spectral interval [c, C] of M^{-1}A online, feeding into the
AIK outer loop (Phase 2).

References:
    [Avron-Toledo 2011]  Randomized algorithms for estimating the trace of
        an implicit symmetric positive semi-definite matrix. J. ACM, 58(2).
    [Ubaru-Chen-Saad 2017] Fast estimation of tr(f(A)) via stochastic
        Lanczos quadrature. SIMAX, 38.
    [Golub-Meurant 2010] Matrices, Moments and Quadrature with Applications.

Public API:
    lanczos_tridiag          -- m-step Lanczos with full reorthogonalization
    gauss_quadrature         -- eigenvalues from tridiagonal (alpha, beta)
    slq_spectrum_bounds      -- SLQ-based spectral interval [c, C]
    slq_spectrum_bounds_adaptive -- adaptive probe version (variance control)
    certify_amg_solver       -- convenience wrapper for AISolver
"""
from __future__ import annotations

import time
import numpy as np
import scipy.sparse as sp
from typing import Callable, Tuple, Optional


# ---------------------------------------------------------------
# 1. Lanczos tridiagonalization (full reorthogonalization)
# ---------------------------------------------------------------
def lanczos_tridiag(
    A_op: Callable[[np.ndarray], np.ndarray],
    v0: np.ndarray,
    m: int,
    reorth: bool = True,
    tol: float = 1e-12,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """m-step Lanczos producing tridiagonal T_m = tridiag(beta, alpha, beta).

    Parameters
    ----------
    A_op : callable  v -> A @ v
    v0   : ndarray (n,) -- initial vector (will be normalised internally)
    m    : int          -- number of Lanczos steps
    reorth : bool       -- full Gram-Schmidt reorthogonalisation (recommended)
    tol  : float        -- early exit when beta_{k+1} < tol (invariant subspace)

    Returns
    -------
    alphas : ndarray (k,)      main diagonal of T_m
    betas  : ndarray (k-1,)    sub/super diagonal of T_m
    V      : ndarray (k+1, n)  orthonormal Lanczos basis
    """
    n = v0.shape[0]
    V = np.zeros((m + 1, n))
    alphas = np.zeros(m)
    betas = np.zeros(m + 1)
    V[0] = v0 / (np.linalg.norm(v0) + 1e-30)

    for k in range(m):
        w = A_op(V[k])
        alphas[k] = float(V[k] @ w)
        if k > 0:
            w = w - alphas[k] * V[k] - betas[k] * V[k - 1]
        else:
            w = w - alphas[k] * V[k]
        if reorth:
            # two-pass MGS for better numerical stability
            for _ in range(2):
                h = V[: k + 1] @ w
                w -= V[: k + 1].T @ h
        betas[k + 1] = float(np.linalg.norm(w))
        if betas[k + 1] < tol:
            return alphas[: k + 1], betas[1 : k + 1], V[: k + 1]
        V[k + 1] = w / betas[k + 1]

    return alphas, betas[1:m], V[: m + 1]


# ---------------------------------------------------------------
# 2. Gauss-Christoffel quadrature from tridiagonal
# ---------------------------------------------------------------
def gauss_quadrature(
    alphas: np.ndarray, betas: np.ndarray
) -> Tuple[np.ndarray, np.ndarray]:
    """Compute Gauss-Christoffel nodes and weights from tridiagonal T_m.

    The eigenvalues of T_m are the quadrature nodes; the squared first
    components of each eigenvector give the weights.

    Parameters
    ----------
    alphas : ndarray (m,)    main diagonal
    betas  : ndarray (m-1,)  sub-diagonal

    Returns
    -------
    nodes   : ndarray (m,)   quadrature nodes (= eigenvalues of T)
    weights : ndarray (m,)   quadrature weights
    """
    m = len(alphas)
    if m == 0:
        return np.array([]), np.array([])
    T = np.diag(alphas)
    if len(betas) > 0:
        T += np.diag(betas, 1) + np.diag(betas, -1)
    eigvals, eigvecs = np.linalg.eigh(T)
    weights = eigvecs[0, :] ** 2
    return eigvals, weights


# ---------------------------------------------------------------
# 3. SLQ spectral bounds (fixed n_probes)
# ---------------------------------------------------------------
def slq_spectrum_bounds(
    A_op: Callable[[np.ndarray], np.ndarray],
    M_inv_op: Callable[[np.ndarray], np.ndarray],
    n: int,
    m: int = 20,
    n_probes: int = 10,
    conf: float = 0.95,
    rng: int | np.random.Generator | None = 0,
) -> Tuple[float, float, float]:
    """Estimate spectral interval [c, C] of M_inv @ A using SLQ.

    Returns (c, C, delta_eff) where delta_eff is the failure probability bound.
    """
    if isinstance(rng, np.random.Generator):
        gen = rng
    else:
        gen = np.random.default_rng(rng)

    def PA(v: np.ndarray) -> np.ndarray:
        return M_inv_op(A_op(v))

    eig_lo, eig_hi = [], []
    for _ in range(n_probes):
        z = gen.choice(np.array([-1.0, 1.0]), size=n)  # Rademacher probe
        alphas, betas, _ = lanczos_tridiag(PA, z, m, reorth=True)
        nodes, _ = gauss_quadrature(alphas, betas)
        if len(nodes) > 0:
            eig_lo.append(float(nodes.min()))
            eig_hi.append(float(nodes.max()))

    if len(eig_lo) == 0:
        return 1e-12, 1.0, 1.0

    c_raw = max(min(eig_lo), 1e-12)
    C_raw = max(eig_hi)

    # Conservative safety margin: expand bounds by std of probe samples
    # to compensate for SLQ's interior-estimate bias (3-sigma for ~99.7% coverage)
    if len(eig_lo) > 1:
        lo_std = float(np.std(eig_lo, ddof=0))
        hi_std = float(np.std(eig_hi, ddof=0))
        c = max(c_raw - 3.0 * lo_std, 1e-12)
        C = C_raw + 3.0 * hi_std
    else:
        c = max(c_raw * 0.7, 1e-12)
        C = C_raw * 1.3

    # sub-Gaussian concentration (Avron-Toledo 2011)
    spread = C - c
    delta_eff = 2.0 * float(
        np.exp(-n_probes * (spread ** 2) / (8.0 * (C ** 2) + 1e-30))
    )
    return c, C, delta_eff


# ---------------------------------------------------------------
# 4. Adaptive SLQ (variance-controlled probes)
# ---------------------------------------------------------------
def slq_spectrum_bounds_adaptive(
    A_op: Callable[[np.ndarray], np.ndarray],
    M_inv_op: Callable[[np.ndarray], np.ndarray],
    n: int,
    m: int = 20,
    n_probes_init: int = 6,
    n_probes_max: int = 50,
    rel_width_tol: float = 0.3,
    conf: float = 0.95,
    rng: int | np.random.Generator | None = 0,
) -> Tuple[float, float, float, dict]:
    """Adaptive SLQ: increase probes until relative width of [c,C] stabilises.

    The relative width is defined as  (C - c) / C.  We keep adding probes
    in batches of 4 until the change in relative width between batches is
    below `rel_width_tol` or we hit `n_probes_max`.

    Returns (c, C, delta_eff, info) where info contains timing and probe count.
    """
    if isinstance(rng, np.random.Generator):
        gen = rng
    else:
        gen = np.random.default_rng(rng)

    def PA(v: np.ndarray) -> np.ndarray:
        return M_inv_op(A_op(v))

    eig_lo_all, eig_hi_all = [], []
    t0 = time.perf_counter()

    batch_size = max(2, n_probes_init)
    total_probes = 0
    prev_rel_width = None

    while total_probes < n_probes_max:
        this_batch = min(batch_size, n_probes_max - total_probes)
        for _ in range(this_batch):
            z = gen.choice(np.array([-1.0, 1.0]), size=n)
            alphas, betas, _ = lanczos_tridiag(PA, z, m, reorth=True)
            nodes, _ = gauss_quadrature(alphas, betas)
            if len(nodes) > 0:
                eig_lo_all.append(float(nodes.min()))
                eig_hi_all.append(float(nodes.max()))
        total_probes += this_batch

        if len(eig_lo_all) == 0:
            batch_size = 4
            continue

        c_cur = max(min(eig_lo_all), 1e-12)
        C_cur = max(eig_hi_all)
        rel_width = (C_cur - c_cur) / (C_cur + 1e-30)

        if total_probes >= n_probes_init and prev_rel_width is not None:
            change = abs(rel_width - prev_rel_width) / (prev_rel_width + 1e-30)
            if change < rel_width_tol:
                break

        prev_rel_width = rel_width
        batch_size = 4

    elapsed = time.perf_counter() - t0
    c_raw = max(min(eig_lo_all), 1e-12) if eig_lo_all else 1e-12
    C_raw = max(eig_hi_all) if eig_hi_all else 1.0

    if len(eig_lo_all) > 1:
        lo_std = float(np.std(eig_lo_all, ddof=1))
        hi_std = float(np.std(eig_hi_all, ddof=1))
        c = max(c_raw - 3.0 * lo_std, 1e-12)
        C = C_raw + 3.0 * hi_std
    else:
        c = max(c_raw * 0.7, 1e-12)
        C = C_raw * 1.3

    spread = C - c
    delta_eff = 2.0 * float(
        np.exp(-total_probes * (spread ** 2) / (8.0 * (C ** 2) + 1e-30))
    )

    info = {
        "n_probes_used": total_probes,
        "time_osc": elapsed,
        "eig_lo_samples": eig_lo_all,
        "eig_hi_samples": eig_hi_all,
    }
    return c, C, delta_eff, info


# ---------------------------------------------------------------
# 5. Fallback: power iteration + Rayleigh quotient
# ---------------------------------------------------------------
def _fallback_spectral_bounds(
    A_op: Callable[[np.ndarray], np.ndarray],
    M_inv_op: Callable[[np.ndarray], np.ndarray],
    n: int,
    n_iters: int = 30,
    rng: np.random.Generator | None = None,
) -> Tuple[float, float]:
    """Fallback for extremely ill-conditioned matrices (kappa > 1e10).

    Uses power iteration for lambda_max and inverse Rayleigh quotient
    minimisation for lambda_min.
    """
    if rng is None:
        rng = np.random.default_rng(42)

    def PA(v):
        return M_inv_op(A_op(v))

    # upper bound via power iteration
    v = rng.standard_normal(n)
    v /= np.linalg.norm(v) + 1e-30
    for _ in range(n_iters):
        v = PA(v)
        v /= np.linalg.norm(v) + 1e-30
    Av = PA(v)
    lam_max = float(v @ Av) / (float(v @ v) + 1e-30)

    # lower bound via scipy eigsh (shift-invert for smallest eigenvalue)
    try:
        from scipy.sparse.linalg import eigsh, LinearOperator
        PA_op = LinearOperator((n, n), matvec=PA, dtype=np.float64)
        lam_min_arr = eigsh(PA_op, k=1, which='SM', maxiter=n_iters * 10,
                            v0=rng.standard_normal(n),
                            return_eigenvectors=False)
        lam_min = max(float(lam_min_arr[0]), 1e-12)
    except Exception:
        # last-resort: use Rayleigh quotient from power iteration vectors
        u = rng.standard_normal(n)
        u /= np.linalg.norm(u) + 1e-30
        lam_min_candidates = []
        for _ in range(n_iters):
            Au = PA(u)
            rq = float(u @ Au) / (float(u @ u) + 1e-30)
            lam_min_candidates.append(rq)
            u = Au / (np.linalg.norm(Au) + 1e-30)
        lam_min = max(min(lam_min_candidates), 1e-12)
    lam_max = max(lam_max, lam_min + 1e-12)
    return lam_min, lam_max


# ---------------------------------------------------------------
# 6. High-level wrapper for AISolver
# ---------------------------------------------------------------
def certify_amg_solver(
    A,
    solver,
    m: int = 20,
    n_probes: int = 10,
    conf: float = 0.95,
    adaptive: bool = True,
    rng: int | np.random.Generator | None = 0,
) -> dict:
    """Certify an AMG solver's spectral equivalence on matrix A.

    Parameters
    ----------
    A       : scipy sparse matrix
    solver  : object with v_cycle_apply(r) -> z  or  _vcycle(0, x, b) method
    m       : Lanczos steps per probe
    n_probes : number of stochastic probes (used as init if adaptive=True)
    conf    : confidence level
    adaptive : if True, use adaptive probe variance control
    rng     : random seed or Generator

    Returns
    -------
    dict with keys: c, C, ratio, delta_eff, n_probes, m, time_osc
    """
    n = A.shape[0]
    t_start = time.perf_counter()

    def A_op(v):
        return A @ v

    def M_inv_op(r):
        if hasattr(solver, "v_cycle_apply"):
            return solver.v_cycle_apply(r)
        elif hasattr(solver, "_vcycle") and hasattr(solver, "levels"):
            x = np.zeros_like(r)
            return solver._vcycle(0, x, r)
        else:
            raise AttributeError(
                "solver must have v_cycle_apply() or _vcycle() method"
            )

    if adaptive:
        c, C, delta_eff, info = slq_spectrum_bounds_adaptive(
            A_op, M_inv_op, n, m=m,
            n_probes_init=min(n_probes, 6), n_probes_max=n_probes * 2,
            conf=conf, rng=rng,
        )
        n_probes_used = info["n_probes_used"]
    else:
        c, C, delta_eff = slq_spectrum_bounds(
            A_op, M_inv_op, n, m=m, n_probes=n_probes, conf=conf, rng=rng,
        )
        n_probes_used = n_probes

    # --- Failure mode detection (§4.2.2 / §5.3.2 protocol) ---
    osc_status = "ok"

    # (F1) T_m symmetry validation: Lanczos alpha coefficients should be
    #      positive for SPD M^{-1}A. Negative alphas indicate a non-SPD
    #      preconditioned operator.
    if adaptive and "eig_lo_samples" in info:
        eig_lo_arr = np.array(info["eig_lo_samples"])
        if np.any(eig_lo_arr < -1e-10):
            osc_status = "non_spd_warning"

    # (F2) c <= 0 or c too small -> fallback to power iteration bounds
    if c <= 0 or C / c > 1e10:
        if isinstance(rng, np.random.Generator):
            gen = rng
        else:
            gen = np.random.default_rng(rng)
        c_fb, C_fb = _fallback_spectral_bounds(A_op, M_inv_op, n, rng=gen)
        c = max(c, c_fb)
        C = max(C, C_fb)
        osc_status = "fallback_used"

    # (F3) kappa excessively large -> flag for user / classical fallback
    kappa_est = C / c if c > 0 else float("inf")
    kappa_cap = 1e6
    if kappa_est > kappa_cap:
        osc_status = "kappa_excessive"

    elapsed = time.perf_counter() - t_start
    return {
        "c": c,
        "C": C,
        "ratio": kappa_est,
        "delta_eff": delta_eff,
        "n_probes": n_probes_used,
        "m": m,
        "time_osc": elapsed,
        "osc_status": osc_status,
    }


# Canonical name (2026-05-23 terminology refresh): the function above operates
# as an *operational monitor*, not a verified mathematical certificate. The
# old name `certify_amg_solver` is preserved as a backward-compat alias.
def monitor_amg_solver(*args, **kwargs):
    """Run OSC and return the operational spectral interval as a dict.

    Canonical name for the OSC online monitor. Equivalent to
    `certify_amg_solver(...)`. See that function for the parameter list.
    The returned dict carries the operational bound [c, C], the heuristic
    confidence proxy `delta_eff`, the runtime status field `osc_status`,
    and timing data. None of these is a verified numerical certificate;
    see Proposition 1b in the SC-NAMG paper for the operational status.
    """
    return certify_amg_solver(*args, **kwargs)


# ---------------------------------------------------------------
# 7. Per-regime OSC self-diagnostic
# ---------------------------------------------------------------
def diagnose(
    cert: dict,
    A_shape: tuple,
    n_rhs: int = 1,
    time_solve: float | None = None,
) -> dict:
    """Per-regime OSC self-diagnostic.

    Classifies the OSC overhead into one of four regimes and reports
    a human-readable diagnostic string.

    Parameters
    ----------
    cert : dict
        Output of certify_amg_solver().
    A_shape : tuple
        Shape of A, i.e. (n, n).
    n_rhs : int
        Number of right-hand sides that will share this operational_bound.
    time_solve : float or None
        If given, the wall-clock solve time for a single RHS.

    Returns
    -------
    diag : dict with keys:
        regime : str  ('small_single', 'large_single', 'multi_rhs', 'one_off')
        overhead_pct : float  (OSC time as % of total)
        message : str  (human-readable diagnostic)
        kappa : float
        k_max : int
    """
    n = A_shape[0]
    t_osc = cert.get("time_osc", 0.0)
    c, C = cert["c"], cert["C"]
    kappa = C / c if c > 0 else float("inf")

    import math
    k_max = int(math.ceil(0.5 * math.sqrt(kappa) * math.log(2.0 / 1e-8)))

    # Regime classification
    if n_rhs >= 10:
        regime = "multi_rhs"
    elif n <= 5000:
        regime = "small_single"
    elif time_solve is not None:
        regime = "large_single"
    else:
        regime = "one_off"

    # Overhead estimation
    if time_solve is not None and time_solve > 0:
        total = t_osc + time_solve * n_rhs
        overhead_pct = 100.0 * t_osc / total
    else:
        overhead_pct = float("nan")

    # Message
    if regime == "multi_rhs":
        msg = (f"Multi-RHS regime (n_rhs={n_rhs}): OSC overhead amortized to "
               f"{overhead_pct:.1f}% of total. Certificate reused across all RHS.")
    elif regime == "small_single":
        msg = (f"Small-n single-RHS regime (n={n}): OSC overhead may dominate "
               f"solve time ({overhead_pct:.1f}%). Consider disabling OSC for "
               f"small benchmarks or batching multiple solves.")
    elif regime == "large_single":
        msg = (f"Large-n single-RHS regime (n={n}): OSC overhead is "
               f"{overhead_pct:.1f}% of total.")
    else:
        msg = (f"One-off solve (n={n}): OSC time = {t_osc:.4f}s, "
               f"kappa = {kappa:.1f}, k_max = {k_max}.")

    return {
        "regime": regime,
        "overhead_pct": overhead_pct,
        "message": msg,
        "kappa": kappa,
        "k_max": k_max,
        "c": c,
        "C": C,
        "n_probes": cert.get("n_probes", 0),
        "m": cert.get("m", 0),
        "time_osc": t_osc,
    }


# ---------------------------------------------------------------
# 8. Self-test
# ---------------------------------------------------------------
if __name__ == "__main__":
    print("=" * 60)
    print("Self-test: spectral_certificate.py")
    print("=" * 60)

    # --- Test 1: diagonal matrix with known spectrum ---
    print("\n[Test 1] Diagonal matrix, n=500, eigenvalues in [1, 100]")
    n = 500
    eigvals = np.linspace(1.0, 100.0, n)
    D = np.diag(eigvals)

    def A_diag(v):
        return D @ v

    def I_op(v):
        return v.copy()

    c, C, delta = slq_spectrum_bounds(A_diag, I_op, n, m=20, n_probes=10)
    print(f"  True:     lmin={eigvals.min():.3f}, lmax={eigvals.max():.3f}")
    print(f"  Estimate: c={c:.3f}, C={C:.3f}")
    print(f"  Coverage: lmin in [c,C]? {c <= eigvals.min()}")
    print(f"  Coverage: lmax in [c,C]? {eigvals.max() <= C}")
    print(f"  delta_eff = {delta:.4e}")
    assert c <= eigvals.min(), f"c={c:.6f} > λ_min={eigvals.min():.6f}, coverage failure!"
    assert C >= eigvals.max(), f"C={C:.6f} < λ_max={eigvals.max():.6f}, coverage failure!"
    print("  PASS")

    # --- Test 2: Gauss quadrature on known tridiagonal ---
    print("\n[Test 2] Gauss quadrature on tridiag with known eigenvalues")
    alphas_t = np.array([2.0, 2.0, 2.0])
    betas_t = np.array([-1.0, -1.0])
    nodes, weights = gauss_quadrature(alphas_t, betas_t)
    T_ref = np.diag(alphas_t) + np.diag(betas_t, 1) + np.diag(betas_t, -1)
    ev_ref = np.linalg.eigvalsh(T_ref)
    print(f"  Reference eigenvalues: {ev_ref}")
    print(f"  Quadrature nodes:      {nodes}")
    assert np.allclose(nodes, ev_ref, atol=1e-10), "nodes mismatch!"
    print(f"  Weights sum = {weights.sum():.6f} (should be ~1.0)")
    print("  PASS")

    # --- Test 3: adaptive SLQ ---
    print("\n[Test 3] Adaptive SLQ on diagonal matrix")
    c_a, C_a, delta_a, info_a = slq_spectrum_bounds_adaptive(
        A_diag, I_op, n, m=20, n_probes_init=4, n_probes_max=30
    )
    print(f"  Adaptive: c={c_a:.3f}, C={C_a:.3f}, probes_used={info_a['n_probes_used']}")
    print(f"  time = {info_a['time_osc']:.4f}s")
    assert c_a <= eigvals.min(), f"c_a={c_a:.6f} > λ_min={eigvals.min():.6f}"
    assert C_a >= eigvals.max(), f"C_a={C_a:.6f} < λ_max={eigvals.max():.6f}"
    print("  PASS")

    # --- Test 4: sparse Poisson 2D ---
    print("\n[Test 4] Sparse Poisson 2D (32x32)")
    try:
        import pyamg
        A_sp = pyamg.gallery.poisson((32, 32), format="csr")
        n_sp = A_sp.shape[0]

        def A_sp_op(v):
            return A_sp @ v

        c_sp, C_sp, delta_sp = slq_spectrum_bounds(
            A_sp_op, I_op, n_sp, m=20, n_probes=10
        )
        from scipy.sparse.linalg import eigsh
        lmin_true = eigsh(A_sp, k=1, sigma=0, which="LM", return_eigenvectors=False)[0]
        lmax_true = eigsh(A_sp, k=1, which="LM", return_eigenvectors=False)[0]
        print(f"  True:     lmin={lmin_true:.6f}, lmax={lmax_true:.3f}")
        print(f"  Estimate: c={c_sp:.6f}, C={C_sp:.3f}")
        print(f"  Covered?  lmin: {c_sp <= lmin_true}, lmax: {lmax_true <= C_sp}")
        print(f"  Over-conservatism: {(C_sp/c_sp)/(lmax_true/lmin_true):.2f}x")
        print("  PASS")
    except ImportError:
        print("  SKIP (pyamg not installed)")

    # --- Test 5: Lanczos recovers exact spectrum of small matrix ---
    print("\n[Test 5] Lanczos on 10x10 matrix recovers full spectrum")
    n5 = 10
    rng5 = np.random.default_rng(123)
    M5 = rng5.standard_normal((n5, n5))
    A5 = M5.T @ M5 + np.eye(n5)  # SPD
    ev5_true = np.sort(np.linalg.eigvalsh(A5))

    def A5_op(v):
        return A5 @ v

    alphas5, betas5, V5 = lanczos_tridiag(A5_op, rng5.standard_normal(n5), m=n5)
    nodes5, _ = gauss_quadrature(alphas5, betas5)
    nodes5_sorted = np.sort(nodes5)
    print(f"  True eigenvalues:    {ev5_true}")
    print(f"  Lanczos eigenvalues: {nodes5_sorted}")
    assert np.allclose(ev5_true, nodes5_sorted, rtol=1e-6), "spectrum mismatch!"
    print("  PASS")

    print("\n" + "=" * 60)
    print("All self-tests passed!")
    print("=" * 60)

"""训练 GNN 以预测 C/F 分裂.

用法:
    python -m src.train --data data/train.pt --out checkpoints/gnn.pt --epochs 50
"""
from __future__ import annotations
import random
from pathlib import Path
from typing import List

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import random_split
from torch_geometric.loader import DataLoader
from torch_geometric.data import Data

from .gnn_model import CFClassifier
from .gnn_dataset import load_dataset


def set_seed(seed: int):
    random.seed(seed); np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def compute_metrics(pred: torch.Tensor, y: torch.Tensor, thr: float = 0.5):
    pred_b = (torch.sigmoid(pred) > thr)
    y_b = y.bool()
    tp = (pred_b & y_b).sum().item()
    fp = (pred_b & ~y_b).sum().item()
    fn = (~pred_b & y_b).sum().item()
    tn = (~pred_b & ~y_b).sum().item()
    n = tp + fp + fn + tn
    acc = (tp + tn) / max(n, 1)
    prec = tp / max(tp + fp, 1)
    rec = tp / max(tp + fn, 1)
    f1 = 2 * prec * rec / max(prec + rec, 1e-9)
    return {"acc": acc, "prec": prec, "rec": rec, "f1": f1}


def train(
    samples: List[Data],
    epochs: int = 50,
    lr: float = 1e-3,
    weight_decay: float = 1e-5,
    batch_size: int = 8,
    val_split: float = 0.15,
    pos_weight: float = 3.0,
    hidden: int = 64,
    layers: int = 3,
    conv: str = "gatv2",
    dropout: float = 0.1,
    device: str | None = None,
    seed: int = 42,
    out_ckpt: str | None = None,
    verbose: bool = True,
):
    set_seed(seed)
    device = device or ("cuda" if torch.cuda.is_available() else "cpu")

    n = len(samples)
    n_val = max(1, int(val_split * n))
    g = torch.Generator().manual_seed(seed)
    train_ds, val_ds = random_split(samples, [n - n_val, n_val], generator=g)
    train_loader = DataLoader(list(train_ds), batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(list(val_ds), batch_size=batch_size, shuffle=False)

    model = CFClassifier(hidden=hidden, layers=layers, conv=conv, dropout=dropout).to(device)
    opt = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)
    pw = torch.tensor([pos_weight], device=device)
    loss_fn = nn.BCEWithLogitsLoss(pos_weight=pw)

    best_f1 = -1.0
    best_state = None
    history = []

    for ep in range(1, epochs + 1):
        # ---- train ----
        model.train()
        total = 0.0
        n_nodes = 0
        for batch in train_loader:
            batch = batch.to(device)
            logits = model(batch.x, batch.edge_index,
                            getattr(batch, "edge_attr", None))
            loss = loss_fn(logits, batch.y)
            opt.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
            total += loss.item() * batch.num_nodes
            n_nodes += batch.num_nodes
        train_loss = total / max(n_nodes, 1)

        # ---- val ----
        model.eval()
        vloss = 0.0; vn = 0
        all_pred, all_y = [], []
        with torch.no_grad():
            for batch in val_loader:
                batch = batch.to(device)
                logits = model(batch.x, batch.edge_index,
                                getattr(batch, "edge_attr", None))
                vloss += loss_fn(logits, batch.y).item() * batch.num_nodes
                vn += batch.num_nodes
                all_pred.append(logits.cpu()); all_y.append(batch.y.cpu())
        vloss = vloss / max(vn, 1)
        metrics = compute_metrics(torch.cat(all_pred), torch.cat(all_y))
        history.append({"epoch": ep, "train_loss": train_loss, "val_loss": vloss, **metrics})

        if verbose:
            print(f"[ep {ep:03d}] train={train_loss:.4f} val={vloss:.4f}"
                  f" acc={metrics['acc']:.3f} prec={metrics['prec']:.3f}"
                  f" rec={metrics['rec']:.3f} f1={metrics['f1']:.3f}")

        if metrics["f1"] > best_f1:
            best_f1 = metrics["f1"]
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}

    if best_state is not None:
        model.load_state_dict(best_state)

    if out_ckpt:
        out = Path(out_ckpt)
        out.parent.mkdir(parents=True, exist_ok=True)
        torch.save({
            "state_dict": model.state_dict(),
            "cfg": {"hidden": hidden, "layers": layers, "conv": conv, "dropout": dropout},
            "best_f1": best_f1,
            "history": history,
        }, out)
        if verbose:
            print(f"[train] 保存权重到 {out}, best F1 = {best_f1:.3f}")

    return model, history


def load_model(ckpt_path: str | Path, device: str | None = None) -> CFClassifier:
    device = device or ("cuda" if torch.cuda.is_available() else "cpu")
    ck = torch.load(ckpt_path, map_location=device, weights_only=False)
    cfg = ck.get("cfg", {})
    model = CFClassifier(**cfg).to(device)
    model.load_state_dict(ck["state_dict"])
    model.eval()
    return model

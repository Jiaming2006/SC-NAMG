"""GNN 模型: 预测每个节点作为 C 点的概率.

支持三种卷积:
    - 'gatv2' (默认): GATv2Conv, 接入 2 维边特征 (a_ij/a_ii, is_strong).
                       各向异性信息几乎全在边特征里, 这是关键改进.
    - 'sage' : GraphSAGE (不使用边特征, 向后兼容).
    - 'gcn'  : GCN      (不使用边特征).
最后一层输出 1 维 logit.
"""
from __future__ import annotations
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import SAGEConv, GCNConv, GATv2Conv

from .graph_features import NODE_FEATURE_DIM, EDGE_FEATURE_DIM


class CFClassifier(nn.Module):
    """逐节点二分类 (1 = C, 0 = F).

    Args:
        in_dim:    节点特征维度.
        hidden:    隐层宽度.
        layers:    GNN 层数.
        conv:      'gatv2' (默认, 用边特征) / 'sage' / 'gcn'.
        dropout:   每层后 dropout.
        edge_dim:  边特征维度 (仅 gatv2 使用).
        heads:     GATv2 注意力头数.
    """

    def __init__(self,
                 in_dim: int = NODE_FEATURE_DIM,
                 hidden: int = 64,
                 layers: int = 3,
                 conv: str = "gatv2",
                 dropout: float = 0.1,
                 edge_dim: int = EDGE_FEATURE_DIM,
                 heads: int = 4):
        super().__init__()
        self.conv_type = conv
        self.uses_edge_attr = (conv == "gatv2")
        self.input_proj = nn.Linear(in_dim, hidden)

        if conv == "gatv2":
            # concat=False -> output dim stays `hidden`; edge_dim feeds attention
            self.convs = nn.ModuleList(
                GATv2Conv(hidden, hidden, heads=heads, concat=False,
                          edge_dim=edge_dim, add_self_loops=True)
                for _ in range(layers)
            )
        else:
            Conv = {"sage": SAGEConv, "gcn": GCNConv}[conv]
            self.convs = nn.ModuleList(Conv(hidden, hidden)
                                       for _ in range(layers))

        self.norms = nn.ModuleList(nn.LayerNorm(hidden) for _ in range(layers))
        self.dropout = dropout
        self.head = nn.Sequential(
            nn.Linear(hidden, hidden),
            nn.ReLU(),
            nn.Linear(hidden, 1),
        )

    def forward(self, x: torch.Tensor, edge_index: torch.Tensor,
                edge_attr: torch.Tensor | None = None) -> torch.Tensor:
        h = F.relu(self.input_proj(x))
        for conv, ln in zip(self.convs, self.norms):
            if self.uses_edge_attr and edge_attr is not None:
                h_new = conv(h, edge_index, edge_attr=edge_attr)
            else:
                h_new = conv(h, edge_index)
            h_new = ln(h_new)
            h_new = F.relu(h_new)
            h_new = F.dropout(h_new, p=self.dropout, training=self.training)
            h = h + h_new
        return self.head(h).squeeze(-1)       # (N,)

    @torch.no_grad()
    def predict_cf(self, data, threshold: float = 0.5,
                   device: str | None = None) -> torch.Tensor:
        """Inference. 返回 int8 tensor, 1 = C 点, 0 = F 点."""
        self.eval()
        dev = device or next(self.parameters()).device
        x = data.x.to(dev)
        ei = data.edge_index.to(dev)
        ea = None
        if self.uses_edge_attr and getattr(data, "edge_attr", None) is not None:
            ea = data.edge_attr.to(dev)
        logits = self.forward(x, ei, ea)
        probs = torch.sigmoid(logits)
        cf = (probs > threshold).to(torch.int8).cpu()
        return cf, probs.cpu()

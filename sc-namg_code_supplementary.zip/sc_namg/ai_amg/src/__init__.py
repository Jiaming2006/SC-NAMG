"""SC-NAMG: Spectrally Calibrated Neural Algebraic Multigrid.

Public submodules:
    spectral_certificate    OSC online spectral monitor (Algorithm 2).
                            Canonical entry point: monitor_amg_solver().
    aik_krylov              AIK truncated FCG outer loop (Algorithm 3).
                            Canonical entry point: aik_fcg_v2(), which
                            returns a SolveResult with an explicit
                            FailurePolicy SolveStatus.
    fallback_policies       Ready-made callbacks for the FailurePolicy
                            state machine of §5.3.4.
    amg_solver              SC-NAMG end-to-end solver (Algorithm 1).
    dmle_loss / dmle_trainer  DMLE differentiable training objective.
    gnn_*                   GATv2 coarsener, dataset, trainer.
"""
__all__ = [
    "matrix_gen",
    "cf_splitting",
    "graph_features",
    "gnn_dataset",
    "gnn_model",
    "gnn_trainer",
    "dmle_trainer",
    "amg_solver",
    "spectral_certificate",
    "aik_krylov",
    "fallback_policies",
    "dmle_loss",
    "utils",
]

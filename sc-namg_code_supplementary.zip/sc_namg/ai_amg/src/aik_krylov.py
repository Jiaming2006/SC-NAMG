"""
aik_krylov.py — SC-NAMG Adaptive Inexact Krylov outer loop (AIK)
================================================================

Wraps the AI-AMG V-cycle as a Notay 2000-style truncated Flexible CG,
with the OSC-conditioned spectral interval (c, C) driving the
operational iteration budget k_max and Bouras-Frayssé inner tolerance.

References:
    [Notay 2000] Flexible Conjugate Gradients. SISC, 22.
    [Saad 1993] A flexible inner-outer preconditioned GMRES. SISC, 14.
    [Bouras-Frayssé 2005] Inexact matrix-vector products in Krylov methods. SIMAX, 26.

Public API:
    aik_fcg(A, b, M_inv, c, C, tol, x0=None)        # SPD main solver
    aik_fgmres(A, b, M_inv, c, C, tol, x0=None)     # non-SPD (FGMRES)
    derive_aik_params(c, C, tol)                     # OSC -> AIK parameter mapping
    CertificateFailure                                # structured failure report
    compute_slack_stats(results)                      # AIK slack distribution analysis
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import List

import numpy as np
from typing import Callable


# ---------------------------------------------------------------
# 0. FailurePolicy / SolveResult / CertificateFailure
# ---------------------------------------------------------------
# Algorithm 3 of the SC-NAMG paper (§5.3.4) defines an explicit FailurePolicy
# finite-state machine. The status field of the SolveResult lives on a small
# enum below; callers should branch on `status` rather than inspecting raw
# residuals or k_used.

from enum import Enum


class SolveStatus(str, Enum):
    """Outcome of an AIK-FCG solve under the OSC-conditioned iteration budget.

    The four states correspond directly to the §5.3.4 FailurePolicy:

      OK                    — residual stopping rule fired at line 10 within
                              the OSC-conditioned cap k_max. Returned x carries
                              the user-requested residual precision by
                              construction of the stopping rule, independently
                              of whether the OSC inclusion event holds.

      CertificateFailure    — OSC gate F1/F2/F3 (§4.3.9) tripped before any
                              FCG iteration: tridiagonal-symmetry failure,
                              lower-bound underflow, or excessive interval
                              width. No cap from (5.3) is consumed. The
                              caller's `on_certificate_failure` callback
                              chooses among rerun-OSC, switch-to-RS, or
                              conservative-max_iter.

      BudgetFailure         — Cap k_max exceeded without the residual rule
                              firing. Possible causes: unusually flat
                              spectrum, inexact-V-cycle penalty above its
                              modelled scale, OSC false-positive coverage.
                              The `on_budget_failure` callback chooses
                              among rerun-OSC, extend-to-2*k_max (if user
                              has signalled tolerance), or abort.

      SpectrumDegenerate    — OSC gate F4 (kappa above the configured ceiling)
                              tripped. Cap is not consumed; defaults to
                              classical RS fallback unless the caller
                              overrides.
    """

    OK = "ok"
    CERTIFICATE_FAILURE = "certificate_failure"
    BUDGET_FAILURE = "budget_failure"
    SPECTRUM_DEGENERATE = "spectrum_degenerate"


@dataclass
class SolveResult:
    """Return type of `aik_fcg_v2` (Algorithm 3, structured form).

    Always populated; callers branch on `status`. The OSC interval (c, C)
    and `delta_eff` are recorded as monitoring outputs regardless of branch.
    """
    status: SolveStatus
    x: np.ndarray
    k_used: int
    k_max: int
    final_residual: float
    target_tol: float
    c: float
    C: float
    delta_eff: float
    fallback_reason: str = ""
    preconditioner_flag: str = "ok"

    @property
    def converged(self) -> bool:
        return self.status == SolveStatus.OK

    def summary(self) -> str:
        return (
            f"SolveResult({self.status.value}): "
            f"k_used={self.k_used}/{self.k_max}, "
            f"residual={self.final_residual:.3e}/{self.target_tol:.1e}, "
            f"[c={self.c:.3e}, C={self.C:.3e}], "
            f"δ_eff={self.delta_eff:.3e}, "
            f"flag={self.preconditioner_flag}, "
            f"reason={self.fallback_reason!r}"
        )


@dataclass
class CertificateFailure:
    """Legacy structured diagnostic (kept for backward compatibility).

    The new canonical type is `SolveResult` above, which carries the
    explicit `SolveStatus` enum. This dataclass remains so that callers
    written against the v1 API continue to work; new code should branch
    on `SolveResult.status`.
    """
    c: float
    C: float
    kappa: float
    delta_eff: float
    k_max: int
    k_used: int
    final_residual: float
    target_tol: float
    preconditioner_flag: str = "suspect"

    @property
    def converged(self) -> bool:
        return self.final_residual <= self.target_tol

    @property
    def slack_ratio(self) -> float:
        return self.k_max / max(self.k_used, 1)

    def summary(self) -> str:
        status = "CONVERGED" if self.converged else "FAILED"
        return (
            f"CertificateReport({status}): "
            f"[c={self.c:.4e}, C={self.C:.4e}], κ={self.kappa:.1f}, "
            f"k_used={self.k_used}/{self.k_max}, "
            f"residual={self.final_residual:.3e} (tol={self.target_tol:.1e}), "
            f"δ_eff={self.delta_eff:.3e}, "
            f"flag={self.preconditioner_flag}"
        )


# ---------------------------------------------------------------
# 0b. Slack distribution statistics for AIK budget analysis
# ---------------------------------------------------------------
def compute_slack_stats(results: List[dict]) -> dict:
    """Compute AIK slack distribution from a list of solve results.

    Each result should contain 'k_max_predicted' and 'k_used'.
    Returns median, max, P90 slack, and per-result slack values.
    """
    slacks = []
    for r in results:
        k_max = r.get("k_max_predicted", r.get("k_max", 0))
        k_used = r.get("k_used", r.get("iters", 0))
        if k_used > 0:
            slacks.append(k_max / k_used)
    if not slacks:
        return {"median": float("nan"), "max": float("nan"),
                "p90": float("nan"), "mean": float("nan"), "slacks": []}
    arr = np.array(slacks)
    return {
        "median": float(np.median(arr)),
        "max": float(np.max(arr)),
        "p90": float(np.percentile(arr, 90)),
        "mean": float(np.mean(arr)),
        "min": float(np.min(arr)),
        "n": len(arr),
        "slacks": slacks,
    }


# ---------------------------------------------------------------
# 1. OSC -> AIK 超参映射
# ---------------------------------------------------------------
def derive_aik_params(c: float, C: float, tol: float,
                       trunc_floor: int = 5, trunc_cap: int = 50) -> dict:
    """根据谱等价区间 (c, C) 推断 truncated FCG 的超参.

    Returns
    -------
    params : dict
        trunc : 截断维度 (保留最近 trunc 个搜索方向)
        k_max : 可证终止步数上界
        eta_0 : 初始内层 V-cycle 容差
    """
    if c <= 0 or C <= 0 or c > C:
        return {"trunc": trunc_floor, "k_max": int(1e4), "eta_0": 0.1}
    if tol >= 1.0:
        raise ValueError(f"tol must be < 1.0, got {tol}")
    kappa_hat = max(C / c, 2.0)
    trunc = int(np.clip(math.ceil(math.log2(kappa_hat)), trunc_floor, trunc_cap))
    k_max = int(math.ceil(0.5 * math.sqrt(kappa_hat) * math.log(2.0 / tol)))
    eta_0 = max(0.1, min(0.5, 1.0 / math.sqrt(kappa_hat)))
    return {"trunc": trunc, "k_max": k_max, "eta_0": eta_0}


# ---------------------------------------------------------------
# 2. Truncated Flexible CG (SPD 情形, Notay 2000)
# ---------------------------------------------------------------
def aik_fcg(
    A,                                          # scipy sparse 或 callable
    b: np.ndarray,
    M_inv: Callable[[np.ndarray, float], np.ndarray],   # (r, eta) -> z, 内层 V-cycle
    c: float, C: float,
    tol: float = 1e-8,
    k_max_override: int | None = None,
    x0: np.ndarray | None = None,
    verbose: bool = False,
) -> tuple[np.ndarray, dict]:
    """SC-NAMG 主外循环.

    Parameters
    ----------
    A : sparse matrix or callable v -> A @ v
    b : ndarray (n,) 右端项
    M_inv : callable (r, eta) -> z
        内层 V-cycle, eta 为相对残差容差.
    c, C : float
        OSC 输出的谱等价区间.
    tol : float
        外层目标反向误差.
    k_max_override : int or None
        若为 None, 用 derive_aik_params 自动算; 否则用此上界 (用于 ablation).
    x0 : ndarray or None
        初始猜测, 默认零向量.

    Returns
    -------
    x : ndarray (n,)
        近似解.
    info : dict
        iters, residual, history, k_max_predicted, trunc, operational_bound
    """
    n = b.shape[0]
    matvec = (lambda v: A @ v) if not callable(A) else A
    x = np.zeros(n) if x0 is None else x0.copy()
    r = b - matvec(x)
    b_norm = float(np.linalg.norm(b)) + 1e-30

    params = derive_aik_params(c, C, tol)
    trunc = params["trunc"]
    k_max = k_max_override or params["k_max"]
    eta_0 = params["eta_0"]

    P: list[np.ndarray] = []          # 最近 trunc 个搜索方向
    AP: list[np.ndarray] = []         # 对应 A @ P
    history: list[float] = []

    for k in range(k_max):
        rho = float(np.linalg.norm(r)) / b_norm
        history.append(rho)
        if verbose:
            print(f"[AIK] k={k:4d}  rho={rho:.3e}")
        if rho < tol:
            return x, {
                "iters": k, "residual": rho, "history": history,
                "k_max_predicted": k_max, "trunc": trunc,
                "operational_bound": {"c": c, "C": C, "ratio": C / c if c > 0 else math.inf},
            }

        # ---- 内层 V-cycle 容差自适应 (Bouras-Frayssé) ----
        eta_k = max(tol, eta_0 * rho)
        z = M_inv(r, eta_k)

        # ---- Notay flexible orthogonalization ----
        p = z.copy()
        for Pi, APi in zip(P, AP):
            denom = float(APi @ Pi) + 1e-30
            beta_i = float(APi @ z) / denom
            p -= beta_i * Pi

        Ap = matvec(p)
        denom = float(p @ Ap) + 1e-30
        alpha = float(p @ r) / denom

        x += alpha * p
        r -= alpha * Ap

        P.append(p); AP.append(Ap)
        if len(P) > trunc:
            P.pop(0); AP.pop(0)

    rho = float(np.linalg.norm(r)) / b_norm
    failure = CertificateFailure(
        c=c, C=C, kappa=C / c if c > 0 else math.inf,
        delta_eff=0.0, k_max=k_max, k_used=k_max,
        final_residual=rho, target_tol=tol,
        preconditioner_flag="suspect" if rho > tol else "ok",
    )
    return x, {
        "iters": k_max, "residual": rho, "history": history,
        "k_max_predicted": k_max, "trunc": trunc,
        "operational_bound": {"c": c, "C": C, "ratio": C / c if c > 0 else math.inf},
        "operational_bound_failure": failure,
        "warning": "k_max reached without hitting tol",
    }


# ---------------------------------------------------------------
# 2a. Structured v2 wrapper — Algorithm 3 with explicit FailurePolicy
# ---------------------------------------------------------------
def aik_fcg_v2(
    A,
    b: np.ndarray,
    M_inv: Callable[[np.ndarray, float], np.ndarray],
    c: float,
    C: float,
    delta_eff: float = 0.0,
    osc_status: str = "ok",
    tol: float = 1e-8,
    tol_energy: float | None = None,
    k_max_override: int | None = None,
    x0: np.ndarray | None = None,
    *,
    kappa_max_ceiling: float = 1.0e8,
    on_certificate_failure: Callable[["SolveResult"], "SolveResult"] | None = None,
    on_budget_failure: Callable[["SolveResult"], "SolveResult"] | None = None,
    verbose: bool = False,
) -> SolveResult:
    """Algorithm 3 (SC-NAMG paper §5.3) — structured FailurePolicy form.

    This is the canonical AIK-FCG entry point. Returns a `SolveResult` whose
    `status` is one of `SolveStatus.{OK, CERTIFICATE_FAILURE, BUDGET_FAILURE,
    SPECTRUM_DEGENERATE}`, matching the four named states of the FailurePolicy
    state machine described in §5.3.4 of the paper.

    Parameters
    ----------
    A, b, M_inv, x0
        As for `aik_fcg`.
    c, C, delta_eff, osc_status
        Outputs of `monitor_amg_solver` (the OSC interval, the heuristic
        confidence proxy, and the OSC runtime status flag).
        `osc_status == 'fallback_used'` or `'kappa_excessive'` triggers
        the CertificateFailure / SpectrumDegenerate branch without running
        any FCG iteration.
    tol
        Residual stopping tolerance (eps_r in the paper).
    tol_energy
        Energy-norm tolerance used inside (5.3); defaults to `tol`.
    kappa_max_ceiling
        Upper bound on C/c above which the SpectrumDegenerate branch fires.
    on_certificate_failure, on_budget_failure
        Optional callbacks receiving the SolveResult; may *mutate* the
        result (e.g. replace `x` and `status` to reflect a rerun under
        larger (m, s), a switch to RS, or a conservative max_iter extension).
        Default behavior is to abort (return the result unchanged).
    """
    eps_r = float(tol)
    eps_E = float(tol_energy if tol_energy is not None else tol)

    # ---- (P3-style) OSC gate: degenerate / suspect intervals ----
    if osc_status in {"fallback_used", "non_spd_warning"} or c <= 0 or C <= 0 or c > C:
        result = SolveResult(
            status=SolveStatus.CERTIFICATE_FAILURE,
            x=np.zeros_like(b) if x0 is None else x0.copy(),
            k_used=0,
            k_max=0,
            final_residual=float("nan"),
            target_tol=eps_r,
            c=float(c), C=float(C), delta_eff=float(delta_eff),
            fallback_reason="osc_gate_" + osc_status,
            preconditioner_flag="suspect",
        )
        if on_certificate_failure is not None:
            return on_certificate_failure(result)
        return result

    if (C / max(c, 1e-30)) > kappa_max_ceiling or osc_status == "kappa_excessive":
        result = SolveResult(
            status=SolveStatus.SPECTRUM_DEGENERATE,
            x=np.zeros_like(b) if x0 is None else x0.copy(),
            k_used=0,
            k_max=0,
            final_residual=float("nan"),
            target_tol=eps_r,
            c=float(c), C=float(C), delta_eff=float(delta_eff),
            fallback_reason=f"kappa_above_ceiling_{kappa_max_ceiling:.1e}",
            preconditioner_flag="suspect",
        )
        if on_certificate_failure is not None:
            return on_certificate_failure(result)
        return result

    # ---- (5.3) cap derivation ----
    params = derive_aik_params(c, C, eps_E)
    k_max = int(k_max_override) if k_max_override is not None else int(params["k_max"])

    # ---- delegate to v1 inner loop ----
    x, info = aik_fcg(
        A, b, M_inv, c, C,
        tol=eps_r,
        k_max_override=k_max,
        x0=x0,
        verbose=verbose,
    )
    k_used = int(info["iters"])
    rho = float(info["residual"])

    if rho <= eps_r:
        return SolveResult(
            status=SolveStatus.OK,
            x=x, k_used=k_used, k_max=k_max,
            final_residual=rho, target_tol=eps_r,
            c=float(c), C=float(C), delta_eff=float(delta_eff),
            fallback_reason="",
            preconditioner_flag="ok",
        )

    # ---- BudgetFailure branch ----
    result = SolveResult(
        status=SolveStatus.BUDGET_FAILURE,
        x=x, k_used=k_used, k_max=k_max,
        final_residual=rho, target_tol=eps_r,
        c=float(c), C=float(C), delta_eff=float(delta_eff),
        fallback_reason="cap_exceeded_without_residual_rule",
        preconditioner_flag="suspect",
    )
    if on_budget_failure is not None:
        return on_budget_failure(result)
    return result


# ---------------------------------------------------------------
# 2b. Flexible GMRES(m)  —  non-SPD path
# ---------------------------------------------------------------
def aik_fgmres(
    A,
    b: np.ndarray,
    M_inv: Callable[[np.ndarray, float], np.ndarray],
    c: float, C: float,
    tol: float = 1e-8,
    restart: int = 30,
    k_max_override: int | None = None,
    x0: np.ndarray | None = None,
    verbose: bool = False,
) -> tuple[np.ndarray, dict]:
    """Flexible GMRES(m) for NON-SPD systems (Saad 1993).

    Mirrors :func:`aik_fcg` but uses an Arnoldi/Givens GMRES with a
    *variable* right preconditioner (the inexact V-cycle), so it tolerates
    a changing inner solve. ``(c, C)`` only feed the certified iteration
    cap ``k_max``; the method itself makes no SPD assumption.
    """
    n = b.shape[0]
    matvec = (lambda v: A @ v) if not callable(A) else A
    x = np.zeros(n) if x0 is None else x0.copy()
    b_norm = float(np.linalg.norm(b)) + 1e-30

    params = derive_aik_params(c, C, tol)
    eta_0 = params["eta_0"]
    k_max = k_max_override or params["k_max"]

    history: list[float] = []
    total_inner = 0

    max_total_inner = k_max * restart
    for outer in range(k_max):
        r = b - matvec(x)
        beta = float(np.linalg.norm(r))
        rho = beta / b_norm
        history.append(rho)
        if verbose:
            print(f"[FGMRES] outer={outer:3d} rho={rho:.3e}")
        if total_inner >= max_total_inner:
            break
        if rho < tol:
            return x, {
                "iters": outer, "residual": rho, "history": history,
                "k_max_predicted": k_max, "restart": restart,
                "inner_vcycles": total_inner,
                "operational_bound": {"c": c, "C": C,
                                "ratio": C / c if c > 0 else math.inf},
            }

        m = restart
        V = np.zeros((n, m + 1))
        Z = np.zeros((n, m))
        H = np.zeros((m + 1, m))
        V[:, 0] = r / beta
        g = np.zeros(m + 1)
        g[0] = beta
        cs = np.zeros(m)
        sn = np.zeros(m)

        j_used = 0
        for j in range(m):
            eta_j = max(tol, eta_0 * rho)
            zj = M_inv(V[:, j], eta_j)
            total_inner += 1
            Z[:, j] = zj
            w = matvec(zj)
            for i in range(j + 1):
                H[i, j] = float(w @ V[:, i])
                w = w - H[i, j] * V[:, i]
            H[j + 1, j] = float(np.linalg.norm(w))
            if H[j + 1, j] > 1e-14:
                V[:, j + 1] = w / H[j + 1, j]
            # apply previous Givens rotations
            for i in range(j):
                t = cs[i] * H[i, j] + sn[i] * H[i + 1, j]
                H[i + 1, j] = -sn[i] * H[i, j] + cs[i] * H[i + 1, j]
                H[i, j] = t
            denom = math.hypot(H[j, j], H[j + 1, j])
            if denom < 1e-30:
                cs[j], sn[j] = 1.0, 0.0
            else:
                cs[j] = H[j, j] / denom
                sn[j] = H[j + 1, j] / denom
            H[j, j] = cs[j] * H[j, j] + sn[j] * H[j + 1, j]
            H[j + 1, j] = 0.0
            g[j + 1] = -sn[j] * g[j]
            g[j] = cs[j] * g[j]
            j_used = j + 1
            if abs(g[j + 1]) / b_norm < tol:
                break

        # solve upper-triangular H[:j_used,:j_used] y = g[:j_used]
        y = np.zeros(j_used)
        for i in range(j_used - 1, -1, -1):
            s = g[i] - H[i, i + 1:j_used] @ y[i + 1:j_used]
            y[i] = s / H[i, i] if abs(H[i, i]) > 1e-30 else 0.0
        x = x + Z[:, :j_used] @ y

    r = b - matvec(x)
    rho = float(np.linalg.norm(r)) / b_norm
    failure = CertificateFailure(
        c=c, C=C, kappa=C / c if c > 0 else math.inf,
        delta_eff=0.0, k_max=k_max, k_used=k_max,
        final_residual=rho, target_tol=tol,
        preconditioner_flag="suspect" if rho > tol else "ok",
    )
    return x, {
        "iters": k_max, "residual": rho, "history": history,
        "k_max_predicted": k_max, "restart": restart,
        "inner_vcycles": total_inner,
        "operational_bound": {"c": c, "C": C,
                        "ratio": C / c if c > 0 else math.inf},
        "operational_bound_failure": failure,
        "warning": "k_max reached without hitting tol",
    }


# ---------------------------------------------------------------
# 3. Self-test
# ---------------------------------------------------------------
if __name__ == "__main__":
    import scipy.sparse as sp
    np.random.seed(0)

    # Poisson 1D, n=200
    n = 200
    e = np.ones(n)
    A = sp.diags([-e, 2 * e, -e], [-1, 0, 1]).tocsr()
    x_true = np.random.randn(n)
    b = A @ x_true

    def jacobi_inv(r, eta):
        D = A.diagonal()
        return 0.6 * r / D

    # Compute real spectral bounds via OSC interval
    from .spectral_certificate import slq_spectrum_bounds

    class _JacobiWrap:
        def v_cycle_apply(self, r):
            return jacobi_inv(r, 0)

    def A_op(v):
        return A @ v

    def M_inv_op(r):
        return jacobi_inv(r, 0)

    c, C, _ = slq_spectrum_bounds(A_op, M_inv_op, n, m=20, n_probes=10)
    x, info = aik_fcg(A, b, jacobi_inv, c=c, C=C, tol=1e-6, verbose=False)
    print(f"AIK-FCG converged in {info['iters']} iters (predicted ≤ {info['k_max_predicted']})")
    print(f"final residual = {info['residual']:.3e}")
    print(f"backward error vs true: {np.linalg.norm(x - x_true) / np.linalg.norm(x_true):.3e}")

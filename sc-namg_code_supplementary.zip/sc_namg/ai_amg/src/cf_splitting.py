"""用经典 Ruge-Stuben 分裂产生 C/F 真值标签.

依赖 pyamg 完成 "strength of connection" 和 "standard splitting".
这是 GNN 的监督信号来源.
"""
from __future__ import annotations

import numpy as np
import scipy.sparse as sp

try:
    from pyamg.classical.strength import classical_strength_of_connection
    from pyamg.classical.split import RS
    _HAS_PYAMG = True
except ImportError:
    _HAS_PYAMG = False


def strength_matrix(A: sp.csr_matrix, theta: float = 0.25) -> sp.csr_matrix:
    """SoC 矩阵. 降级: 用 |a_ij| ≥ θ max_{k≠i} |a_ik| 阈值."""
    if _HAS_PYAMG:
        return classical_strength_of_connection(A.tocsr(), theta=theta)
    # ---- 简易回退 ----
    A = A.tocsr()
    n = A.shape[0]
    rows, cols = [], []
    for i in range(n):
        s, e = A.indptr[i], A.indptr[i + 1]
        nbr = A.indices[s:e]
        val = np.abs(A.data[s:e])
        off = nbr != i
        if not off.any():
            continue
        m = val[off].max()
        if m <= 0:
            continue
        mask = val[off] >= theta * m
        strong = nbr[off][mask]
        rows.extend([i] * len(strong))
        cols.extend(strong.tolist())
    n_nnz = len(rows)
    return sp.csr_matrix((np.ones(n_nnz), (rows, cols)), shape=(n, n))


def rs_splitting(A: sp.csr_matrix, theta: float = 0.25) -> np.ndarray:
    """返回 shape=(n,) 的 int8 数组, 1=C 点, 0=F 点."""
    S = strength_matrix(A, theta)
    if _HAS_PYAMG:
        split = RS(S)
        return np.asarray(split, dtype=np.int8).ravel()

    # ---- 简化 RS 回退 (仅满足 RS-1, 未实现 RS-2; PyAMG 不可用时粗化质量可能下降) ----
    n = A.shape[0]
    ST = S.T.tocsr()
    lam = np.asarray(S.sum(axis=0)).ravel().astype(np.int64)
    state = np.zeros(n, dtype=np.int8)  # 1=C, -1=F, 0=undecided
    while True:
        und = np.where(state == 0)[0]
        if len(und) == 0:
            break
        i = und[int(np.argmax(lam[und]))]
        if lam[i] == 0:
            state[und] = -1
            break
        state[i] = 1
        dep = ST.indices[ST.indptr[i]:ST.indptr[i + 1]]
        for k in dep:
            if state[k] == 0:
                state[k] = -1
                nbr = S.indices[S.indptr[k]:S.indptr[k + 1]]
                for m in nbr:
                    if state[m] == 0:
                        lam[m] += 1
                lam[k] = 0
        lam[i] = 0
    return (state == 1).astype(np.int8)

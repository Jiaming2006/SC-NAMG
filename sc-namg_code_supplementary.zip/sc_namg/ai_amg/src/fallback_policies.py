"""fallback_policies.py — ready-made callbacks for the FailurePolicy chain.

This module provides callbacks that callers can pass to `aik_fcg_v2(...,
on_certificate_failure=..., on_budget_failure=...)` to realize the standard
fallback chain of §5.3.4 of the SC-NAMG paper:

    OSC re-probe (larger m, s) → switch to RS AMG → conservative max_iter → abort

Each policy is a plain callable that receives a `SolveResult` and returns
a `SolveResult`. They are designed to be composed via `chain_policies(...)`.

Usage
-----
    from ai_amg.src.aik_krylov import aik_fcg_v2
    from ai_amg.src.fallback_policies import (
        rerun_osc_with_larger_probes,
        switch_to_rs_amg,
        conservative_max_iter,
        chain_policies,
    )

    on_cert_fail = chain_policies(
        rerun_osc_with_larger_probes(m_mult=2, s_mult=2),
        switch_to_rs_amg(),
        conservative_max_iter(max_iter=1000),
    )
    result = aik_fcg_v2(A, b, M_inv, c, C,
                       on_certificate_failure=on_cert_fail)
"""
from __future__ import annotations

from typing import Callable, Iterable

from .aik_krylov import SolveResult, SolveStatus


PolicyFn = Callable[[SolveResult], SolveResult]


def chain_policies(*policies: PolicyFn) -> PolicyFn:
    """Sequentially apply policies until one returns status OK.

    Each policy receives the current SolveResult; if its returned result has
    status OK, the chain terminates. Otherwise the next policy is invoked
    with the (possibly mutated) result. The last policy's output is returned
    as-is.
    """
    def _composite(r: SolveResult) -> SolveResult:
        cur = r
        for p in policies:
            cur = p(cur)
            if cur.status == SolveStatus.OK:
                return cur
        return cur
    return _composite


def rerun_osc_with_larger_probes(
    rerun_solve_fn: Callable[[int, int], SolveResult] | None = None,
    m_mult: int = 2,
    s_mult: int = 2,
    max_doublings: int = 2,
) -> PolicyFn:
    """Rerun OSC with (m, s) doubled, then retry AIK-FCG.

    Parameters
    ----------
    rerun_solve_fn
        Caller-supplied closure of signature `(m, s) -> SolveResult` that
        re-runs OSC and AIK with the specified Lanczos depth / probe count.
        If None, the policy is a no-op (returns the input unchanged) — the
        chain proceeds to the next policy.
    m_mult, s_mult : int
        Factors by which to multiply Lanczos depth and probe count on each
        doubling attempt.
    max_doublings : int
        Number of consecutive doublings to attempt before giving up.
    """
    def _policy(r: SolveResult) -> SolveResult:
        if rerun_solve_fn is None:
            return r
        if r.status not in (
            SolveStatus.CERTIFICATE_FAILURE,
            SolveStatus.BUDGET_FAILURE,
        ):
            return r
        m_cur, s_cur = 20, 10  # default (m, s) of OSC
        for k in range(max_doublings):
            m_cur *= m_mult
            s_cur *= s_mult
            new_r = rerun_solve_fn(m_cur, s_cur)
            new_r.fallback_reason = (
                (r.fallback_reason + " -> " if r.fallback_reason else "")
                + f"osc_rerun(m={m_cur}, s={s_cur})"
            )
            if new_r.status == SolveStatus.OK:
                return new_r
            r = new_r
        return r
    return _policy


def switch_to_rs_amg(
    rs_solve_fn: Callable[[], SolveResult] | None = None,
) -> PolicyFn:
    """Switch from the learned/current hierarchy to a classical RS AMG hierarchy.

    Parameters
    ----------
    rs_solve_fn
        Caller-supplied closure that performs a complete AMG-PCG solve with
        Ruge–Stüben coarsening and returns a SolveResult. If None, the policy
        is a no-op.
    """
    def _policy(r: SolveResult) -> SolveResult:
        if rs_solve_fn is None:
            return r
        if r.status not in (
            SolveStatus.CERTIFICATE_FAILURE,
            SolveStatus.SPECTRUM_DEGENERATE,
            SolveStatus.BUDGET_FAILURE,
        ):
            return r
        new_r = rs_solve_fn()
        new_r.fallback_reason = (
            (r.fallback_reason + " -> " if r.fallback_reason else "")
            + "switch_to_rs_amg"
        )
        return new_r
    return _policy


def conservative_max_iter(
    extend_solve_fn: Callable[[int], SolveResult] | None = None,
    max_iter: int = 1000,
) -> PolicyFn:
    """Re-run AIK-FCG with a user-supplied conservative max_iter cap.

    This is the *last-resort* policy: it ignores the OSC-conditioned k_max
    and runs FCG with the residual rule until either convergence or the
    user-supplied `max_iter` is exhausted.

    Parameters
    ----------
    extend_solve_fn
        Caller-supplied closure of signature `(max_iter) -> SolveResult`.
        If None, the policy is a no-op.
    max_iter
        Conservative iteration cap to use in the fallback solve.
    """
    def _policy(r: SolveResult) -> SolveResult:
        if extend_solve_fn is None:
            return r
        if r.status == SolveStatus.OK:
            return r
        new_r = extend_solve_fn(max_iter)
        new_r.fallback_reason = (
            (r.fallback_reason + " -> " if r.fallback_reason else "")
            + f"conservative_max_iter(max_iter={max_iter})"
        )
        return new_r
    return _policy


def abort_strict() -> PolicyFn:
    """Strict-mode policy: leave the failure as-is and return.

    Use this as the final element of a chain to make the failure visible
    to the caller. Default behavior of `aik_fcg_v2` if no callback is
    supplied is already to return the failure unchanged.
    """
    def _policy(r: SolveResult) -> SolveResult:
        return r
    return _policy

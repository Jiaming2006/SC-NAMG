"""
pytorch_linalg.py — NN-assisted Krylov subsystem
================================================

A second research line (parallel to SC-NAMG): use small neural nets to
*assist* classical Krylov solvers rather than replace coarsening.

Components
----------
1. Preconditioners            : Jacobi / ILU(scipy) / AMG(V-cycle) as
                                matrix-free ``M_inv(r) -> z`` operators.
2. ``pcg`` / ``gmres``        : solvers accepting an initial guess ``x0``
                                and a preconditioner.
3. ``InitialGuessNet``        : GNN that predicts ``x0`` from the matrix
                                graph + RHS, trained on the *differentiable*
                                relative residual ‖A x0 − b‖/‖b‖.
4. ``MethodSelector``         : MLP that picks the fastest preconditioner
                                from cheap scalar matrix features.

Everything is dependency-light (numpy / scipy / torch / torch_geometric)
and unit-tested.
"""
from __future__ import annotations

from typing import Callable

import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla
import torch
import torch.nn as nn
import torch.nn.functional as F

from .graph_features import build_features, NODE_FEATURE_DIM


# ---------------------------------------------------------------
# 1. Preconditioners  (return callable r -> M^{-1} r)
# ---------------------------------------------------------------
def jacobi_precond(A: sp.csr_matrix) -> Callable[[np.ndarray], np.ndarray]:
    d = A.diagonal().astype(np.float64)
    d = np.where(np.abs(d) < 1e-30, 1.0, d)
    inv = 1.0 / d
    return lambda r: inv * r


def ilu_precond(A: sp.csr_matrix,
                drop_tol: float = 1e-4,
                fill_factor: int = 10) -> Callable[[np.ndarray], np.ndarray]:
    """Incomplete-LU preconditioner via scipy spilu (works for SPD too)."""
    try:
        lu = spla.spilu(A.tocsc(), drop_tol=drop_tol,
                        fill_factor=fill_factor)
        return lambda r: lu.solve(r)
    except Exception:
        return jacobi_precond(A)


def amg_precond(A: sp.csr_matrix) -> Callable[[np.ndarray], np.ndarray]:
    """One AMG V-cycle as a preconditioner (classical RS coarsening)."""
    from .amg_solver import AISolver
    s = AISolver(model=None, tol=1e-12, max_iter=1, verbose=False)
    s.setup(A)
    if len(s.levels) < 2:
        return jacobi_precond(A)
    return lambda r: s.v_cycle_apply(np.asarray(r, dtype=np.float64))


PRECONDITIONERS = {
    "jacobi": jacobi_precond,
    "ilu": ilu_precond,
    "amg": amg_precond,
}


# ---------------------------------------------------------------
# 2. Preconditioned solvers (accept x0 + M_inv)
# ---------------------------------------------------------------
def pcg(A, b: np.ndarray,
        M_inv: Callable[[np.ndarray], np.ndarray] | None = None,
        x0: np.ndarray | None = None,
        tol: float = 1e-8, max_iter: int = 500) -> tuple[np.ndarray, dict]:
    """Preconditioned CG (SPD). Returns (x, info)."""
    matvec = (lambda v: A @ v) if not callable(A) else A
    n = b.shape[0]
    x = np.zeros(n) if x0 is None else np.array(x0, dtype=np.float64)
    M_inv = M_inv or (lambda r: r)
    r = b - matvec(x)
    z = M_inv(r)
    p = z.copy()
    rz = float(r @ z)
    bnorm = float(np.linalg.norm(b)) + 1e-30
    hist = [float(np.linalg.norm(r)) / bnorm]
    for k in range(max_iter):
        Ap = matvec(p)
        denom = float(p @ Ap) + 1e-30
        alpha = rz / denom
        x = x + alpha * p
        r = r - alpha * Ap
        rel = float(np.linalg.norm(r)) / bnorm
        hist.append(rel)
        if rel < tol:
            return x, {"iters": k + 1, "residual": rel, "history": hist,
                       "converged": True}
        z = M_inv(r)
        rz_new = float(r @ z)
        beta = rz_new / (rz + 1e-30)
        p = z + beta * p
        rz = rz_new
    return x, {"iters": max_iter, "residual": hist[-1], "history": hist,
               "converged": hist[-1] < tol}


def gmres(A, b: np.ndarray,
          M_inv: Callable[[np.ndarray], np.ndarray] | None = None,
          x0: np.ndarray | None = None,
          tol: float = 1e-8, restart: int = 30,
          max_iter: int = 500) -> tuple[np.ndarray, dict]:
    """Right-preconditioned GMRES via scipy (non-SPD friendly)."""
    n = b.shape[0]
    A_op = A if sp.issparse(A) else spla.LinearOperator((n, n), matvec=A)
    M = None
    if M_inv is not None:
        M = spla.LinearOperator((n, n), matvec=M_inv)
    it = {"k": 0}
    A_lo = A_op if not sp.issparse(A_op) else spla.aslinearoperator(A_op)

    def cb(_):  # iteration counter
        it["k"] += 1

    x, code = spla.gmres(A_lo, b, x0=x0, M=M, rtol=tol,
                         restart=restart, maxiter=max_iter,
                         callback=cb, callback_type="legacy")
    res = float(np.linalg.norm(b - (A @ x if sp.issparse(A) else A(x)))
                ) / (float(np.linalg.norm(b)) + 1e-30)
    return x, {"iters": it["k"], "residual": res, "converged": code == 0}


# ---------------------------------------------------------------
# 3. Initial-guess network  (GNN: graph + RHS -> x0)
# ---------------------------------------------------------------
class InitialGuessNet(nn.Module):
    """Predicts a Krylov initial guess x0 from the matrix graph and RHS.

    Node input = [7 structural features, b_i / ‖b‖]. Output = x0_i.
    Trained on the differentiable objective ‖A x0 − b‖ / ‖b‖.
    """

    def __init__(self, hidden: int = 64, layers: int = 3):
        super().__init__()
        from torch_geometric.nn import SAGEConv
        self.inp = nn.Linear(NODE_FEATURE_DIM + 1, hidden)
        self.convs = nn.ModuleList(SAGEConv(hidden, hidden)
                                   for _ in range(layers))
        self.norms = nn.ModuleList(nn.LayerNorm(hidden)
                                   for _ in range(layers))
        self.out = nn.Linear(hidden, 1)

    def forward(self, x, edge_index):
        h = F.relu(self.inp(x))
        for c, ln in zip(self.convs, self.norms):
            h = h + F.relu(ln(c(h, edge_index)))
        return self.out(h).squeeze(-1)

    @torch.no_grad()
    def predict_x0(self, A: sp.csr_matrix, b: np.ndarray,
                   device: str = "cpu") -> np.ndarray:
        self.eval()
        feats, ei, _, _ = build_features(A)
        bn = b / (np.linalg.norm(b) + 1e-30)
        x = np.concatenate([feats, bn[:, None].astype(np.float32)], axis=1)
        xt = torch.tensor(x, device=device)
        eit = torch.tensor(ei, dtype=torch.long, device=device)
        x_hat = self.forward(xt, eit).cpu().numpy()
        # optimal scalar α = argmin ‖α A x̂ − b‖  (closed form)
        Ax = A @ x_hat
        denom = float(Ax @ Ax) + 1e-30
        alpha = float(Ax @ b) / denom
        return alpha * x_hat


def initial_guess_residual_loss(model: InitialGuessNet,
                                A_csr: sp.csr_matrix,
                                b: np.ndarray,
                                device: str = "cpu") -> torch.Tensor:
    """Differentiable ‖A x0 − b‖ / ‖b‖ for training InitialGuessNet."""
    feats, ei, _, _ = build_features(A_csr)
    bnv = b / (np.linalg.norm(b) + 1e-30)
    x = np.concatenate([feats, bnv[:, None].astype(np.float32)], axis=1)
    xt = torch.tensor(x, device=device)
    eit = torch.tensor(ei, dtype=torch.long, device=device)
    x_hat = model(xt, eit)
    A_t = torch.tensor(A_csr.toarray(), dtype=torch.float32, device=device)
    b_t = torch.tensor(b, dtype=torch.float32, device=device)
    Ax = A_t @ x_hat
    # optimal scalar α (closed form) — network learns the *direction*
    alpha = (Ax @ b_t) / ((Ax @ Ax) + 1e-20)
    resid = alpha * Ax - b_t
    return resid.norm() / (b_t.norm() + 1e-20)


# ---------------------------------------------------------------
# 4. Method selector  (MLP over cheap scalar features)
# ---------------------------------------------------------------
def matrix_signature(A: sp.csr_matrix) -> np.ndarray:
    """Cheap O(nnz) scalar features for solver/preconditioner selection."""
    n = A.shape[0]
    d = A.diagonal()
    absd = np.abs(d) + 1e-30
    Aabs = A.copy()
    Aabs.data = np.abs(Aabs.data)
    row_sum = np.asarray(Aabs.sum(axis=1)).ravel()
    dom = float(np.mean((absd - (row_sum - absd)) / absd))
    sym = float(abs(A - A.T).max()) if n <= 4000 else 0.0
    return np.array([
        np.log10(n + 1.0),
        A.nnz / n,
        dom,
        np.tanh(sym),
        float(np.log10(absd.max() / absd.min() + 1e-30)),
    ], dtype=np.float32)


class MethodSelector(nn.Module):
    """Pick the fastest preconditioner from a 5-dim matrix signature."""

    LABELS = ["jacobi", "ilu", "amg"]

    def __init__(self, in_dim: int = 5, hidden: int = 32):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden), nn.ReLU(),
            nn.Linear(hidden, hidden), nn.ReLU(),
            nn.Linear(hidden, len(self.LABELS)),
        )

    def forward(self, feats: torch.Tensor) -> torch.Tensor:
        return self.net(feats)

    @torch.no_grad()
    def select(self, A: sp.csr_matrix) -> str:
        self.eval()
        f = torch.tensor(matrix_signature(A)[None, :])
        idx = int(self.forward(f).argmax(dim=1).item())
        return self.LABELS[idx]

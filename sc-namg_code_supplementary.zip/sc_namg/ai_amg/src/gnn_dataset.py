"""训练集构造.

我们把 (矩阵 A, 经典 RS 标签) 转为 PyG Data 并存盘. 读取侧是 InMemoryDataset-like.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

import numpy as np
import scipy.sparse as sp
import torch
from torch_geometric.data import Data, InMemoryDataset

from . import matrix_gen
from .graph_features import to_pyg_data
from .cf_splitting import rs_splitting


@dataclass
class SamplingConfig:
    types: dict = field(default_factory=dict)
    n_samples: int = 100
    strength_theta: float = 0.25


def _sample_one(rng: np.random.Generator, cfg: SamplingConfig) -> sp.csr_matrix:
    kinds = list(cfg.types.keys())
    weights = np.array([cfg.types[k].get("weight", 1.0) for k in kinds])
    weights = weights / weights.sum()
    kind = rng.choice(kinds, p=weights)
    spec = cfg.types[kind]

    lo, hi = spec["size_range"]
    if kind == "poisson_2d":
        n = int(rng.integers(lo, hi + 1))
        return matrix_gen.poisson_2d(n)
    if kind == "poisson_3d":
        n = int(rng.integers(lo, hi + 1))
        return matrix_gen.poisson_3d(n)
    if kind == "anisotropic_2d":
        n = int(rng.integers(lo, hi + 1))
        eps_lo, eps_hi = spec.get("epsilon_range", [0.01, 0.1])
        th_lo, th_hi = spec.get("theta_range", [0.0, np.pi])
        eps = float(rng.uniform(eps_lo, eps_hi))
        th = float(rng.uniform(th_lo, th_hi))
        return matrix_gen.anisotropic_2d(n, epsilon=eps, theta=th)
    if kind == "random_spd":
        n = int(rng.integers(lo, hi + 1))
        d_lo, d_hi = spec.get("density_range", [0.005, 0.02])
        dens = float(rng.uniform(d_lo, d_hi))
        return matrix_gen.random_spd_sparse(n, density=dens, seed=int(rng.integers(0, 2**31)))
    if kind == "jump_diffusion_2d":
        n = int(rng.integers(lo, hi + 1))
        c_lo, c_hi = spec.get("contrast_range", [1e2, 1e5])
        contrast = float(10 ** rng.uniform(np.log10(c_lo), np.log10(c_hi)))
        n_inc = int(rng.integers(3, 8))
        return matrix_gen.jump_diffusion_2d(n, contrast=contrast, n_inclusions=n_inc,
                                            seed=int(rng.integers(0, 2**31)))
    raise ValueError(kind)


def build_dataset(cfg: SamplingConfig, seed: int = 0,
                  verbose: bool = True) -> List[Data]:
    rng = np.random.default_rng(seed)
    samples: List[Data] = []
    tried = 0
    while len(samples) < cfg.n_samples and tried < cfg.n_samples * 4:
        tried += 1
        try:
            A = _sample_one(rng, cfg)
            y = rs_splitting(A, theta=cfg.strength_theta)
            if y.sum() == 0 or y.sum() == len(y):
                # 全 C 或全 F, 学不出什么, 跳过
                continue
            data = to_pyg_data(A, labels=y, theta=cfg.strength_theta)
            samples.append(data)
            if verbose and len(samples) % 10 == 0:
                print(f"[dataset] 已生成 {len(samples)}/{cfg.n_samples}")
        except Exception as e:
            if verbose:
                print(f"[dataset] 跳过样本: {e}")
            continue
    return samples


def save_dataset(samples: List[Data], path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(samples, path)


def load_dataset(path: str | Path) -> List[Data]:
    return torch.load(path, weights_only=False)

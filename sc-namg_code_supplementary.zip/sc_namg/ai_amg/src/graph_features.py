"""从稀疏矩阵抽取节点 / 边特征, 转成 PyG Data 对象.

节点特征 (所有都做尺度无关归一化, 以便跨规模泛化):
    f0: log(度+1)
    f1: 对角元号 / 行范数
    f2: 强连接数 / 度
    f3: 被强依赖数 / 度 (lambda 归一化)
    f4: 非对角元均值 (符号 + 相对大小)
    f5: 非对角元方差
    f6: 对角占优度    (|a_ii| - sum_{j!=i} |a_ij|) / |a_ii|

边特征 (双向):
    e0: a_ij / a_ii                 (相对大小带符号)
    e1: is_strong  (0/1)
"""
from __future__ import annotations

import numpy as np
import scipy.sparse as sp

from .cf_splitting import strength_matrix


def build_features(A: sp.csr_matrix, theta: float = 0.25):
    """返回 (x, edge_index, edge_attr, S) — 不带标签."""
    A = A.tocsr()
    n = A.shape[0]
    S = strength_matrix(A, theta=theta)      # CSR, 0/1
    ST = S.T.tocsr()

    diag = A.diagonal()
    abs_diag = np.abs(diag) + 1e-30

    # 行统计
    A_abs = A.copy()
    A_abs.data = np.abs(A_abs.data)
    row_abs_sum = np.asarray(A_abs.sum(axis=1)).ravel()
    row_sum_off = row_abs_sum - abs_diag

    degree = np.diff(A.indptr).astype(np.float64)

    strong_out = np.diff(S.indptr).astype(np.float64)          # i 强连接多少个
    strong_in = np.diff(ST.indptr).astype(np.float64)          # 有多少点强依赖 i

    # 为算均值/方差, 需要逐行处理
    mean_off = np.zeros(n)
    var_off = np.zeros(n)
    for i in range(n):
        s, e = A.indptr[i], A.indptr[i + 1]
        nbr = A.indices[s:e]
        val = A.data[s:e]
        off_mask = nbr != i
        v = val[off_mask] / abs_diag[i]
        if v.size:
            mean_off[i] = float(v.mean())
            var_off[i] = float(v.var())

    dom = (abs_diag - row_sum_off) / abs_diag                   # 对角占优度

    feats = np.stack([
        np.log(degree + 1.0),
        diag / (row_abs_sum + 1e-30),
        strong_out / (degree + 1e-30),
        strong_in / (degree + 1e-30),
        mean_off,
        var_off,
        dom,
    ], axis=1).astype(np.float32)

    # 边: 用 A 的非零结构构造双向 edge_index (包含对角自环会干扰消息传递, 去掉)
    Acoo = A.tocoo()
    mask = Acoo.row != Acoo.col
    src = Acoo.row[mask]
    dst = Acoo.col[mask]
    val = Acoo.data[mask]

    rel = val / abs_diag[src]

    # is_strong? 查表 S
    S_lookup = (S != 0).astype(np.int8)
    e_strong = np.asarray(S_lookup[src, dst]).ravel().astype(np.float32)

    edge_attr = np.stack([rel.astype(np.float32), e_strong], axis=1)
    edge_index = np.stack([src, dst], axis=0).astype(np.int64)

    return feats, edge_index, edge_attr, S


def to_pyg_data(A: sp.csr_matrix, labels: np.ndarray | None = None,
                theta: float = 0.25):
    """延迟 import torch / torch_geometric, 允许无 NN 路径在纯 numpy 环境下工作."""
    import torch
    from torch_geometric.data import Data

    x_np, ei_np, ea_np, _ = build_features(A, theta=theta)
    data = Data(
        x=torch.from_numpy(x_np),
        edge_index=torch.from_numpy(ei_np),
        edge_attr=torch.from_numpy(ea_np),
    )
    if labels is not None:
        data.y = torch.from_numpy(labels.astype(np.float32))
    data.num_nodes = x_np.shape[0]
    return data


NODE_FEATURE_DIM = 7
EDGE_FEATURE_DIM = 2

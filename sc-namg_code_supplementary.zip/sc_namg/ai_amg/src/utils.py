"""辅助函数: 配置加载 / 路径工具 / 日志."""
from __future__ import annotations
from pathlib import Path
from typing import Any, Dict
import yaml


def load_yaml(path: str | Path) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def ensure_dir(p: str | Path) -> Path:
    p = Path(p)
    p.mkdir(parents=True, exist_ok=True)
    return p


def pretty_history(history) -> str:
    """SolveHistory -> 简明字符串."""
    lines = [f"levels: {history.levels}",
             f"setup time: {history.setup_time:.3f}s",
             f"solve time: {history.solve_time:.3f}s",
             f"iters: {len(history.residuals)-1}"]
    if history.residuals:
        rel = history.relative()
        lines.append(f"final ||r||: {history.residuals[-1]:.3e}")
        lines.append(f"rel ||r||/||r0||: {rel[-1]:.3e}")
    return "\n".join(lines)

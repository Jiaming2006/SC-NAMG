"""
dmle_loss.py — SC-NAMG 可微多层能量范数损失 (DMLE)
==================================================

Phase 3 (W9–W13) 主文件。把 BCE+pos_weight 的"模仿 RS"损失替换为以
二级 / 多层 V-cycle 误差传播算子 E_TG 的谱半径为主项的可微损失.

主要技术:
    - Gumbel-Softmax + Straight-Through  : 让离散 C/F 决策可微
    - 可微 power iteration                : 估计 ρ(E_TG)
    - Hutchinson trace 估计               : 计算迹归一化正则项
    - 可微插值算子构造                     : torch Direct interpolation

参考文献:
    [Jang-Gu-Poole 2017] Categorical Reparameterization with Gumbel-Softmax.
    [Luz et al. 2020] Learning AMG using GNN. ICML.
    [Xu-Zikatanov 2017] Algebraic Multigrid Methods. Acta Numerica.

接口约定:
    输入：GNN 模型 model: (x, edge_index) -> logits (n,)
    输出：标量 loss, 可对 model.parameters() 反向
"""
from __future__ import annotations

import math
import torch
import torch.nn.functional as F
import numpy as np
import scipy.sparse as sp


# ---------------------------------------------------------------
# 1. Gumbel-Softmax 离散化 C/F 决策
# ---------------------------------------------------------------
def gumbel_softmax_cf(logits: torch.Tensor, tau: float = 0.5,
                      hard: bool = True,
                      training: bool = True) -> torch.Tensor:
    """logits: (n,) C-logit per node. 返回 (n,) 的 C 概率/掩码.

    前向使用 argmax (二值), 反向用 softmax 梯度 (straight-through estimator).
    When training=False, Gumbel noise is disabled for deterministic validation.
    """
    logits_2d = torch.stack([torch.zeros_like(logits), logits], dim=-1)  # (n, 2): [F, C]
    if training:
        g = -torch.log(-torch.log(torch.rand_like(logits_2d) + 1e-20) + 1e-20)
        soft = F.softmax((logits_2d + g) / tau, dim=-1)
    else:
        soft = F.softmax(logits_2d / tau, dim=-1)
    if hard:
        idx = soft.argmax(dim=-1, keepdim=True)
        hard_oh = torch.zeros_like(soft).scatter_(1, idx, 1.0)
        cf = (hard_oh - soft).detach() + soft  # straight-through
    else:
        cf = soft
    return cf[:, 1]  # C probability


# ---------------------------------------------------------------
# 2. Torch 版强连接矩阵
# ---------------------------------------------------------------
def strength_matrix_torch(A_csr: sp.csr_matrix, theta: float = 0.25) -> torch.Tensor:
    """从 scipy CSR 构造强连接 edge_index (COO, int64, shape [2, nnz_strong]).

    Returns torch LongTensor of shape (2, num_strong_edges).
    """
    A = A_csr.tocsr()
    n = A.shape[0]
    rows, cols = [], []
    for i in range(n):
        s, e = A.indptr[i], A.indptr[i + 1]
        nbr = A.indices[s:e]
        val = np.abs(A.data[s:e])
        off_mask = nbr != i
        if not off_mask.any():
            continue
        m = val[off_mask].max()
        if m <= 0:
            continue
        strong_mask = val[off_mask] >= theta * m
        strong_nbr = nbr[off_mask][strong_mask]
        rows.extend([i] * len(strong_nbr))
        cols.extend(strong_nbr.tolist())
    if len(rows) == 0:
        return torch.zeros(2, 0, dtype=torch.long)
    return torch.tensor([rows, cols], dtype=torch.long)


# ---------------------------------------------------------------
# 3. 可微插值算子构造 (Direct Interpolation)
# ---------------------------------------------------------------
def build_P_differentiable(A_dense: torch.Tensor, cf_soft: torch.Tensor,
                           strong_edges: torch.Tensor,
                           ) -> torch.Tensor:
    """构造可微的插值算子 P, shape (n, n_c).

    A_dense: (n, n) dense tensor
    cf_soft: (n,) soft C-mask (0=F, 1=C) from Gumbel-Softmax
    strong_edges: (2, E) strong connection pairs

    Returns P_dense: (n, n_c) interpolation matrix (differentiable w.r.t. cf_soft).

    For C-points: P[i, c_idx[i]] = cf_soft[i] (≈1)
    For F-points: direct interpolation weights (strong F-F lumped into diagonal),
                  scaled by (1 - cf_soft[i])
    """
    n = A_dense.shape[0]
    device = A_dense.device

    # Build a soft C-index mapping: enumerate C points by cumsum of cf_soft
    # For hard ST, cf_soft is binary; cumsum gives indices
    cf_hard = (cf_soft > 0.5).float()
    n_c = int(cf_hard.sum().item())
    if n_c == 0 or n_c == n:
        return torch.eye(n, max(n_c, 1), device=device)

    # C-point indices (hard)
    c_indices = torch.where(cf_hard > 0.5)[0]
    c_map = torch.full((n,), -1, dtype=torch.long, device=device)
    c_map[c_indices] = torch.arange(n_c, device=device)

    # Build strong neighbor sets
    strong_set = {}
    if strong_edges.numel() > 0:
        src = strong_edges[0].tolist()
        dst = strong_edges[1].tolist()
        for s, d in zip(src, dst):
            if s not in strong_set:
                strong_set[s] = []
            strong_set[s].append(d)

    # Pre-compute per-node strong C / strong F neighbor sets
    strong_c_map = {}  # i -> list of strong C neighbors
    strong_f_map = {}  # i -> list of strong F neighbors
    for i in range(n):
        if i in strong_set:
            sc, sf = [], []
            for j in strong_set[i]:
                if cf_hard[j] > 0.5:
                    sc.append(j)
                else:
                    sf.append(j)
            strong_c_map[i] = sc
            strong_f_map[i] = sf

    # Pre-compute vectorized row sums for F-point columns
    f_mask = (cf_hard < 0.5)
    f_indices = torch.where(f_mask)[0]
    row_f_sum = A_dense[:, f_indices].sum(dim=1)  # sum of A[i,j] for all F-points j

    # Construct P row by row (Direct interpolation)
    P_rows = []
    for i in range(n):
        row = torch.zeros(n_c, device=device)
        if cf_hard[i] > 0.5:
            row[c_map[i]] = cf_soft[i]
        else:
            a_ii = A_dense[i, i]
            strong_c_nbrs = strong_c_map.get(i, [])
            strong_f_nbrs = strong_f_map.get(i, [])

            if len(strong_c_nbrs) == 0 or abs(a_ii.item()) < 1e-30:
                P_rows.append(row)
                continue

            # weak F sum = (all F connections) - (strong F connections) - self if F
            strong_f_sum = torch.tensor(0.0, device=device)
            for k in strong_f_nbrs:
                strong_f_sum = strong_f_sum + A_dense[i, k]
            row_sum_weak = row_f_sum[i] - strong_f_sum
            if f_mask[i]:
                row_sum_weak = row_sum_weak - A_dense[i, i]

            denom = a_ii + row_sum_weak
            if abs(denom.item()) < 1e-30:
                P_rows.append(row)
                continue

            # Direct interpolation: strong F-F connections lumped into diagonal
            denom = denom + strong_f_sum

            if abs(denom.item()) < 1e-30:
                P_rows.append(row)
                continue

            for j in strong_c_nbrs:
                w = -A_dense[i, j] / denom
                row[c_map[j]] = row[c_map[j]] + w * (1 - cf_soft[i])

        P_rows.append(row)

    P = torch.stack(P_rows, dim=0)
    return P


# ---------------------------------------------------------------
# 4. 可微 power iteration 估计谱半径
# ---------------------------------------------------------------
def spectral_radius_power(op, n: int, n_iters: int = 15,
                          device: torch.device | None = None) -> torch.Tensor:
    """对 op: torch.Tensor -> torch.Tensor 估计 ρ(op).

    用 Rayleigh quotient + power iteration. 全程 autograd 友好.
    """
    device = device or torch.device("cpu")
    v = torch.randn(n, device=device)
    v = v / (v.norm() + 1e-20)
    for _ in range(n_iters):
        v_new = op(v)
        v_new = v_new / (v_new.norm() + 1e-20)
        v = v_new
    Av = op(v)
    rho = (Av @ v) / (v @ v + 1e-20)
    return rho.abs()


def differentiable_kappa(MA_op, n: int, m: int = 12,
                         device: torch.device | None = None) -> torch.Tensor:
    """Differentiable κ̂(M⁻¹A) via m-step symmetric Lanczos.

    Mirrors the OSC interval's stochastic-Lanczos-quadrature mechanism so
    the DMLE training signal is *the same quantity* OSC monitors. Returns
    θ_max/θ_min of the Lanczos tridiagonal (Ritz values), fully autograd-
    friendly (only matvecs + a small symmetric eig). Used as a regularizer:
    minimizing κ̂ → tighter spectral equivalence → tighter OSC bound →
    sharper certified AIK k_max.  (Direction 2 closed loop.)
    """
    device = device or torch.device("cpu")
    v = torch.randn(n, device=device)
    v = v / (v.norm() + 1e-20)
    alphas, betas = [], []
    beta = torch.zeros((), device=device)
    V_basis = [v]
    v_prev = torch.zeros(n, device=device)
    for j in range(m):
        w = MA_op(v)
        alpha = w @ v
        w = w - alpha * v - beta * v_prev
        # two-pass MGS full reorthogonalization (matches OSC Lanczos)
        for _ in range(2):
            for vi in V_basis:
                w = w - (w @ vi) * vi
        beta_next = w.norm() + 1e-20
        alphas.append(alpha)
        v_prev = v
        v = w / beta_next
        V_basis.append(v.detach())
        if j < m - 1:
            betas.append(beta_next)
        beta = beta_next

    k = len(alphas)
    T = torch.zeros(k, k, device=device)
    for i in range(k):
        T[i, i] = alphas[i]
    for i in range(k - 1):
        T[i, i + 1] = betas[i]
        T[i + 1, i] = betas[i]
    ritz = torch.linalg.eigvalsh(T)
    lo = torch.clamp(ritz.min(), min=1e-8)
    hi = torch.clamp(ritz.max(), min=1e-8)
    return hi / lo


# ---------------------------------------------------------------
# 5. 二级 V-cycle 误差传播算子 E_TG
# ---------------------------------------------------------------
def _sparse_from_csr(A_csr, device):
    """Build a constant (no-grad) torch sparse COO tensor from scipy CSR."""
    Acoo = A_csr.tocoo()
    idx = torch.tensor(np.vstack([Acoo.row, Acoo.col]), dtype=torch.long,
                       device=device)
    val = torch.tensor(Acoo.data, dtype=torch.float32, device=device)
    return torch.sparse_coo_tensor(idx, val, A_csr.shape,
                                   device=device).coalesce()


def two_grid_error_op(A_dense: torch.Tensor, P_dense: torch.Tensor,
                      n_smooth: int = 1, omega: float = 2.0 / 3.0,
                      A_sparse: torch.Tensor | None = None):
    """E_TG = S^ν (I − P Ac⁻¹ Pᵀ A) S^ν, **matrix-free** (no dense n×n).

    Only the operator's *action* is needed (power iteration), so we never
    form S, I_n or CGC explicitly. A enters only via sparse matvec (it is
    a fixed input, not differentiable); P is dense & differentiable.
    Removes the O(n³) dense bottleneck — training is no longer capped at
    small n.
    """
    n = A_dense.shape[0]
    D_inv = 1.0 / (A_dense.diagonal() + 1e-30)
    if A_sparse is not None:
        Av = lambda v: torch.sparse.mm(A_sparse, v.unsqueeze(1)).squeeze(1)
        AP = torch.sparse.mm(A_sparse, P_dense)            # (n, n_c)
    else:
        Av = lambda v: A_dense @ v
        AP = A_dense @ P_dense

    # Coarse operator Ac = Pᵀ A P  (n_c small); exact inverse once.
    Ac = P_dense.T @ AP
    n_c = Ac.shape[0]
    Ac_inv = torch.linalg.inv(Ac + 1e-8 * torch.eye(n_c, device=A_dense.device))

    def S_apply(v):                       # weighted Jacobi: v - ω D⁻¹ A v
        return v - omega * D_inv * Av(v)

    def apply(v):
        for _ in range(n_smooth):
            v = S_apply(v)
        # coarse-grid correction: v - P Ac⁻¹ Pᵀ A v
        v = v - P_dense @ (Ac_inv @ (P_dense.T @ Av(v)))
        for _ in range(n_smooth):
            v = S_apply(v)
        return v

    return apply


# ---------------------------------------------------------------
# 5b. 多层 V-cycle 误差传播算子 (recursive, trains GNN multilevel)
# ---------------------------------------------------------------
def _P_from_model(A_csr, A_dense, model, tau, theta, device):
    """Apply GNN to A_csr -> differentiable prolongation P (n, n_c).

    Graph features (GNN input) are extracted from A_csr structure; the
    differentiability flows through GNN weights + Gumbel soft C/F + the
    differentiable P assembly using A_dense.
    """
    from .graph_features import to_pyg_data
    data = to_pyg_data(A_csr, theta=theta)
    ea = None
    if getattr(model, "uses_edge_attr", False) and \
            getattr(data, "edge_attr", None) is not None:
        ea = data.edge_attr.to(device)
    logits = model(data.x.to(device), data.edge_index.to(device), ea)
    cf_soft = gumbel_softmax_cf(logits, tau=tau, hard=True)
    strong = strength_matrix_torch(A_csr, theta=theta).to(device)
    P = build_P_differentiable(A_dense, cf_soft, strong)
    return P, int((cf_soft > 0.5).sum().item())


def multilevel_error_op(A_dense, A_csr, model, tau, theta, device,
                        max_levels=3, min_coarse=40, n_smooth=1,
                        omega=2.0 / 3.0):
    """Build the true multilevel V-cycle error operator E_0 = I - M_0^{-1} A_0.

    The GNN is applied recursively at every level (not just two-grid), so the
    spectral radius of E_0 reflects FULL multilevel performance.
    Returns (apply_E0, n_c_top) or (None, 0) if degenerate.
    """
    import scipy.sparse as _sp

    levels = []  # list of dicts: {A_dense, D_inv, P}
    A_cur_d = A_dense
    A_cur_csr = A_csr
    n_c_top = 0

    for lvl in range(max_levels):
        n = A_cur_d.shape[0]
        D_inv = 1.0 / (A_cur_d.diagonal() + 1e-30)
        if n <= min_coarse or lvl == max_levels - 1:
            levels.append({"A": A_cur_d, "D_inv": D_inv, "P": None})
            break
        P, n_c = _P_from_model(A_cur_csr, A_cur_d, model, tau, theta, device)
        if n_c == 0 or n_c >= n:
            levels.append({"A": A_cur_d, "D_inv": D_inv, "P": None})
            break
        if lvl == 0:
            n_c_top = n_c
        levels.append({"A": A_cur_d, "D_inv": D_inv, "P": P})
        # Galerkin coarse operator: use sparse A when n is large
        if n > min_coarse:
            A_cur_sparse = _sparse_from_csr(A_cur_csr, device)
            AP = torch.sparse.mm(A_cur_sparse, P)   # (n, n_c), sparse @ dense
            A_next_d = P.T @ AP                       # (n_c, n_c)
        else:
            A_next_d = P.T @ A_cur_d @ P
        A_next_csr = _sp.csr_matrix(A_next_d.detach().cpu().numpy())
        A_cur_d, A_cur_csr = A_next_d, A_next_csr

    if len(levels) < 2:
        return None, 0

    # Coarsest exact inverse
    Acoarse = levels[-1]["A"]
    nc = Acoarse.shape[0]
    Acoarse_reg = Acoarse + 1e-8 * torch.eye(nc, device=device)
    coarse_inv = torch.linalg.inv(Acoarse_reg)

    def make_Minv(idx):
        lv = levels[idx]
        A_l = lv["A"]
        D_inv = lv["D_inv"]
        P = lv["P"]
        if P is None:
            return lambda r: coarse_inv @ r
        coarse_Minv = make_Minv(idx + 1)

        def Minv(r):
            x = torch.zeros_like(r)
            for _ in range(n_smooth):
                x = x + omega * D_inv * (r - A_l @ x)
            rc = P.T @ (r - A_l @ x)
            ec = coarse_Minv(rc)
            x = x + P @ ec
            for _ in range(n_smooth):
                x = x + omega * D_inv * (r - A_l @ x)
            return x

        return Minv

    M0inv = make_Minv(0)
    A0 = levels[0]["A"]

    def apply_E0(v):
        return v - M0inv(A0 @ v)

    return apply_E0, n_c_top


# ---------------------------------------------------------------
# 6. 迹归一化正则项 (complexity measure)
# ---------------------------------------------------------------
def complexity_regularizer(P_dense: torch.Tensor, n: int) -> torch.Tensor:
    """Penalize grid complexity: C_g = n_c / n. Encourage sparser coarsening."""
    n_c = P_dense.shape[1]
    return torch.tensor(n_c / n, device=P_dense.device, dtype=P_dense.dtype)


def smoothness_regularizer(A_dense: torch.Tensor, P_dense: torch.Tensor,
                           n_probes: int = 5,
                           A_sparse: torch.Tensor | None = None) -> torch.Tensor:
    """Penalize poor approximation property via matrix-free Hutchinson estimator.

    Estimates ‖(I − P Pᵀ A / tr(A)) z‖² without forming any n×n matrix.
    """
    n = A_dense.shape[0]
    tr_A = A_dense.diagonal().sum()
    z = (torch.randint(0, 2, (n, n_probes), device=A_dense.device).float() * 2 - 1)
    if A_sparse is not None:
        Az = torch.sparse.mm(A_sparse, z)
    else:
        Az = A_dense @ z
    PtAz = P_dense.T @ Az          # (n_c, n_probes)
    PPtAz = P_dense @ PtAz         # (n, n_probes)
    diff_z = z - PPtAz / (tr_A + 1e-20)   # (I - PP^T A / tr(A)) z
    tr_est = (diff_z * diff_z).sum(0).mean()
    return tr_est / n


# ---------------------------------------------------------------
# 7. DMLE 单样本损失
# ---------------------------------------------------------------
def dmle_loss_single(
    A_csr: sp.csr_matrix,
    logits: torch.Tensor,
    tau: float = 0.5,
    theta: float = 0.25,
    lam_rho: float = 1.0,
    lam_complex: float = 0.1,
    lam_smooth: float = 0.05,
    n_power: int = 15,
    training: bool = True,
) -> tuple[torch.Tensor, dict]:
    """计算单个矩阵的 DMLE 损失.

    Args:
        A_csr: scipy sparse matrix (n, n)
        logits: (n,) GNN output logits (C-logit)
        tau: Gumbel-Softmax temperature
        theta: strength threshold
        lam_rho, lam_complex, lam_smooth: loss weights

    Returns:
        loss: scalar tensor (differentiable)
        info: dict with rho, n_c, etc.
    """
    n = A_csr.shape[0]
    device = logits.device

    # 1. Gumbel-Softmax C/F decision
    cf_soft = gumbel_softmax_cf(logits, tau=tau, hard=True, training=training)

    # 2. Strong connections
    strong_edges = strength_matrix_torch(A_csr, theta=theta).to(device)

    # 3. Build differentiable P (dense A needed for per-element access in P assembly)
    A_dense = torch.tensor(A_csr.toarray(), dtype=torch.float32, device=device)
    A_sparse = _sparse_from_csr(A_csr, device)
    P_dense = build_P_differentiable(A_dense, cf_soft, strong_edges)

    n_c = P_dense.shape[1]
    if n_c == 0 or n_c >= n:
        return torch.tensor(10.0, device=device, requires_grad=True), {"rho": 10.0, "n_c": n_c}

    # 4. Two-grid error operator spectral radius (matrix-free, sparse A)
    E_TG = two_grid_error_op(A_dense, P_dense, n_smooth=1,
                             A_sparse=A_sparse)
    rho = spectral_radius_power(E_TG, n, n_iters=n_power, device=device)

    # 5. Regularizers
    reg_complex = complexity_regularizer(P_dense, n)
    reg_smooth = smoothness_regularizer(A_dense, P_dense, A_sparse=A_sparse)

    # 6. Combined loss
    loss = lam_rho * rho + lam_complex * reg_complex + lam_smooth * reg_smooth

    info = {
        "rho": rho.item(),
        "n_c": n_c,
        "grid_complexity": n_c / n,
        "reg_smooth": reg_smooth.item(),
    }
    return loss, info


# ---------------------------------------------------------------
# 8. DMLE batch 损失 (对接训练循环)
# ---------------------------------------------------------------
def dmle_loss_batch(
    model,
    batch_data,  # list of (A_csr, pyg_data) tuples
    tau: float = 0.5,
    theta: float = 0.25,
    lam_rho: float = 1.0,
    lam_complex: float = 0.1,
    lam_smooth: float = 0.05,
    n_power: int = 15,
    device: str = "cpu",
) -> tuple[torch.Tensor, list[dict]]:
    """对 batch 中每个矩阵计算 DMLE 损失并平均.

    Args:
        model: CFClassifier
        batch_data: list of (A_csr, pyg_data)

    Returns:
        total_loss: averaged loss
        infos: per-sample info dicts
    """
    total_loss = torch.tensor(0.0, device=device)
    infos = []
    for A_csr, data in batch_data:
        x = data.x.to(device)
        edge_index = data.edge_index.to(device)
        ea = None
        if getattr(model, "uses_edge_attr", False) and \
                getattr(data, "edge_attr", None) is not None:
            ea = data.edge_attr.to(device)
        logits = model(x, edge_index, ea)  # (n,)
        loss, info = dmle_loss_single(
            A_csr, logits, tau=tau, theta=theta,
            lam_rho=lam_rho, lam_complex=lam_complex,
            lam_smooth=lam_smooth, n_power=n_power,
        )
        total_loss = total_loss + loss
        infos.append(info)
    return total_loss / max(len(batch_data), 1), infos


# ---------------------------------------------------------------
# 8b. 多层 DMLE batch 损失 (trains GNN on full V-cycle, not two-grid)
# ---------------------------------------------------------------
def dmle_loss_batch_multilevel(
    model,
    batch_data,
    tau: float = 0.5,
    theta: float = 0.25,
    lam_rho: float = 1.0,
    lam_complex: float = 0.1,
    lam_smooth: float = 0.05,
    lam_kappa: float = 0.0,
    n_power: int = 15,
    m_lanczos: int = 12,
    max_levels: int = 3,
    min_coarse: int = 40,
    device: str = "cpu",
) -> tuple[torch.Tensor, list[dict]]:
    """Multilevel DMLE: loss = ρ(full V-cycle error op) + λ_κ·κ̂(M⁻¹A).

    The GNN is applied recursively at every coarsening level so the trained
    splitting composes well multilevel (not merely two-grid).

    Direction 2 — when ``lam_kappa > 0`` the loss also minimizes a
    differentiable Lanczos estimate of the OSC-certified condition number
    κ(M⁻¹A) = C/c. This is the *same quantity* the OSC interval bounds,
    so training directly tightens the operational_bound → sharper AIK k_max.
    """
    total_loss = torch.tensor(0.0, device=device)
    infos = []
    for A_csr, _data in batch_data:
        n = A_csr.shape[0]
        A_dense = torch.tensor(A_csr.toarray(), dtype=torch.float32,
                               device=device)
        E0, n_c_top = multilevel_error_op(
            A_dense, A_csr, model, tau, theta, device,
            max_levels=max_levels, min_coarse=min_coarse, n_smooth=1,
        )
        if E0 is None:
            loss = torch.tensor(10.0, device=device, requires_grad=True)
            total_loss = total_loss + loss
            infos.append({"rho": 10.0, "n_c": 0, "degenerate": True})
            continue
        rho = spectral_radius_power(E0, n, n_iters=n_power, device=device)
        # Light complexity reg from top-level C-fraction
        reg_complex = torch.tensor(n_c_top / n, device=device)
        loss = lam_rho * rho + lam_complex * reg_complex

        kappa_val = None
        if lam_kappa > 0.0:
            # M⁻¹A = I − E ; minimize its OSC condition number κ̂ = C/c
            MA_op = lambda v: v - E0(v)
            kappa = differentiable_kappa(MA_op, n, m=m_lanczos,
                                         device=device)
            # log1p keeps the term well-scaled vs ρ∈[0,1]
            loss = loss + lam_kappa * torch.log1p(kappa)
            kappa_val = float(kappa.item())

        total_loss = total_loss + loss
        infos.append({"rho": rho.item(), "n_c": n_c_top,
                      "grid_complexity": n_c_top / n,
                      "kappa_hat": kappa_val})
    return total_loss / max(len(batch_data), 1), infos


# ---------------------------------------------------------------
# 9. Temperature annealing schedule
# ---------------------------------------------------------------
def tau_schedule(epoch: int, total_epochs: int,
                 tau_start: float = 2.0, tau_end: float = 0.1) -> float:
    """Exponential temperature annealing: high tau -> low tau.

    Early training: soft decisions (exploration).
    Late training: hard decisions (exploitation).
    """
    decay = (tau_end / tau_start) ** (epoch / max(total_epochs - 1, 1))
    return tau_start * decay


# ---------------------------------------------------------------
# 10. Self-test
# ---------------------------------------------------------------
if __name__ == "__main__":
    import pyamg
    from .graph_features import to_pyg_data
    from .gnn_model import CFClassifier

    torch.manual_seed(0)
    np.random.seed(0)

    # Small Poisson 2D
    n = 8
    A = pyamg.gallery.poisson((n, n), format="csr")
    N = A.shape[0]
    print(f"Test matrix: Poisson {n}x{n}, N={N}")

    # Build PyG data
    data = to_pyg_data(A, labels=None)

    # Simple model
    model = CFClassifier(hidden=32, layers=2)
    model.train()

    # Forward pass
    logits = model(data.x, data.edge_index)
    loss, info = dmle_loss_single(A, logits, tau=1.0)
    print(f"DMLE loss = {loss.item():.4f}, rho = {info['rho']:.4f}, n_c = {info['n_c']}")

    # Backward pass
    loss.backward()
    grad_norm = sum(p.grad.norm().item() for p in model.parameters() if p.grad is not None)
    print(f"Gradient norm = {grad_norm:.4e} (should be > 0 for differentiability)")

    # Temperature schedule
    for ep in [0, 25, 50, 75, 99]:
        t = tau_schedule(ep, 100)
        print(f"  epoch {ep:3d}: tau = {t:.3f}")

    print("\nDMLE self-test PASSED ✓")

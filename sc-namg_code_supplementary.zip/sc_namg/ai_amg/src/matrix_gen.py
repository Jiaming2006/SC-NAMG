"""矩阵生成 & 加载.

四类矩阵：
    * 2D / 3D Poisson        有限差分离散化
    * 各向异性扩散            旋转角 theta, 各向异性比 epsilon
    * 随机 SPD 稀疏矩阵        A = B B^T + alpha I
    * 用户提供的 .mtx / .npz   直接读入
"""
from __future__ import annotations
from pathlib import Path
from typing import Optional

import numpy as np
import scipy.sparse as sp
from scipy.io import mmread


# ----------------------- 结构化离散矩阵 -----------------------

def poisson_2d(n: int) -> sp.csr_matrix:
    """在 n×n 单位正方形上的 5-点 Laplacian, 总未知数 N = n*n."""
    N = n * n
    main = 4.0 * np.ones(N)
    side = -np.ones(N - 1)
    side[np.arange(1, N) % n == 0] = 0  # 去掉跨行连接
    updown = -np.ones(N - n)
    A = sp.diags([updown, side, main, side, updown],
                 offsets=[-n, -1, 0, 1, n], format="csr")
    return A


def poisson_3d(n: int) -> sp.csr_matrix:
    """3D Poisson 7-点差分, 未知数 n^3."""
    e = np.ones(n)
    T = sp.diags([-e[:-1], 2 * e, -e[:-1]], [-1, 0, 1], shape=(n, n))
    I = sp.eye(n)
    A2 = sp.kron(I, T) + sp.kron(T, I)
    A3 = sp.kron(I, A2) + sp.kron(T, sp.kron(I, I))
    return A3.tocsr()


def anisotropic_2d(n: int, epsilon: float = 0.01, theta: float = 0.0) -> sp.csr_matrix:
    """旋转各向异性扩散: -∇·(K ∇u), K = R(θ) diag(1, ε) R(θ)^T, 9-点差分."""
    c, s = np.cos(theta), np.sin(theta)
    a_xx = c * c + epsilon * s * s
    a_yy = s * s + epsilon * c * c
    a_xy = (1.0 - epsilon) * c * s

    h = 1.0 / (n + 1)
    inv_h2 = 1.0 / (h * h)

    N = n * n
    rows, cols, vals = [], [], []

    def add(r, c_, v):
        rows.append(r)
        cols.append(c_)
        vals.append(v)

    for i in range(n):
        for j in range(n):
            k = i * n + j
            center = 2.0 * (a_xx + a_yy) * inv_h2
            add(k, k, center)
            if j < n - 1: add(k, k + 1, -a_xx * inv_h2)
            if j > 0:     add(k, k - 1, -a_xx * inv_h2)
            if i < n - 1: add(k, k + n, -a_yy * inv_h2)
            if i > 0:     add(k, k - n, -a_yy * inv_h2)
            if i < n - 1 and j < n - 1: add(k, k + n + 1, -0.5 * a_xy * inv_h2)
            if i > 0 and j > 0:         add(k, k - n - 1, -0.5 * a_xy * inv_h2)
            if i < n - 1 and j > 0:     add(k, k + n - 1,  0.5 * a_xy * inv_h2)
            if i > 0 and j < n - 1:     add(k, k - n + 1,  0.5 * a_xy * inv_h2)

    A = sp.csr_matrix((vals, (rows, cols)), shape=(N, N))
    # 数值对称化, 抑制浮点误差
    A = 0.5 * (A + A.T)
    return A.tocsr()


# ----------------------- 跳跃扩散 (jump diffusion) -----------------------

def jump_diffusion_2d(n: int, contrast: float = 1e4,
                      n_inclusions: int = 5,
                      seed: Optional[int] = None) -> sp.csr_matrix:
    """2D diffusion with random high-contrast inclusions.

    -div(k(x) grad u) on [0,1]^2, 5-point FD.
    k(x) = 1 outside inclusions, k(x) = contrast inside random circular regions.
    """
    rng = np.random.default_rng(seed)
    N = n * n
    h = 1.0 / (n + 1)
    inv_h2 = 1.0 / (h * h)

    # Generate random circular inclusions
    centers = rng.uniform(0.2, 0.8, size=(n_inclusions, 2))
    radii = rng.uniform(0.05, 0.15, size=n_inclusions)

    # Vectorized coefficient field k(x,y): shape (n, n), index [i, j]
    jj, ii = np.meshgrid(np.arange(n), np.arange(n))
    xs = (jj + 1) * h
    ys = (ii + 1) * h
    kfield = np.ones((n, n))
    for (cx, cy), r in zip(centers, radii):
        inside = (xs - cx) ** 2 + (ys - cy) ** 2 < r ** 2
        kfield[inside] = contrast

    def harmonic(a, b):
        return 2.0 * a * b / (a + b)

    rows, cols, data = [], [], []
    node = np.arange(N).reshape(n, n)  # node[i, j] = i*n + j
    diag = np.zeros((n, n))

    # Right neighbor (j -> j+1)
    kf = harmonic(kfield[:, :-1], kfield[:, 1:]) * inv_h2
    rows.append(node[:, :-1].ravel()); cols.append(node[:, 1:].ravel())
    data.append(-kf.ravel())
    diag[:, :-1] += kf
    diag[:, -1] += kfield[:, -1] * inv_h2

    # Left neighbor (j -> j-1)
    kf = harmonic(kfield[:, 1:], kfield[:, :-1]) * inv_h2
    rows.append(node[:, 1:].ravel()); cols.append(node[:, :-1].ravel())
    data.append(-kf.ravel())
    diag[:, 1:] += kf
    diag[:, 0] += kfield[:, 0] * inv_h2

    # Top neighbor (i -> i+1)
    kf = harmonic(kfield[:-1, :], kfield[1:, :]) * inv_h2
    rows.append(node[:-1, :].ravel()); cols.append(node[1:, :].ravel())
    data.append(-kf.ravel())
    diag[:-1, :] += kf
    diag[-1, :] += kfield[-1, :] * inv_h2

    # Bottom neighbor (i -> i-1)
    kf = harmonic(kfield[1:, :], kfield[:-1, :]) * inv_h2
    rows.append(node[1:, :].ravel()); cols.append(node[:-1, :].ravel())
    data.append(-kf.ravel())
    diag[1:, :] += kf
    diag[0, :] += kfield[0, :] * inv_h2

    rows.append(node.ravel()); cols.append(node.ravel())
    data.append(diag.ravel())

    A = sp.csr_matrix(
        (np.concatenate(data), (np.concatenate(rows), np.concatenate(cols))),
        shape=(N, N),
    )
    A = 0.5 * (A + A.T)
    return A.tocsr()


# ----------------------- 随机 SPD -----------------------

def random_spd_sparse(n: int, density: float = 0.01,
                      seed: Optional[int] = None) -> sp.csr_matrix:
    """生成一个 n×n 随机稀疏 SPD 矩阵.

    A = B B^T + (1 + u) I, 其中 u ∈ U(0,1), 保证良态并对角占优."""
    rng = np.random.default_rng(seed)
    B = sp.random(n, n, density=density, format="csr", random_state=rng)
    shift = 1.0 + rng.random()
    A = B @ B.T + sp.eye(n) * shift
    return A.tocsr()


# ----------------------- 自定义加载 -----------------------

def load_matrix(path: str | Path) -> sp.csr_matrix:
    """读 .mtx 或 .npz. .npz 支持 CSR 三元组或键 'A'."""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(p)
    if p.suffix.lower() == ".mtx":
        return sp.csr_matrix(mmread(str(p)))
    if p.suffix.lower() == ".npz":
        data = np.load(p, allow_pickle=False)
        keys = set(data.files)
        if {"data", "indices", "indptr", "shape"} <= keys:
            return sp.csr_matrix(
                (data["data"], data["indices"], data["indptr"]),
                shape=tuple(data["shape"]),
            )
        if "A" in keys:
            return sp.csr_matrix(data["A"])
    raise ValueError(f"无法识别的矩阵文件: {path}")


# ----------------------- 工厂 -----------------------

def generate(kind: str, n: int, **kwargs) -> sp.csr_matrix:
    """统一入口. kind ∈ {poisson_2d, poisson_3d, anisotropic_2d, random_spd}."""
    if kind == "poisson_2d":
        return poisson_2d(n)
    if kind == "poisson_3d":
        return poisson_3d(n)
    if kind == "anisotropic_2d":
        return anisotropic_2d(n, **kwargs)
    if kind == "random_spd":
        return random_spd_sparse(n, **kwargs)
    if kind == "jump_diffusion_2d":
        return jump_diffusion_2d(n, **kwargs)
    raise ValueError(f"未知矩阵类型: {kind}")


def random_rhs(A: sp.csr_matrix, seed: Optional[int] = None) -> np.ndarray:
    """生成与 A 匹配的 RHS: b = A x*, x* 随机."""
    rng = np.random.default_rng(seed)
    x_star = rng.standard_normal(A.shape[0])
    return A @ x_star

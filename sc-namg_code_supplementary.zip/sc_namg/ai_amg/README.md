# ai_amg — SC-NAMG 核心模块

GNN 加速 AMG C/F 分裂 + 谱认证收敛保证。

## 模块说明

| 文件 | 功能 |
|------|------|
| `amg_solver.py` | 多层 V-cycle 求解器，含 `solve_certified()` ��到端认证 |
| `spectral_certificate.py` | OSC: Lanczos 三对角化 + SLQ 谱��估计 |
| `aik_krylov.py` | AIK: 截断 Flexible CG (Notay 2000) |
| `dmle_loss.py` | DMLE: Gumbel-Softmax + 可微 ρ(E_TG) 损失 |
| `dmle_trainer.py` | DMLE 训练循环 (温度退火 + cosine LR) |
| `gnn_model.py` | GraphSAGE C/F 二分类网络 |
| `gnn_trainer.py` | BCE 监督训练 (模仿 RS 标签) |
| `gnn_dataset.py` | 多类型矩阵采��� + PyG Data 构造 |
| `graph_features.py` | 节点/边特征提取 (7 维节点 + 2 维边) |
| `cf_splitting.py` | 经典 Ruge-Stuben 分裂 (真值标签) |
| `matrix_gen.py` | 矩阵生成: Poisson 2D/3D, 各向异性, 随机 SPD |

## 运行测试

```bash
python -m pytest tests/ -v
```

## 快速求解

```python
from src.amg_solver import AISolver
from src import matrix_gen

A = matrix_gen.poisson_2d(64)
b = matrix_gen.random_rhs(A)

solver = AISolver(model=None, tol=1e-8).setup(A)
x, cert = solver.solve_certified(b, tol=1e-8)
print(f"converged in {cert['k_used']} iters, res={cert['final_residual']:.2e}")
```

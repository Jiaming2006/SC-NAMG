#!/usr/bin/env python3
"""
bench/run.py — SC-NAMG 统一评测 harness
==========================================

Phase 0 (W1–W2) 主文件. 后续所有阶段的实验都基于这套接口.

用法::

    python bench/run.py --solver pyamg_rs   --matrix poisson_2d_256 --tol 1e-8 --repeat 5
    python bench/run.py --solver ai_amg     --matrix bcsstk16       --tol 1e-8 --repeat 5
    python bench/run.py --solver sc_namg    --matrix poisson_3d_64  --tol 1e-8 --repeat 5

输出 JSON 到 stdout, 结构::

    {
        "solver": "...",
        "matrix": "...",
        "n": 65536,
        "nnz": ...,
        "tol": 1e-8,
        "runs": [
            {"iters": 23, "time_setup": 0.12, "time_solve": 0.34,
             "final_residual": 9.1e-9, "ok": true},
            ...
        ],
        "summary": {
            "iters_mean": 23.4, "iters_std": 0.8,
            "time_total_mean": 0.47, "time_total_std": 0.03,
            "convergence_rate": 1.0
        }
    }

待办:
    [ ] sc_namg 路径 (Phase 2 完成后接入)
    [ ] SuiteSparse 矩阵下载脚本 bench/download_suitesparse.py
    [ ] 与 experiments/exp*/run.py 协调输出目录
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path

import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla


# ============================================================
# 1. 矩阵加载 (delegated to loaders.py)
# ============================================================
from ai_amg.bench.loaders import load_matrix


# ============================================================
# 2. 求解器封装
# ============================================================
def solve_pyamg_rs(A, b, tol):
    import pyamg
    t0 = time.perf_counter()
    ml = pyamg.classical.ruge_stuben_solver(A)
    t_setup = time.perf_counter() - t0
    res = []
    t1 = time.perf_counter()
    x = ml.solve(b, tol=tol, residuals=res, maxiter=200)
    t_solve = time.perf_counter() - t1
    return x, len(res), t_setup, t_solve, float(np.linalg.norm(b - A @ x) / (np.linalg.norm(b) + 1e-30))


def solve_pyamg_sa(A, b, tol):
    import pyamg
    t0 = time.perf_counter()
    ml = pyamg.smoothed_aggregation_solver(A)
    t_setup = time.perf_counter() - t0
    res = []
    t1 = time.perf_counter()
    x = ml.solve(b, tol=tol, residuals=res, maxiter=200)
    t_solve = time.perf_counter() - t1
    return x, len(res), t_setup, t_solve, float(np.linalg.norm(b - A @ x) / (np.linalg.norm(b) + 1e-30))


def solve_pyamg_cg(A, b, tol):
    """对照: 不带预条件的纯 CG."""
    t0 = time.perf_counter()
    t_setup = time.perf_counter() - t0
    res = []
    cb = lambda xk: res.append(float(np.linalg.norm(b - A @ xk)))
    t1 = time.perf_counter()
    x, info = spla.cg(A, b, rtol=tol, maxiter=2000, callback=cb)
    t_solve = time.perf_counter() - t1
    return x, len(res), t_setup, t_solve, float(np.linalg.norm(b - A @ x) / (np.linalg.norm(b) + 1e-30))


def solve_ai_amg(A, b, tol):
    """调用现有 ai_amg AISolver."""
    try:
        from ai_amg.src.amg_solver import AISolver
    except ImportError:
        from src.amg_solver import AISolver
    t0 = time.perf_counter()
    solver = AISolver(model=None, tol=tol, max_iter=200)   # --no-model 模式作 baseline
    solver.setup(A)
    t_setup = time.perf_counter() - t0
    t1 = time.perf_counter()
    x, hist = solver.solve(b)
    t_solve = time.perf_counter() - t1
    # AISolver.solve returns (x, SolveHistory); iters = #residuals - 1
    if isinstance(hist, dict):
        iters = hist.get("iters", -1)
    else:
        iters = max(len(getattr(hist, "residuals", [])) - 1, 0)
    return x, iters, t_setup, t_solve, float(np.linalg.norm(b - A @ x) / (np.linalg.norm(b) + 1e-30))


def solve_sc_namg(A, b, tol):
    """SC-NAMG: OSC + AIK OSC-monitored solve."""
    try:
        from ai_amg.src.amg_solver import AISolver
    except ImportError:
        from src.amg_solver import AISolver
    t0 = time.perf_counter()
    solver = AISolver(model=None, tol=tol, max_iter=200)
    solver.setup(A)
    t_setup = time.perf_counter() - t0
    t1 = time.perf_counter()
    x, cert = solver.solve_certified(b, tol=tol)
    t_solve = time.perf_counter() - t1
    iters = cert.get("k_used", -1)
    return x, iters, t_setup, t_solve, float(np.linalg.norm(b - A @ x) / (np.linalg.norm(b) + 1e-30))


SOLVERS = {
    "pyamg_rs": solve_pyamg_rs,
    "pyamg_sa": solve_pyamg_sa,
    "pyamg_cg": solve_pyamg_cg,
    "ai_amg": solve_ai_amg,
    "sc_namg": solve_sc_namg,
}

# Optional learned-preconditioner baselines (NeurIF / GNP). They print
# "[SKIP] ... not installed" and are excluded unless the package is
# importable or registered via neurif_gnp_proxy.register_baseline().
try:
    from ai_amg.bench.baselines.neurif_gnp_proxy import (
        solve_neurif, solve_gnp)
except ImportError:
    from bench.baselines.neurif_gnp_proxy import (  # type: ignore
        solve_neurif, solve_gnp)
SOLVERS["neurif"] = solve_neurif
SOLVERS["gnp"] = solve_gnp


# ============================================================
# 3. 主入口
# ============================================================
def main():
    p = argparse.ArgumentParser()
    p.add_argument("--solver", required=True, choices=list(SOLVERS.keys()))
    p.add_argument("--matrix", required=True, help="e.g. poisson_2d_256")
    p.add_argument("--tol", type=float, default=1e-8)
    p.add_argument("--repeat", type=int, default=5)
    p.add_argument("--out", default=None, help="JSON 输出文件 (默认 stdout)")
    args = p.parse_args()

    A, b, meta = load_matrix(args.matrix)
    solver_fn = SOLVERS[args.solver]

    runs = []
    for r in range(args.repeat):
        try:
            x, iters, t_setup, t_solve, final_res = solver_fn(A, b, args.tol)
            runs.append({
                "iters": int(iters),
                "time_setup": float(t_setup),
                "time_solve": float(t_solve),
                "final_residual": float(final_res),
                "ok": final_res <= 10 * args.tol,
            })
        except Exception as e:
            runs.append({"error": repr(e), "ok": False})

    ok_runs = [r for r in runs if r.get("ok")]
    summary = {}
    if ok_runs:
        iters_arr = np.array([r["iters"] for r in ok_runs])
        time_arr = np.array([r["time_setup"] + r["time_solve"] for r in ok_runs])
        summary = {
            "iters_mean": float(iters_arr.mean()), "iters_std": float(iters_arr.std()),
            "time_total_mean": float(time_arr.mean()), "time_total_std": float(time_arr.std()),
            "convergence_rate": len(ok_runs) / len(runs),
        }

    output = {
        "solver": args.solver, "matrix": args.matrix,
        "meta": meta, "tol": args.tol,
        "runs": runs, "summary": summary,
    }

    blob = json.dumps(output, indent=2, ensure_ascii=False)
    if args.out:
        os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
        with open(args.out, "w") as f:
            f.write(blob)
        print(f"written: {args.out}")
    else:
        print(blob)


if __name__ == "__main__":
    main()

"""
neurif_gnp_proxy.py — NeurIF / GNP baseline comparison proxy
============================================================

The submission checklist asks for a NeurIF / GNP comparison (≥ 1 figure
+ 1 table). Neither package is a hard dependency of this repo, so this
module provides two honest paths (review "强方案" + "折中方案"):

1. **Thin wrapper** — if ``neurif`` / ``gnp`` (or a user-registered
   callable) is importable, run it and return real numbers.
2. **Cited fallback** — otherwise emit a clearly-provenanced row whose
   numbers come *from the original papers*. We do NOT fabricate values:
   the cited table is pre-seeded with ``None`` + the exact citation
   string; the user fills the figures reported in the referenced paper.
   A missing/un-filled baseline is reported as ``skipped``, never faked.

Solver signature matches ``ai_amg/bench/run.py``::

    solve_xxx(A, b, tol) -> (x, iters, t_setup, t_solve, rel_residual)
"""
from __future__ import annotations

import time
from typing import Callable

import numpy as np

SKIP = "__SKIP__"

# ---------------------------------------------------------------
# Cited baselines — provenance only, NO fabricated numbers.
# Fill `iters` / `rho` from the cited table, then they appear in the
# comparison automatically. Left as None ⇒ reported as "cited (TODO)".
# ---------------------------------------------------------------
CITED_BASELINES = {
    "neurif": {
        # NeurIF results cited from Häusner et al., TMLR 2024, Table 3
        "citation": "Häusner et al., 'Neural incomplete factorization', "
                    "TMLR 2024, Table 3",
        "by_class": {
            # matrix-class -> {"iters": <fill>, "rho": <fill>}
            "poisson_2d":     {"iters": None, "rho": None},
            "anisotropic_2d": {"iters": None, "rho": None},
            "suitesparse":    {"iters": None, "rho": None},
        },
    },
    "gnp": {
        # GNP results cited from Li et al., 'Learning preconditioners',
        # NeurIPS 2023, Table 2
        "citation": "Li et al., 'Learning preconditioners with GNNs', "
                    "NeurIPS 2023, Table 2",
        "by_class": {
            "poisson_2d":     {"iters": None, "rho": None},
            "anisotropic_2d": {"iters": None, "rho": None},
            "suitesparse":    {"iters": None, "rho": None},
        },
    },
}

# Optional user-registered runnable baselines:
#   register_baseline("neurif", fn)  where fn(A,b,tol)->(x,iters,ts,tsv,res)
_REGISTRY: dict[str, Callable] = {}


def register_baseline(name: str, fn: Callable) -> None:
    _REGISTRY[name.lower()] = fn


def _try_import(name: str):
    try:
        return __import__(name)
    except Exception:
        return None


def _solve_via(name: str, A, b, tol):
    """Run a baseline if a runnable is available, else return SKIP."""
    if name in _REGISTRY:
        return _REGISTRY[name](A, b, tol)
    mod = _try_import(name)
    if mod is None:
        print(f"[SKIP] {name} not installed "
              f"(register_baseline('{name}', fn) to enable)")
        return SKIP
    # Best-effort adapter: expect mod.solve(A, b, tol) -> (x, iters)
    solve = getattr(mod, "solve", None)
    if solve is None:
        print(f"[SKIP] {name} importable but has no solve(A,b,tol)")
        return SKIP
    t0 = time.perf_counter()
    x, iters = solve(A, b, tol)
    dt = time.perf_counter() - t0
    res = float(np.linalg.norm(b - A @ x) / (np.linalg.norm(b) + 1e-30))
    return x, int(iters), 0.0, dt, res


def solve_neurif(A, b, tol):
    return _solve_via("neurif", A, b, tol)


def solve_gnp(A, b, tol):
    return _solve_via("gnp", A, b, tol)


# ---------------------------------------------------------------
# Comparison table / figure builder
# ---------------------------------------------------------------
def _matrix_class(name: str) -> str:
    if name.startswith("poisson"):
        return "poisson_2d"
    if name.startswith("anisotropic"):
        return "anisotropic_2d"
    if name.startswith(("jump", "random")):
        return "anisotropic_2d"
    return "suitesparse"


def build_comparison(exp4_results: dict) -> dict:
    """Merge real SC-NAMG / AMG-PCG numbers (from exp4_benchmark
    results.json) with NeurIF / GNP rows (run / cited / skipped).

    Returns a dict with `rows` (per-matrix) and `summary`.
    """
    rows = []
    for r in exp4_results.get("results", []):
        if "error" in r:
            continue
        m = r["methods"]
        cls = _matrix_class(r["matrix"])
        row = {
            "matrix": r["matrix"], "n": r["n"], "class": cls,
            "amg_pcg": m.get("amg_pcg", {}).get("iters"),
            "sc_namg": m.get("sc_namg", {}).get("iters"),
        }
        for bl in ("neurif", "gnp"):
            cited = CITED_BASELINES[bl]["by_class"].get(cls, {})
            row[bl] = cited.get("iters")          # None ⇒ TODO/cited
            row[f"{bl}_status"] = ("cited" if cited.get("iters")
                                   is not None else "cited-TODO")
        rows.append(row)

    summary = {
        "n_matrices": len(rows),
        "sc_namg_mean_iters": float(np.mean(
            [x["sc_namg"] for x in rows if x["sc_namg"]])) if rows else None,
        "neurif_citation": CITED_BASELINES["neurif"]["citation"],
        "gnp_citation": CITED_BASELINES["gnp"]["citation"],
        "note": "NeurIF/GNP numbers are cited from the referenced papers; "
                "un-filled entries are marked cited-TODO and never faked. "
                "Install/register the packages for live runs.",
    }
    return {"rows": rows, "summary": summary}


def to_markdown(cmp: dict) -> str:
    h = "| Matrix | n | class | AMG-PCG | SC-NAMG | NeurIF | GNP |\n"
    h += "|--------|---|-------|---------|---------|--------|-----|\n"
    for r in cmp["rows"]:
        def cell(v, st=None):
            if v is None:
                return "cited†" if st == "cited-TODO" else "—"
            return str(v)
        h += (f"| {r['matrix']} | {r['n']} | {r['class']} | "
              f"{cell(r['amg_pcg'])} | {cell(r['sc_namg'])} | "
              f"{cell(r['neurif'], r['neurif_status'])} | "
              f"{cell(r['gnp'], r['gnp_status'])} |\n")
    h += (f"\n† cited from: {cmp['summary']['neurif_citation']}; "
          f"{cmp['summary']['gnp_citation']}\n")
    return h

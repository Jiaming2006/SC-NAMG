#!/usr/bin/env python3
"""Download SPD matrices from the SuiteSparse Matrix Collection.

Fetches Matrix-Market (.mtx) files into ``ai_amg/data/suitesparse/`` so the
benchmark can run on real engineering matrices, not just synthetic ones.

Usage::

    python -m ai_amg.bench.download_suitesparse                 # default set
    python -m ai_amg.bench.download_suitesparse bcsstk16 nasa2910
    python -m ai_amg.bench.download_suitesparse --list

Source: https://sparse.tamu.edu  (SuiteSparse Matrix Collection, Davis & Hu).
Only small/medium SPD matrices are listed by default.
"""
from __future__ import annotations

import argparse
import sys
import tarfile
import tempfile
import urllib.request
from pathlib import Path

SUITESPARSE_DIR = Path(__file__).parent.parent / "data" / "suitesparse"

# name -> SuiteSparse group (needed to build the download URL).
# 20 SPD matrices spanning structural mechanics, fluids, heat, FEM,
# circuits — the submission-checklist standard benchmark set.
KNOWN = {
    # --- structural mechanics ---
    "bcsstk16": "HB",            # 4884    structural
    "bcsstk27": "HB",            # 1224    structural
    "bcsstk17": "HB",            # 10974   structural
    "bcsstk18": "HB",            # 11948   structural
    "bcsstk25": "HB",            # 15439   structural
    "msc23052": "Boeing",        # 23052   structural
    "nasa2910": "Nasa",          # 2910    structural
    "1138_bus": "HB",            # 1138    power grid
    "nos7": "HB",                # 729     structural
    "s3rmt3m3": "Cylshell",      # 5357    shell
    # --- FEM ---
    "ex15": "FIDAP",             # 6867    FEM
    "parabolic_fem": "Wissgott", # 525825  parabolic FEM
    "af_5_k101": "Schenk_AFE",   # 503625  FEM
    "BenElechi1": "Oberwolfach", # 245874  FEM
    "apache2": "GHS_psdef",      # 715176  structural FEM
    # --- diffusion / heat / fluids ---
    "ecology2": "McRae",         # 999999  diffusion
    "thermal2": "Schmid",        # 1228045 heat conduction
    "sherman5": "HB",            # 3312    fluid
    "Pres_Poisson": "ACUSIM",    # 14822   CFD pressure-Poisson
    # --- circuit ---
    "G3_circuit": "AMD",         # 1585478 circuit
}

BASE = "https://suitesparse-collection-website.herokuapp.com/MM/{group}/{name}.tar.gz"
MIRROR = "https://sparse.tamu.edu/MM/{group}/{name}.tar.gz"


def _download(url: str, dst: Path) -> bool:
    try:
        print(f"  GET {url}")
        req = urllib.request.Request(url, headers={"User-Agent": "sc-namg/1.0"})
        with urllib.request.urlopen(req, timeout=120) as r, open(dst, "wb") as f:
            f.write(r.read())
        return True
    except Exception as e:  # noqa: BLE001
        print(f"  failed: {e}")
        return False


def fetch(name: str) -> Path | None:
    """Download + extract one matrix; returns path to the .mtx or None."""
    group = KNOWN.get(name)
    if group is None:
        print(f"[skip] unknown matrix '{name}' (not in KNOWN map)")
        return None
    SUITESPARSE_DIR.mkdir(parents=True, exist_ok=True)
    target = SUITESPARSE_DIR / f"{name}.mtx"
    if target.exists():
        print(f"[have] {target}")
        return target

    with tempfile.TemporaryDirectory() as td:
        tgz = Path(td) / f"{name}.tar.gz"
        ok = _download(BASE.format(group=group, name=name), tgz) or \
            _download(MIRROR.format(group=group, name=name), tgz)
        if not ok:
            print(f"[fail] could not download {name}")
            return None
        with tarfile.open(tgz, "r:gz") as tar:
            members = [m for m in tar.getmembers()
                       if m.name.endswith(".mtx") and "_b" not in m.name]
            if not members:
                print(f"[fail] no .mtx in archive for {name}")
                return None
            m = members[0]
            with tar.extractfile(m) as src, open(target, "wb") as out:
                out.write(src.read())
    print(f"[ok]   {target}")
    return target


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("names", nargs="*",
                    help="matrix names (default: bcsstk16 nasa2910 s3rmt3m3)")
    ap.add_argument("--list", action="store_true",
                    help="list known matrices and exit")
    args = ap.parse_args()

    if args.list:
        print("Known SuiteSparse matrices (name : group):")
        for k, v in KNOWN.items():
            print(f"  {k:16s} {v}")
        return

    names = args.names or ["bcsstk16", "nasa2910", "s3rmt3m3"]
    print(f"Downloading {len(names)} matrices into {SUITESPARSE_DIR}")
    n_ok = 0
    for nm in names:
        if fetch(nm) is not None:
            n_ok += 1
    print(f"\nDone: {n_ok}/{len(names)} matrices available.")
    if n_ok < len(names):
        sys.exit(1)


if __name__ == "__main__":
    main()

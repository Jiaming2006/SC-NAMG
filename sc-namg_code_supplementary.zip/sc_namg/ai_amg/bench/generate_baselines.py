#!/usr/bin/env python3
"""
generate_baselines.py -- Run baseline solvers and save results
===============================================================

Phase 0 deliverable: creates baselines_pyamg.json and baselines_ai_amg.json.

Usage:
    python ai_amg/bench/generate_baselines.py
"""
from __future__ import annotations

import json
import os
import sys
import time

import numpy as np
import scipy.sparse.linalg as spla

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from ai_amg.bench.loaders import load_matrix


BASELINE_MATRICES = [
    "poisson_2d_16", "poisson_2d_32", "poisson_2d_64", "poisson_2d_128", "poisson_2d_256",
    "poisson_3d_8", "poisson_3d_16", "poisson_3d_32",
    "anisotropic_2d_16", "anisotropic_2d_32", "anisotropic_2d_64", "anisotropic_2d_128",
]

TOL = 1e-8
REPEAT = 5


def run_pyamg_rs(A, b, tol):
    import pyamg
    t0 = time.perf_counter()
    ml = pyamg.classical.ruge_stuben_solver(A)
    t_setup = time.perf_counter() - t0
    res = []
    t1 = time.perf_counter()
    x = ml.solve(b, tol=tol, residuals=res, maxiter=200)
    t_solve = time.perf_counter() - t1
    final = float(np.linalg.norm(b - A @ x) / (np.linalg.norm(b) + 1e-30))
    return {"iters": len(res), "time_setup": t_setup, "time_solve": t_solve,
            "final_residual": final, "ok": final <= 10 * tol}


def run_pyamg_sa(A, b, tol):
    import pyamg
    t0 = time.perf_counter()
    ml = pyamg.smoothed_aggregation_solver(A)
    t_setup = time.perf_counter() - t0
    res = []
    t1 = time.perf_counter()
    x = ml.solve(b, tol=tol, residuals=res, maxiter=200)
    t_solve = time.perf_counter() - t1
    final = float(np.linalg.norm(b - A @ x) / (np.linalg.norm(b) + 1e-30))
    return {"iters": len(res), "time_setup": t_setup, "time_solve": t_solve,
            "final_residual": final, "ok": final <= 10 * tol}


def run_ai_amg(A, b, tol):
    from ai_amg.src.amg_solver import AISolver
    t0 = time.perf_counter()
    solver = AISolver(model=None, tol=tol, max_iter=200)
    solver.setup(A)
    t_setup = time.perf_counter() - t0
    t1 = time.perf_counter()
    x, hist = solver.solve(b)
    t_solve = time.perf_counter() - t1
    final = float(np.linalg.norm(b - A @ x) / (np.linalg.norm(b) + 1e-30))
    return {"iters": len(hist.residuals), "time_setup": t_setup, "time_solve": t_solve,
            "final_residual": final, "ok": final <= 10 * tol,
            "n_levels": len(solver.levels)}


def run_baseline(solver_name, solver_fn, matrices, tol, repeat):
    results = {}
    for mid in matrices:
        print(f"  {solver_name} / {mid}...", end=" ", flush=True)
        try:
            A, b, meta = load_matrix(mid)
        except Exception as e:
            print(f"SKIP ({e})")
            continue

        runs = []
        for _ in range(repeat):
            try:
                r = solver_fn(A, b, tol)
                runs.append(r)
            except Exception as e:
                runs.append({"error": str(e), "ok": False})

        ok_runs = [r for r in runs if r.get("ok")]
        if ok_runs:
            iters_arr = np.array([r["iters"] for r in ok_runs])
            time_arr = np.array([r["time_setup"] + r["time_solve"] for r in ok_runs])
            summary = {
                "iters_mean": float(iters_arr.mean()),
                "iters_std": float(iters_arr.std()),
                "time_total_mean": float(time_arr.mean()),
                "time_total_std": float(time_arr.std()),
                "convergence_rate": len(ok_runs) / len(runs),
            }
        else:
            summary = {"convergence_rate": 0.0}

        results[mid] = {"meta": meta, "runs": runs, "summary": summary}
        status = f"iters={summary.get('iters_mean', 'N/A'):.0f}" if ok_runs else "FAILED"
        print(status)

    return results


def main():
    outdir = os.path.join(os.path.dirname(__file__), "baselines")
    os.makedirs(outdir, exist_ok=True)

    print("=" * 60)
    print("  Phase 0: Generating baselines")
    print("=" * 60)

    for name, fn, outfile in [
        ("pyamg_rs", run_pyamg_rs, "baselines_pyamg_rs.json"),
        ("pyamg_sa", run_pyamg_sa, "baselines_pyamg_sa.json"),
        ("ai_amg_v0", run_ai_amg, "baselines_ai_amg_v0.json"),
    ]:
        print(f"\n--- {name} ---")
        results = run_baseline(name, fn, BASELINE_MATRICES, TOL, REPEAT)
        path = os.path.join(outdir, outfile)
        with open(path, "w") as f:
            json.dump({"solver": name, "tol": TOL, "repeat": REPEAT,
                        "results": results}, f, indent=2, default=str)
        print(f"  -> {path}")

    print(f"\n{'=' * 60}")
    print("  Baselines generated successfully")
    print(f"{'=' * 60}")


if __name__ == "__main__":
    main()

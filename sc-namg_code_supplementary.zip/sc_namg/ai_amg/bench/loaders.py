"""
loaders.py -- Unified matrix loading for SC-NAMG benchmarks
============================================================

Supports:
  - pyamg built-in generators (Poisson 2D/3D, anisotropic diffusion)
  - SuiteSparse .mtx files  (data/suitesparse/)
  - Random SPD matrices
  - Custom .npz files

Usage:
    A, b, meta = load_matrix("poisson_2d_256")
    A, b, meta = load_matrix("anisotropic_2d_64")
    A, b, meta = load_matrix("bcsstk16")           # SuiteSparse
    names = list_available_matrices()
"""
from __future__ import annotations

import numpy as np
import scipy.sparse as sp
from pathlib import Path


SUITESPARSE_DIR = Path(__file__).parent.parent / "data" / "suitesparse"

BUILTIN_POISSON_2D = [16, 32, 64, 128, 256, 512]
BUILTIN_POISSON_3D = [8, 16, 32, 64]
BUILTIN_ANISOTROPIC = [16, 32, 64, 128, 256]


def load_matrix(matrix_id: str):
    """Load matrix by ID. Returns (A_csr, b, meta_dict)."""

    # --- Poisson 2D ---
    if matrix_id.startswith("poisson_2d_"):
        n = int(matrix_id.split("_")[-1])
        import pyamg
        A = pyamg.gallery.poisson((n, n), format="csr")
        b = np.ones(A.shape[0])
        return A, b, {"n": A.shape[0], "nnz": A.nnz, "type": "poisson_2d", "grid": n}

    # --- Poisson 3D ---
    if matrix_id.startswith("poisson_3d_"):
        n = int(matrix_id.split("_")[-1])
        import pyamg
        A = pyamg.gallery.poisson((n, n, n), format="csr")
        b = np.ones(A.shape[0])
        return A, b, {"n": A.shape[0], "nnz": A.nnz, "type": "poisson_3d", "grid": n}

    # --- Anisotropic 2D (axis-aligned θ=π/8, or rotated θ=π/4) ---
    if matrix_id.startswith("anisotropic_2d_"):
        parts = matrix_id.split("_")
        n = int(parts[2])
        rotated = "rot" in parts
        rest = [p for p in parts[3:] if p != "rot"]
        eps = float(rest[0]) if rest else 0.01
        theta = np.pi / 4.0 if rotated else np.pi / 8.0
        from ai_amg.src import matrix_gen
        A = matrix_gen.anisotropic_2d(n, epsilon=eps, theta=theta)
        b = np.ones(A.shape[0])
        return A, b, {"n": A.shape[0], "nnz": A.nnz,
                      "type": "anisotropic_2d", "grid": n,
                      "epsilon": eps, "theta": float(theta)}

    # --- Jump-diffusion 2D (high-contrast inclusions) ---
    if matrix_id.startswith("jump_diffusion_2d_"):
        parts = matrix_id.split("_")
        n = int(parts[3])
        contrast = float(parts[4]) if len(parts) > 4 else 1e4
        from ai_amg.src import matrix_gen
        A = matrix_gen.jump_diffusion_2d(n, contrast=contrast, seed=0)
        b = np.ones(A.shape[0])
        return A, b, {"n": A.shape[0], "nnz": A.nnz,
                      "type": "jump_diffusion_2d", "grid": n,
                      "contrast": contrast}

    # --- Random SPD ---
    if matrix_id.startswith("random_spd_"):
        parts = matrix_id.split("_")
        n = int(parts[2])
        seed = int(parts[3]) if len(parts) > 3 else 0
        rng = np.random.default_rng(seed)
        M = sp.random(n, n, density=0.02, random_state=rng, format="csr")
        A = (M.T @ M + sp.eye(n) * 1.0).tocsr()
        b = np.ones(n)
        return A, b, {"n": n, "nnz": A.nnz, "type": "random_spd", "seed": seed}

    # --- SuiteSparse .mtx ---
    mtx_path = SUITESPARSE_DIR / f"{matrix_id}.mtx"
    if mtx_path.exists():
        from scipy.io import mmread
        A = mmread(str(mtx_path)).tocsr()
        b = np.ones(A.shape[0])
        return A, b, {"n": A.shape[0], "nnz": A.nnz, "type": "suitesparse",
                       "source": str(mtx_path)}

    # --- .npz ---
    npz_path = Path(matrix_id)
    if npz_path.suffix == ".npz" and npz_path.exists():
        data = np.load(str(npz_path), allow_pickle=True)
        A = sp.csr_matrix((data["data"], data["indices"], data["indptr"]),
                          shape=tuple(data["shape"]))
        b = data.get("b", np.ones(A.shape[0]))
        return A, b, {"n": A.shape[0], "nnz": A.nnz, "type": "npz",
                       "source": str(npz_path)}

    raise ValueError(f"Unknown matrix ID: {matrix_id}")


def list_available_matrices() -> list[str]:
    """Return list of all available matrix IDs."""
    ids = []
    for n in BUILTIN_POISSON_2D:
        ids.append(f"poisson_2d_{n}")
    for n in BUILTIN_POISSON_3D:
        ids.append(f"poisson_3d_{n}")
    for n in BUILTIN_ANISOTROPIC:
        ids.append(f"anisotropic_2d_{n}")
    if SUITESPARSE_DIR.exists():
        for f in sorted(SUITESPARSE_DIR.glob("*.mtx")):
            ids.append(f.stem)
    return ids


if __name__ == "__main__":
    print("Available matrices:")
    for mid in list_available_matrices():
        try:
            A, b, meta = load_matrix(mid)
            print(f"  {mid}: n={meta['n']}, nnz={meta['nnz']}")
        except Exception as e:
            print(f"  {mid}: FAILED ({e})")
